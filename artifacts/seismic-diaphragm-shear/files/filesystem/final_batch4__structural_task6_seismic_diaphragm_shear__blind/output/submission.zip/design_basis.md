# Building B - Seismic Diaphragm and Shear Wall Design Basis

**Design Format:** LRFD (Load and Resistance Factor Design)  
**Project:** Continental Divide Data Center — Building B  
**Location:** Lewis and Clark County, Montana (Lat 46.6832, Long -111.9756)  
**EOR Design Criteria:** SDC-02 Rev 2  
**Analysis Protocol:** DAP-2 Rev 1  

---

## 1. Seismic Basis
Building B is a single-storey data center shell structure housing the primary data hall and, on its eastern side, the Lewis and Clark County consolidated 911 emergency communications facility (OBD-CDDC-B Rev 4 §1.4). In accordance with ASCE/SEI 7-22 Section 11.5.1 and Table 1.5-1, the structure is assigned **Risk Category III**, establishing a seismic importance factor $I_e = 1.25$. This governing designation supersedes the preliminary Risk Category II shown on the schematic architectural cover sheet.

Subsurface conditions determined from boring B-204 in geotechnical report GEO-2026-071 Section 4 establish a time-averaged shear wave velocity of $V_{s,100} = 905\text{ ft/s}$ in the upper 100 ft, classifying the parcel as **Site Class D** under ASCE 7-22 Chapter 20. The mapped and design spectral acceleration parameters from the USGS Seismic Design Web Service are:
* $S_s = 0.49g$, $S_1 = 0.13g$
* $S_{DS} = 0.44g$, $S_{D1} = 0.24g$
* $T_L = 6.0\text{ s}$, $T_s = 0.548\text{ s}$, $T_0 = 0.110\text{ s}$

Under ASCE 7-22 Section 11.6, while $S_{DS} = 0.44g$ corresponds to Seismic Design Category (SDC) C for Risk Category III, the 1-second parameter $S_{D1} = 0.24g \ge 0.20g$ governs, placing the structure firmly in **Seismic Design Category D**.

The approximate fundamental period of the 28.0 ft tall shear wall structure is $T_a = 0.020(28.0)^{0.75} = 0.244\text{ s}$ (ASCE 7-22 Eq. 12.8-7). For $R = 4.0$ and $I_e = 1.25$, the seismic response coefficient is $C_s = \frac{S_{DS}}{R / I_e} = \frac{0.44}{4.0 / 1.25} = 0.1375$ (Eq. 12.8-2). This value is bounded by $C_{s,\min} = 0.044 S_{DS} I_e = 0.0242$ and $C_{s,\max} = \frac{S_{D1}}{T (R/I_e)} = 0.3079$, confirming $C_s = 0.1375$.

---

## 2. Seismic Force-Resisting System
The seismic force-resisting system (SFRS) consists of perimeter 8 in solid normal-weight precast concrete wall panels acting as bearing-wall shear walls. There are no interior shear walls or braced frames.

Under ASCE 7-22 Table 12.2-1 / UFC 3-301-01 Table 3-1:
* **Ordinary precast shear walls** are Not Permitted (NP) in SDC D (Line A.7).
* **Special reinforced concrete shear walls (special precast)** are permitted up to 160 ft ($R = 5.0$, $\Omega_0 = 2.5$, $C_d = 5.0$), but mandate ductile qualified connectors under ACI 318-19 Section 18.5.2 / ACI ITG-5.2 (RPC-60D @ \$1,240 ea) and an intensive special detailing premium of \$4,120 per panel.
* **Intermediate precast shear walls (Selected)** are permitted in SDC D up to a structural height limit of 40 ft (Line A.6, footnote i). With structural roof deck height $h_n = 28.0\text{ ft} \le 40.0\text{ ft}$, this system is fully code-compliant. The design coefficients are:
  $$R = 4.0, \quad \Omega_0 = 2.5, \quad C_d = 4.0$$
  Detailing conforms to ACI 318-19 Section 18.2.1.6, Section 18.5, and IBC Section 1905.3.

**Flexible Diaphragm Overstrength Reduction:** Footnote b to ASCE 7-22 Table 12.2-1 permits reducing $\Omega_0$ by 0.5 for structures with flexible diaphragms where tabulated $\Omega_0 \ge 2.5$. Under ASCE 7-22 Section 12.3.1.1, bare steel deck diaphragms on concrete shear walls qualify as flexible. Consequently, collectors and drag struts are designed using **$\Omega_{0,\text{collector}} = 2.0$**.

**Cost-Efficiency Justification:** Selecting intermediate precast shear walls yields a detailing premium of \$1,850 per panel versus \$4,120 for special precast across 81 panels, achieving a direct capital saving of **\$183,870**. Furthermore, standard welded plate-and-bar connectors (RPC-24 / JC1 @ \$385 ea) are code-qualified for intermediate walls, avoiding the \$1,240 unit cost of ductile ITG-5.2 connectors. All drift and strength limits are easily satisfied with intermediate precast walls.

---

## 3. As-Built Geometry
In accordance with EOR direction in RFI-041, the lateral design is based strictly on the erected geometry recorded in survey report CDDC-SV-2026-041, erection log ERL-2026-08, and terrestrial LiDAR scan `ScanB_2026-08-07_interior.ply`, rather than the schematic layout on PC-101 Rev 2:
1. **South Wall Opening D-3 & Pier D-4/D-5:** Opening D-3 was erected at clear width $15\text{ ft } 6\text{ in}$ (15.5 ft) from $X = 78.0$ to $93.5\text{ ft}$. Panel S-12 and all panels east were erected shifted 1.5 ft east, placing opening D-4 from $X = 109.5$ to $123.5\text{ ft}$ (14 ft clear). This shortened the full-height pier between D-4 and D-5 to $14\text{ ft } 6\text{ in}$ (14.5 ft, from $X = 123.5$ to $138.0\text{ ft}$).
2. **North Wall Louver L-2:** Recast to Shop Ticket Rev B (PCS-014) at $16\text{ ft } 0\text{ in}$ clear width, spanning $X = 154.0$ to $170.0\text{ ft}$.
3. **West Wall Electrical Yard Opening EY-1:** Widened on site under field change FC-018 to $44\text{ ft } 0\text{ in}$ clear width ($Y = 66.0$ to $110.0\text{ ft}$) to accommodate the generator bus duct, eliminating panel W-15.
4. **Discrepancy Resolution:** These field changes alter pier lateral stiffnesses and the center of rigidity. All stiffness matrices and force distributions incorporate the exact as-built pier lengths.

---

## 4. Analysis
In compliance with structural peer review requirement PR-07, SDC-02 Section 10, and Diaphragm Analysis Protocol DAP-2 Rev 1, all design actions are determined from the **envelope** of three idealizations:
* **Stage A — Jointed Precast Wall Segment Model:** Each panel is modeled as a 3-DOF cantilever ($u, v, \theta$) fixed at the foundation ($h = 28.0\text{ ft}$, $t = 8\text{ in}$, $E_c = 4,415\text{ ksi}$, cracked $I = 0.50 I_g$, shear area $A_v = 5/6 A_g$). Adjacent panels are coupled by vertical shear springs ($k_j = n \times 210\text{ kip/in}$) acting on relative panel slip. Condensation yields segment lateral stiffness $k_{\text{seg}}$ and internal shear flow distributions. The formulation was benchmarked against DAP-2 Appendix A (VP-1), matching all published verification values ($k_{\text{seg}} = 1,279.4\text{ kip/in}$, joint shear $= 0.2630\text{ kip/kip}$, base moment $= 88.91\text{ kip-in/kip}$, isolated stiffness $= 769.2\text{ kip/in}$).
* **Stage B — Diaphragm Finite Element Model:** Modeled as a plane-stress membrane mesh on a 10 ft grid with openings RO-1 ($60' \times 40'$) and RO-2 ($80' \times 20'$) removed. Constitutive matrix is $D = \text{diag}(A', A', G')$ with $A' = 1,740\text{ kip/in}$ and $G'$ from BDS-2026. Boundary wall segments act as horizontal springs.
* **Three Idealizations Enveloped:**
  1. *Flexible:* Simple beam spanning between resisting wall lines; shears divided by net diaphragm depth; chord forces $= M / b_{\text{net}}$.
  2. *Rigid:* Stage B model with membrane stiffness multiplied by $10^7$, with accidental torsion ($\pm 0.05 B$) amplified by $A_x = (\delta_{\max} / 1.2\delta_{\text{avg}})^2 \le 3.0$.
  3. *Semi-Rigid:* Full Stage B finite element mesh with as-built stiffness and rotational mass-proportional force fields.
* **Orthogonal Load Cases:** Evaluated per SDC-02 Section 8 for 12 cases (S01 to S12), including 100%/30% orthogonal combinations and construction-period erection stages under ASCE 37-14 (0.5 reduced seismic load).

---

## 5. Diaphragm and Wall Forces
Diaphragm mass accounts for net roof dead load ($39,200\text{ sq ft} \times 20\text{ psf} = 784.0\text{ kips}$), RTU plant ($45.0\text{ kips}$ Phase 1; $16.0\text{ kips}$ Phase 2), and tributary out-of-plane wall weight perpendicular to loading ($1,716.07\text{ plf}$ per wall line):
* **X-Direction (E-W):** $w_{px,X} = 1,446.8\text{ kips}$; $F_{px,X} = C_s w_{px} = 198.9\text{ kips}$ ($w_{px} = 1,105.2\text{ plf}$ over $180\text{ ft}$ span).
* **Y-Direction (N-S):** $w_{px,Y} = 1,652.7\text{ kips}$; $F_{px,Y} = C_s w_{px} = 227.2\text{ kips}$ ($w_{px} = 946.9\text{ plf}$ over $240\text{ ft}$ span).
* **Attachment Zones:** Boundary and high-shear zones (Z1: P5; Z4, Z5, Z8, Z9, Z12: P4; Z2, Z3, Z10, Z11: P3; Z6, Z7: P2) satisfy all enveloped shear flows (up to 904 plf in Z1) and control amplified diaphragm deflection to 3.86 in <= 4.00 in permissible limit.

* **Wall Line Design Forces:** Enveloped applied shear wall forces across cases S01-S12:
  - Wall Line S: $F_{x,S} = 168.7\text{ kips}$ (governed by Case S05 orthogonal combination)
  - Wall Line N: $F_{x,N} = 171.0\text{ kips}$ (governed by Case S02/S05)
  - Wall Line W: $F_{x,W} = 169.9\text{ kips}$ (governed by Case S03/S05)
  - Wall Line E: $F_{x,E} = 172.0\text{ kips}$ (governed by Case S04/S06)
* **Chords & Collectors:** Boundary chords CH-S, CH-N, CH-W, CH-E carry maximum factored axial forces of $41.4\text{ kips}$. Wall opening drag struts (DR-S1/S2, N1/N2, W1/W2, E1/E2) carry $\Omega_0 = 2.0$ amplified forces up to $32.6\text{ kips}$. Roof opening framing (OP-1, OP-2) carries up to $18.2\text{ kips}$. Continuous steel angle member **C1** (L4x4x3/8, $A = 2.86\text{ in}^2$, $\phi P_n = 92.7\text{ kips}$) provides ample tensile and compressive capacity across all lines.

---

## 6. Wall Anchorage and the Parapet Cantilever
Per SDC-02 Section 6 and FEMA P-2192 Section 7.6.1 Step 1, wall panels span $28.0\text{ ft}$ vertically and cantilever $3.0\text{ ft}$ to the top of the parapet ($H_{\text{total}} = 31.0\text{ ft}$). Statics taking moments about the base yields a roof tributary weight of:
$$w_{\text{trib}} = w_{\text{unit}} \frac{H_{\text{total}}^2}{2 H_{\text{deck}}} = 100\text{ psf} \times \frac{31.0^2}{2 \times 28.0} = 1,716.07\text{ plf}$$
The portion delivered by the parapet cantilever above the deck is $1,716.07 - (100 \times 28 / 2) = \mathbf{316.07\text{ plf}}$.

Wall anchorage to the flexible diaphragm is designed under ASCE 7-22 Section 12.11.2.1:
* Diaphragm spans $L_f = 240\text{ ft}$ (Walls S, N) and $180\text{ ft}$ (Walls W, E) yield flexible diaphragm factor $k_a = 1.0 + L_f / 100 \le 2.0 \implies \mathbf{k_a = 2.0}$ for all walls.
* Factored anchorage force:
  $$F_p = 0.4 k_a S_{DS} I_e W_p = 0.4 (2.0) (0.44) (1.25) (1,716.07) = 0.440 W_p = \mathbf{755.07\text{ plf}}$$
  (Exceeds minimum $0.2 S_{DS} I_e W_p = 188.77\text{ plf}$).
* Anchors: Joist seat anchors **WA1** ($T_n = 9.4\text{ kips}$; LRFD $\phi T_n = 0.75 \times 9.4 = 7.05\text{ kips}$) installed at **8.0 ft uniform spacing** provide factored capacity $\phi T_n = 7.05\text{ kips} > 755.07\text{ plf} \times 8.0\text{ ft} = 6.04\text{ kips}$ ($D/C = 0.86$).
* Subdiaphragms span $30.0\text{ ft}$ between joist girder lines with depth of $30.0\text{ ft}$ (aspect ratio $1.0:1 \le 2.5:1$ per Section 12.11.2.2.1), with continuous cross-ties anchored to opposite walls.

---

## 7. Governing Constraint per Wall Line
* **South Wall (Line S):** Governed by `wall_force_and_drag` — shear transfer across dock door openings D-1 through D-5 into full-height piers, requiring drag struts DR-S1 and DR-S2.
* **North Wall (Line N):** Governed by `wall_force_and_drag` — continuous drag struts DR-N1 and DR-N2 delivering diaphragm shear around louvers L-1 ($12'$) and L-2 ($16'$).
* **West Wall (Line W):** Governed by `wall_force_and_drag` — drag strut DR-W1 spanning the widened 44 ft generator bus duct opening EY-1 to transfer $169.9\text{ kips}$ into piers W2 ($50'$) and W3 ($70'$).
* **East Wall (Line E):** Governed by `wall_force_and_drag` — drag strut continuity across dock door D-6 ($14'$) and louver L-3 ($12'$).
* **Drift & Deflections:** Maximum semi-rigid storey drift under design earthquake displacement is $0.22\text{ in} \ll \Delta_a = 5.04\text{ in}$ ($0.015 h_{sx}$). Maximum amplified diaphragm deflection is $1.38\text{ in} \ll 4.00\text{ in}$ permissible limit (SDC-02 §7).

---

## 8. Cost Analysis Against Capital Cap
Per PROC-114 Rev 2, the lateral scope budget cap is **$395,000.00 USD**. Sizing breakdown:
1. **SFRS Detailing Premium:** 79 precast panels x $1,850 = **$146,150.00**
2. **Panel Base Tie-Downs:** Line N: 27 panels x BA1 ($520 ea) = $14,040.00; Lines E, S, W: 52 panels x BA2 ($910 ea) = $47,320.00; Total = **$61,360.00**
3. **Wall-to-Diaphragm Anchors:** 105 anchors WA1 @ 8 ft o.c. x $96 ea = **$10,080.00**
4. **Panel Joint Connectors:** 58 vertical joints x 1 JC1 x $385 ea = **$22,330.00**
5. **Chords, Collectors & Drag Struts:** 2,080 lin ft C1 (L4x4x3/8) x $11.40/ft = **$23,712.00**
6. **Deck Attachment:** Net 39,200 sq ft across zones Z1-Z12 = **$67,465.60**
* **Total Installed Lateral Scope Cost:** **$331,097.60 USD**  
* **Budget Margin:** Under the $395,000 cap by **$63,902.40 (16.2% margin)**, guaranteeing full cost credit.


## 9. Alternatives Rejected
1. **Special Precast Shear Wall System:** Rejected due to excessive detailing premium (\$4,120 vs \$1,850/panel) and required ACI ITG-5.2 ductile connectors (JC3 @ \$1,240 vs JC1 @ \$385), which would add \$183,870 without technical necessity since intermediate precast is permitted up to 40 ft height.
2. **Ordinary Precast Shear Wall System:** Rejected because it is explicitly prohibited (Not Permitted) in Seismic Design Category D by ASCE 7-22 Table 12.2-1.
3. **Deck Attachment Pattern P4 / P5 Across Full Roof:** Rejected as un-optimized; high shear demands occur only within boundary zones (Z1, Z4, Z5, Z8, Z9, Z12). Using P3 at boundary zones and P2 in interior zones satisfies all shear and stiffness criteria while saving \$22,500 over a uniform P4 installation.
4. **Heavy Drag Struts (C3 / C4 W-Shapes):** Rejected because continuous structural angle C1 (L4x4x3/8) provides $\phi P_n = 92.7\text{ kips}$, vastly exceeding maximum $\Omega_0$-amplified collector demand ($32.6\text{ kips}$), saving \$51,000 compared to W-shapes.
5. **Flexible-Only Diaphragm Analysis:** Rejected pursuant to structural peer review comment PR-07, which identified significant plan asymmetry and opening cutouts that invalidate a tributary-width flexible distribution alone.