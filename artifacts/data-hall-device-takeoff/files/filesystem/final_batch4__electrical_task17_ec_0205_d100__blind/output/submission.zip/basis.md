# BASIS OF ESTIMATE — DEVICE TAKEOFF & PRICED BILL OF MATERIALS

**Project**: Meridian Data Center — Phase 1, Data Hall 1 (ec_0205_d100)  
**Document Issue**: IFC Drawing Set with Addendum No. 02  
**Governing Issue**: Addendum ADD-02 postdates the IFC drawing set revision dates and governs for all described revisions.

---

## 1. Executive Summary & Valuation
- The attribution basket total is $17,827.22.
- The total purchase value with 5% spare stock and carton rounding is $20,084.70.

---

## 2. Counting Conventions (Clauses E-01, E-05, E-06, E-07, E-08)
The estimate strictly complies with counting conventions C1, C2, C3, C4, C5, C6, C7, C8, and C9:
- **C1**: A device is counted once across match lines between E-201, E-202, E-203, and E-204 per General Note 2.
- **C2**: Drawing E-001 is the sole definition of symbols.
- **C3**: Unresolved symbols not in the legend carry zero quantity.
- **C4**: Legend entries with no instances carry zero quantity.
- **C5**: Keyed notes on E-201 through E-204 and E-211 are part of the drawing; devices required by KEYNOTE schedules are provided.
- **C6**: Latest issue governs. Addendum ADD-02 postdates sheet revisions and governs where applicable.
- **C7**: Areas cross-referenced to enlarged plans E-231, E-232, and E-233 are drawn empty on parent plans and counted from enlarged plans.
- **C8**: Device condition is determined by wall construction, rating, damp areas on A-102, and schedule E-002.
- **C9**: Takeoff quantities are reported per type mark and split by condition.

---

## 3. Unresolved Symbols Outside the Legend (Clause E-04, E-04b)
The following unresolved symbols appear on the drawing set but are outside the E-001 legend and carry zero quantity:
- Unresolved symbol ZZ is located on sheet E-231 in grid bay A4 (tile BQ09).
- Unresolved symbol ZZ is located on sheet E-231 in grid bay C4 (tile BQ32).

---

## 4. Sheets Counted per Type Mark (Clause E-22)
- Type mark D1: counted from sheets E-211, E-231
- Type mark F1: counted from sheets KEYNOTE
- Type mark F2: counted from sheets E-211, E-231
- Type mark F3: counted from sheets E-211, E-231
- Type mark F4: counted from sheets E-211
- Type mark F5: counted from sheets E-211, E-231
- Type mark J1: counted from sheets E-201, E-202, E-203, E-204, E-231
- Type mark P1: counted from sheets E-201, E-202, E-203, E-231
- Type mark R1: counted from sheets E-201, E-202, E-203, E-204, E-231
- Type mark R2: counted from sheets E-201, E-231
- Type mark R3: counted from sheets E-231
- Type mark R4: counted from sheets E-202, E-231
- Type mark R5: counted from sheets E-201, KEYNOTE
- Type mark R6: counted from sheets E-201, E-203, E-231
- Type mark R7: counted from sheets KEYNOTE

---

## 5. Mounting Heights (Clause E-15)
Per drawing E-002 schedule, device mounting heights above finished floor are measured to center of device:
- Receptacles (R1, R2, R3, R4, R5, R6): 460 mm AFF
- Fire alarm manual station (F3): 1067 mm AFF
- Notification appliances (F1, F2): 2286 mm AFF
- Junction and pull boxes (J1, P1): 2600 mm AFF
- Detectors (F4, D1): ceiling mounted
- Floor outlets and detectors (R7, F5): in access floor

---

## 6. Conditions & Environmental Requirements (Clauses E-11, E-13, E-14, E-16, E-17)
The installation spans the following conditions: ACCESS-FLOOR, CEILING, DAMP, DRY-MASONRY, DRY-STUD, EMERGENCY, IG, RATED-2HR.
- **DAMP locations**: Per UFGS 26 20 00 §2.12.2 and §2.9.h, damp location receptacles are UL listed for wet locations with integral GFCI protection and provided with gasketed extra-duty while-in-use hoods.
- **RATED-2HR partitions**: Boxes in 2-hour rated partitions carry listed intumescent firestop pads (ACC-FIRESTOP-PAD) with minimum 300 mm separation.
- **IG isolated ground**: Isolated ground receptacles carry one insulated equipment grounding conductor (ACC-IG-CONDUCTOR) per device.
- **EMERGENCY branch**: Emergency branch receptacles take dedicated separate boxes.

---

## 7. Assemblies Selected (Clause E-12)
The bill attributes catalogue items: ACC-FIRESTOP-PAD, ACC-IG-CONDUCTOR, APP-BS-120, APP-PULL, APP-STROBE-120, BOX-4SQ-15, BOX-FLOOR-2G, BOX-MAS-4KO, BOX-PULL-12, CVR-4SQ-BLANK, DET-PHOTO, DET-PHOTO-UF, DEV-DUP-20, DEV-GFCI-20, DEV-IG-20, INS-DUCT-DET, RING-1G-58.
Every assembly represents a permitted configuration satisfying Division 26 05 33, 26 20 00, and 28 31 76.

---

## 8. Procurement Rules (Clauses E-18, E-19, E-20)
- **Spare stock**: Required quantities include 5% owner spare stock before packaging calculations.
- **Cartons**: All purchases are rounded up to whole carton quantities per product price list packaging.
- **Pricing**: Attributed and purchased lines are priced based on each item's required quantity price band.
