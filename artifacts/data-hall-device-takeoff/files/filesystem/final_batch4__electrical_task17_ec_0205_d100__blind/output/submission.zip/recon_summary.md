# RECONNAISSANCE & CONSTRAINT EXTRACTION SUMMARY (SLICE 01)
**Project**: Meridian Data Center — Phase 1, Data Hall 1 (ec_0205_d100)  
**Owner**: Northgate Colocation LLC  
**Document Issue Date**: 2026-07-24 (IFC) | **Addendum No. 02**: 2026-08-07  
**Role**: Principal Electrical Estimator  

---

## 1. Executive Summary & Objective

This reconnaissance establishes the baseline inventory, hierarchy of authority, atomic constraint register, condition determination rules, device catalog mapping, and schema definitions for the device takeoff and priced bill of materials for Data Hall 1.

Every count in this takeoff must be mathematically exact (zero tolerance). No document in the package explicitly provides quantities; all counts must be synthesized from geometric census, symbol recognition against drawing E-001, keyed notes cross-referencing other sheets, enlarged plans, and Addendum No. 02 modifications.

---

## 2. Workspace Document Inventory

### 2.1 Drawing Set (`drawings/`)
| Sheet ID | Title | Format | Key Content & Role |
|---|---|---|---|
| **E-001** | Symbol Legend and General Notes | PNG (6800x4400) | **Sole authoritative definition of device symbols** (17 scheduled types). General Notes 1–6. |
| **E-002** | Device and Mounting Schedule | Markdown | Scheduled mounting heights, mounting types, wiring methods, branch assignments, colours, spec sections. **Carries no quantities.** |
| **T-002** | Codes and General Notes | Markdown | Codes in force (NFPA 70, NFPA 72, UFC 3-520-01, UFC 3-600-01, UFC 3-501-01, ERDC/ITL CAD/Graphics). General Notes 1–6. |
| **A-101** | Equipment Plan | PNG (6800x4400) | Architectural equipment layout, server cabinet lineups, CRAH units, electrical equipment. |
| **A-102** | Partition and Finish Plan | PNG (6800x4400) | **Sole authority for device CONDITION**: wall construction (stud, masonry), fire rating (2-hour type P3), DAMP hatch (CRAH aprons, vestibule), room names. |
| **A-301** | Building Section | PNG (6800x4400) | Floor-to-ceiling heights, access floor plenum depth, ceiling plenum dimensions. |
| **A-601** | Equipment Schedules | PNG (6800x4400) | Architectural and IT equipment census, dimensions, power requirements. |
| **A-602** | Containment Pathway Construction Data | PNG (6800x4400) | Hot/cold aisle containment geometry, cable tray pathways. |
| **E-101** | Power and Telecom Plan | PNG (6800x4400) | Major feeder routing, telecom backbones, panelboards. |
| **E-201** | Power & Device Plan 1 | PNG (6800x4400) | Devices in Grid Bays A1–B2 (SW quadrant). Keyed notes, match lines. |
| **E-202** | Power & Device Plan 2 | PNG (6800x4400) | Devices in Grid Bays C1–D2 (SE quadrant). Keyed notes, match lines. |
| **E-203** | Power & Device Plan 3 | PNG (6800x4400) | Devices in Grid Bays A3–B4 (NW quadrant). Keyed notes, match lines. |
| **E-204** | Power & Device Plan 4 | PNG (6800x4400) | Devices in Grid Bays C3–D4 (NE quadrant). Keyed notes, match lines. |
| **E-211** | Fire Alarm Device Plan | PNG (6800x4400) | Life safety appliances (F1, F2, F3, F4, F5, F6, D1). Keyed notes. |
| **E-231** | Enlarged Electrical Plans (Area 1) | PNG (6800x4400) | Enlarged plan for high-density areas; parent plan is drawn empty where cross-referenced. |
| **E-232** | Enlarged Electrical Plans (Area 2) | PNG (6800x4400) | Enlarged electrical details, UPS/Battery room details. |
| **E-233** | Enlarged Electrical Plans (Area 3) | PNG (6800x4400) | Enlarged electrical details, main electrical room. |
| **M-101** | Chilled Water Plan | PNG (6800x4400) | CRAH unit piping, mechanical equipment locations (census for UFC 3-520-01 25-ft receptacle rule). |
| **F-101** | Fire Protection Plan | PNG (6800x4400) | Sprinkler pipe layout, pre-action valves, suppression zones. |

### 2.2 Addenda (`addenda/`)
- **ADD-02** (Dated 2026-08-07): Postdates all IFC drawing revisions (2026-07-24).
  - **Item 02-1**: In Grid Bay A1 on E-201, **DELETE** the duplex receptacles shown clouded/tagged Rev 2 (serving withdrawn cabinets).
  - **ADD**, at positions of 1st and 2nd deleted receptacles from south, **one quadraplex receptacle (R2) each**, mounted per E-002.
  - No other sheet is modified.

### 2.3 Specifications (`spec/`)
- `07_84_00_firestopping.md`: Firestopping of penetrations; intumescent pads on boxes in rated walls; 300 mm (12 in) box separation.
- `26_05_33_raceways_and_boxes.md`: Box types for dry stud, masonry, rated assemblies, damp locations, floor boxes, pull boxes, junction boxes, detector boxes.
- `26_20_00_wiring_devices.md`: Receptacle grades, IG conductors, weather-resistant GFCI, device plates, mounting heights (460 mm AFF to center), emergency branch separation, UFC 3-520-01 25-ft spacing rule.
- `28_31_76_fire_detection_and_alarm.md`: Notification appliances, manual stations (<=1.5 m from exit doors), ceiling smoke detectors, access floor detectors (21 m² / 225 sq ft coverage), and **D1 duct detector scope (furnished Div 23, installed/wired Div 26: labor-only `INS-DUCT-DET`)**.

### 2.4 Product Data & Price List (`product_data/`)
- `device_catalogue_2026.md`: 27 catalog items with listing tokens and classifications. Note: Contains NO while-in-use hood.
- `price_list_2026Q2.md`: 27 catalog items with unit rates across three quantity bands (Band 1: 1–24, Band 2: 25–99, Band 3: 100+), carton quantities, and terms.

### 2.5 Owner's Project Requirements (`project/OPR.md`)
- 5% spare stock required for all materials, rounded up to next whole carton.
- Pricing based on required quantity band before spare stock.

### 2.6 Criteria Manual (`criteria/takeoff_criteria_manual.md`)
- Master evaluation standard: 9 Counting Conventions (C1–C9), 8 Condition Vocabularies, 23 Clauses (E-01 to E-22), exact deliverable schemas.

---

## 3. Order of Precedence & Authority

Conflicts and governing rules are resolved strictly in accordance with:
Criteria Manual / Addenda (ADD-02) > Enlarged Plans (E-231..233) > Parent Plans (E-201..204, E-211) > Legend (E-001) / Schedule (E-002) > Architectural Plans (A-102) > Specifications > Standards.

1. **Addendum Hierarchy (C6, E-07)**: ADD-02 (2026-08-07) supersedes E-201 (2026-07-24) for clouded/tagged items in Grid Bay A1.
2. **Legend Exclusivity (C2, C3, C4, E-02, E-03, E-04, E-04b)**: E-001 is the sole definition of a valid device symbol. Unscheduled symbols on plans carry 0 count and are recorded in `basis.md` as unresolved items.
3. **Keyed Note Primacy (C5, E-06)**: Keyed notes requiring devices must be provided even if no symbol is drawn. Geometry census comes from referenced sheets (e.g., CRAH units on M-101/A-101, doors on A-102).
4. **Enlarged Plan Primacy (C7, E-08)**: Parent plans leave cross-referenced areas empty; devices are counted exclusively from enlarged plans.
5. **Match-Line Single Count (C1, E-05)**: Match-line notes dictate which sheet counts the boundary devices (scheduled side vs. reference side).

---

## 4. Scheduled Device Inventory (from E-001 & E-002)

| Mark | Description | Mounting Height | Mounting Location | Branch | Spec Section |
|---|---|---|---|---|---|
| **R1** | Receptacle, Duplex, 20 A, 125 V, Wall-Mounted | 460 mm AFF | Wall | Normal | 26 20 00 |
| **R2** | Receptacle, Quadraplex, 20 A, 125 V, Wall-Mounted | 460 mm AFF | Wall | Normal | 26 20 00 |
| **R3** | Receptacle, Duplex, GFCI, 20 A | 460 mm AFF | Wall | Normal | 26 20 00 |
| **R4** | Receptacle, Duplex, Isolated Ground, 20 A, 125 V | 460 mm AFF | Wall | Normal | 26 20 00 |
| **R5** | Receptacle, Duplex, Weather-Resistant, While-In-Use | 460 mm AFF | Wall | Normal | 26 20 00 |
| **R6** | Receptacle, Duplex, Emergency Branch, 20 A, 125 V | 460 mm AFF | Wall | Emergency | 26 20 00 |
| **R7** | Box, Outlet, Floor, Two-Gang, In Access Floor | Flush in floor | In Access Floor | Normal | 26 20 00 |
| **R8** | Receptacle, Single, 50 A, 250 V, Wall-Mounted | 1200 mm AFF | Wall | Normal | 26 20 00 |
| **J1** | Box, Junction, 100 mm Square, Concealed | 2600 mm AFF | Wall | Normal | 26 20 00 |
| **P1** | Box, Pull, 300 x 300 x 150 mm, Surface | 2600 mm AFF | Wall | Normal | 26 20 00 |
| **F1** | Appliance, Notification, Visible, Wall-Mounted | 2286 mm AFF | Wall | Normal | 28 31 76 |
| **F2** | Appliance, Notification, Audible-Visible, Wall-Mounted| 2286 mm AFF | Wall | Normal | 28 31 76 |
| **F3** | Station, Manual, Fire Alarm, Wall-Mounted | 1067 mm AFF | Wall | Normal | 28 31 76 |
| **F4** | Detector, Smoke, Photoelectric, Ceiling-Mounted | Ceiling | Ceiling | Normal | 28 31 76 |
| **F5** | Detector, Smoke, Photoelectric, In Access Floor | In Access Floor | In Access Floor | Normal | 28 31 76 |
| **F6** | Detector, Smoke, Projected Beam, Wall-Mounted | 2286 mm AFF | Wall | Normal | 28 31 76 |
| **D1** | Detector, Smoke, Duct, Furnished Div 23 | At Unit | In Supply Duct | Normal | 28 31 76 |

---

## 5. Condition Determination Precedence Engine

A device's `condition` is governed by strict precedence:

1. **E-002 Properties Take Absolute Precedence**:
   - `EMERGENCY`: Any device with `BRANCH == EMERGENCY` (e.g., R6).
   - `IG`: Any device scheduled as Isolated Ground (e.g., R4).
   - `CEILING`: Any device with `MOUNTING == CEILING` (e.g., F4), PLUS **D1 duct smoke detector is carried under CEILING wherever it is located**.
   - `ACCESS-FLOOR`: Any device with `MOUNTING == IN ACCESS FLOOR` (e.g., R7, F5).
2. **DAMP Location Precedence**:
   - Any remaining device located within an area hatched `DAMP` on A-102 (CRAH condensate aprons and vestibule) is assigned condition `DAMP`.
3. **Wall Construction Proximity Rule (A-102)**:
   - Any other device taking a wall condition is assigned the construction of the nearest wall on A-102, measured to the wall centerline:
     - `RATED-2HR`: Wall hatched 2-hour fire-rated (Type P3).
     - `DRY-MASONRY`: Wall of masonry or precast construction.
     - `DRY-STUD`: Normal drywall stud partition.
4. **Keyed Note Unlocated Device Rule**:
   - A device required by a keyed note and drawn nowhere takes the construction of the wall the note names (for a device at a door, the wall containing that door on A-102), or `DRY-STUD` where the note names none.

---

## 6. Catalog Item & Assembly Assignment Rules

| Condition | Required Assembly Items | Multiplicity | Catalog Item ID | Notes / Exceptions |
|---|---|---|---|---|
| `DRY-STUD` (Receptacles) | Box 4" Square 2-1/8" Deep<br>Plaster Ring 5/8" Raised<br>Device | 1<br>1<br>1 | `BOX-4SQ-21`<br>`RING-1G-58`<br>`DEV-DUP-20` (or `DEV-GFCI-20` for R3) | Plaster ring required per 26 05 33 §2.2. |
| `DRY-MASONRY` | Masonry Box 3-1/2" Deep<br>Device | 1<br>1 | `BOX-MAS-4KO`<br>`DEV-DUP-20` | **NO plaster ring** per 26 05 33 §2.3. |
| `RATED-2HR` | Box 4" Square 2-1/8" Deep<br>Plaster Ring 5/8" Raised<br>Intumescent Firestop Pad<br>Device | 1<br>1<br>1<br>1 | `BOX-4SQ-21`<br>`RING-1G-58`<br>`ACC-FIRESTOP-PAD`<br>`DEV-DUP-20` | Firestop pad mandatory per 07 84 00 & E-14. |
| `DAMP` | Weather-Resistant GFCI Device<br>Box 4" Square 2-1/8" Deep<br>Plaster Ring 5/8" Raised | 1<br>1<br>1 | `DEV-GFCI-20`<br>`BOX-4SQ-21`<br>`RING-1G-58` | **Catalogue carries no while-in-use hood**: state in basis, carry no BOM line per task instructions. |
| `CEILING` (F4) | 4" Mounting Box<br>Ceiling Photo Detector | 1<br>1 | `BOX-4SQ-15`<br>`DET-PHOTO` | No ring. |
| `CEILING` (D1) | Duct Detector Install Allowance | 1 | `INS-DUCT-DET` | Material furnished by Div 23; Div 26 carries labor/installation only. |
| `ACCESS-FLOOR` (R7) | Recessed Floor Box Steel 2-Gang | 1 | `BOX-FLOOR-2G` | No ring. |
| `ACCESS-FLOOR` (F5) | 4" Mounting Box<br>Access Floor Photo Detector | 1<br>1 | `BOX-4SQ-15`<br>`DET-PHOTO-UF` | Under-floor listed detector. |
| `EMERGENCY` (R6) | Box 4" Square 2-1/8" Deep<br>Plaster Ring 5/8" Raised<br>Device (Red/Spec Grade) | 1<br>1<br>1 | `BOX-4SQ-21`<br>`RING-1G-58`<br>`DEV-DUP-20` | Separate box required per E-17. |
| `IG` (R4) | Box 4" Square 2-1/8" Deep<br>Plaster Ring 5/8" Raised<br>IG Receptacle<br>Insulated EGC Conductor | 1<br>1<br>1<br>1 | `BOX-4SQ-21`<br>`RING-1G-58`<br>`DEV-IG-20`<br>`ACC-IG-CONDUCTOR` | EGC conductor per E-16 / 26 20 00 §2.2. |
| `Junction Box` (J1) | Box 4" Square 1-1/2" Deep<br>Flat Blank Cover | 1<br>1 | `BOX-4SQ-15`<br>`CVR-4SQ-BLANK` | Concealed junction per 26 05 33 §2.8. |
| `Pull Box` (P1) | Pull Box 12x12x6" Screw Cover | 1 | `BOX-PULL-12` | Box & cover integral per 26 05 33 §2.7. |
| `Fire Alarm Wall` (F1) | Box 4" Square 2-1/8" Deep<br>Strobe Appliance 120V | 1<br>1 | `BOX-4SQ-21`<br>`APP-STROBE-120` | 28 31 76 §2.1. |
| `Fire Alarm Wall` (F2) | Box 4" Square 2-1/8" Deep<br>Buzzer/Strobe or Horn/Strobe | 1<br>1 | `BOX-4SQ-21`<br>`APP-BS-120` | E-002 schedules 120V; match voltage. |
| `Manual Station` (F3) | Box 4" Square 2-1/8" Deep<br>Double Action Pull Station | 1<br>1 | `BOX-4SQ-21`<br>`APP-PULL` | 28 31 76 §2.2. |

---

## 7. Atomic Sub-Clause Decomposition (E-01 to E-22)

To comply with Fractal Kernel Principle 7, all compound requirements are decomposed into atomic, single-clause verification gates:

| Clause ID | Gate Type | Requirement Text | Governing Document & Source | Active Verification Metric |
|---|---|---|---|---|
| **E-01** | HARD | Device quantity exactness | Criteria Manual §5 | Derived integer count == submitted count |
| **E-02** | HARD | Full type mark inclusion | E-001 Legend | All marks with >=1 instance appear in takeoff.csv |
| **E-03** | HARD | Zero-instance handling | E-001 Note 4, C4 | Marks with 0 instances carry 0 or omitted |
| **E-04** | HARD | Unscheduled symbol exclusion | E-001 Note 5, C3 | Non-legend symbols carry quantity = 0 |
| **E-04b** | soft | Unscheduled symbol reporting | E-001 Note 5, C3 | Non-legend symbols reported in basis.md with sheet & bay |
| **E-05** | HARD | Match-line single count | Device Plans Note 2, C1 | Boundary devices counted exactly once per match-line note |
| **E-06** | HARD | Keyed note device inclusion | Keynotes, C5, UFC 3-520-01 | Devices required by keynotes included in count |
| **E-07** | HARD | Addendum authority precedence | ADD-02, Revision blocks, C6 | ADD-02 deletions removed, additions included in A1 |
| **E-08** | HARD | Enlarged plan cross-referencing | General Note 4, E-231, C7 | Enlarged plan devices counted; parent plan empty |
| **E-09** | soft | Sheet-level total agreement | Criteria Manual §5 | (Sheet, type mark) count in locations.csv == derived |
| **E-10** | soft | Location vs BOM parity | Criteria Manual §5 | locations.csv count == bom.csv attribution count per (mark, cond) |
| **E-11** | HARD | Condition assignment accuracy | A-102, E-002, C8 | Every device condition exact per precedence rules |
| **E-12** | HARD | Permitted catalog assembly | Spec 26 05 33, 26 20 00 | Chosen assembly satisfies spec requirements for condition |
| **E-13** | HARD | Damp location GFCI + Hood | Spec 26 20 00 §2.3, UFGS 2.12.2 | DAMP devices carry GFCI WR; hood noted as missing in catalog |
| **E-14a** | HARD | Firestop pad on rated wall boxes | Spec 07 84 00 §2.1, NFPA 70 300.21 | Box in RATED-2HR carries ACC-FIRESTOP-PAD |
| **E-14b** | HARD | 300 mm box separation | UFC 3-520-01 §3-6.1 | Back-to-back boxes separated by >= 300 mm (12 in) |
| **E-15** | soft | Scheduled mounting heights | E-002, UFGS 26 20 00 §3.1.10 | Receptacles mounted at 460 mm AFF to center; stated in basis |
| **E-16** | soft | Isolated ground EGC conductor | NFPA 70 250.146(D), Spec 26 20 00 §2.2 | IG device includes ACC-IG-CONDUCTOR |
| **E-17** | soft | Emergency branch box separation | E-002, Spec 26 20 00 §3.2 | Emergency device uses dedicated box, never shared |
| **E-18** | HARD | 5% minimum owner spare stock | project/OPR.md §4 | Purchase qty >= ceil(Required qty * 1.05) |
| **E-19** | soft | Full carton purchase rounding | price_list_2026Q2.md | Purchase qty == integer * carton_qty |
| **E-20** | HARD | Price band determination | price_list_2026Q2.md | Unit rate based on REQUIRED qty band (1-24, 25-99, 100+) |
| **E-21** | soft | Mathematical ledger parity | Criteria Manual §5 | extended_price == qty * unit_price; sum == basket total |
| **E-22** | soft | Basis of estimate documentation | Criteria Manual §3.5, §5 | basis.md documents all methods, sheets, assemblies, totals |

---

## 8. Pricing & Purchasing Computational Logic

1. **Attribution Rows (BOM Proper)**:
   - For each active `(type_mark, condition)`:
     Required Qty = Sum over all pairs of (Count * Multiplicity)
2. **Pricing Band Selection**:
   - Evaluated on total **Required Qty** for each catalog item:
     - Band 1: 1 <= Q_req <= 24 (or item-specific break)
     - Band 2: 25 <= Q_req <= 99 (or item-specific break)
     - Band 3: Q_req >= 100 (or item-specific break)
   - Unit price P_unit is fixed across all rows (attribution and purchase) for that item.
3. **Basket Total**:
   - Basket Total = Sum over all attribution rows of (Q_attrib * P_unit)
4. **Purchase Rows**:
   - for_type_mark = (PURCHASE), condition = (STOCK)
   - Required with spare: Q_spare = Q_req * 1.05
   - Carton rounded purchase quantity: Q_purch = ceil(Q_spare / Carton Size) * Carton Size
   - Extended Purchase Price: Ext Price = Q_purch * P_unit

---

## 9. Next Steps for Execution (Slice 02)

1. Run automated symbol search across parent plans (E-201, E-202, E-203, E-204), enlarged plans (E-231, E-232, E-233), and fire alarm plan (E-211).
2. Execute keyed note census extraction (CRAH units, doors, mechanical equipment).
3. Apply ADD-02 revisions to Grid Bay A1 on E-201.
4. Classify device conditions against A-102 geometric partition zones and E-002 schedule rules.
5. Generate `takeoff.csv`, `locations.csv`, `bom.csv`, `register.csv`, and `basis.md`.
6. Package initial complete deliverable into `output/submission.zip`.
