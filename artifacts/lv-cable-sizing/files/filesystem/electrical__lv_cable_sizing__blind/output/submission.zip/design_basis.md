# Engineering Design Basis — Low-Voltage Conductor Sizing
## Building 4210, Consolidated Support Facility, Naval Support Activity Whitmore Ridge
### Electrical Basis of Design & Wire Schedule Technical Narrative

```json
{
  "codes_of_record": {
    "nfpa70_edition": "2023",
    "ibc_edition": "2024",
    "adopted_by": "UFC 1-200-01",
    "precedence": "most restrictive requirement governs"
  },
  "environment": {
    "outdoor_design_dry_bulb_c": 42.0,
    "roof_ambient_c": 46.0,
    "earth_ambient_c": 27.45,
    "soil_thermal_resistivity_k_m_w": 0.6,
    "solar_irradiance_w_m2": 1030.0
  },
  "sources": {
    "outdoor_design_dry_bulb_c": "EDS-26 Rev 4 clause 5.4 / NOAA daily normals USW00003145",
    "roof_ambient_c": "EDS-26 Rev 4 clause 5.4 / M-501-C Note 2",
    "earth_ambient_c": "EDS-26 Rev 4 clause 5.3.2 / NOAA daily normals USW00003145",
    "soil_thermal_resistivity_k_m_w": "GEO-4210-T clause 2.2 (fluidised thermal backfill)",
    "solar_irradiance_w_m2": "EDS-26 Rev 4 clause 5.4"
  },
  "voltage_drop": {
    "start_point": "T-1 secondary lugs",
    "transformer_reset": false,
    "feeder_chain_pct": 2.663,
    "branch_limit_pct": 3.0,
    "total_limit_pct": 5.0
  },
  "cost": {
    "conductor_usd": 116065.9,
    "termination_usd": 8184.96,
    "raceway_usd": 45060.5,
    "material_usd": 121016.14,
    "labor_usd": 48295.22,
    "total_usd": 169311.36
  },
  "duct_assignment": {
    "SE-1": [
      "D1",
      "D2",
      "D3",
      "D4",
      "D5",
      "D6"
    ],
    "F-10": [
      "D8",
      "D10"
    ],
    "F-05": [
      "E1",
      "E2",
      "E3"
    ]
  },
  "mutual_heating_rise_k": 27.14
}
```

---

## 1. Codes of Record, Adopting Authority, and Order of Precedence

The electrical design of Building 4210 is prepared strictly against the federal criteria and installation standards established at the start of design on Sheet G-001:
- **Adopting Document**: `UFC 1-200-01 DoD Building Code` (1 September 2022, with Change 4 of 17 December 2024). UFC 1-200-01 adopts the `International Building Code (IBC), 2024 Edition`, and directs every reference to the National Electrical Code (`NFPA 70`) to `UFC 3-501-01`.
- **National Electrical Code**: `NFPA 70, 2023 Edition`, as cited and amended by UFC 3-501-01 and UFC 3-520-01.
- **Governing Federal Criteria**: `UFC 3-501-01 Electrical Engineering` (27 November 2024) and `UFC 3-520-01 Interior Electrical Systems` (16 January 2025).
- **Energy Criteria**: `UFC 1-200-02 High and Performance Sustainable Building Requirements`, citing `ASHRAE 90.1`.
- **Installation Standard**: Naval Support Activity Whitmore Ridge Public Works Department `EDS-26 Electrical Design Standard, Rev 4` (12 June 2026).

### Order of Precedence
Per EDS-26 Section 1.1 and Sheet G-001: **Where two of these documents set different limits for the same parameter, the most restrictive requirement governs.** Where an installation standard is silent, the governing UFC controls.

### Superseded Revisions Excluded
- `EDS-26 Rev 2` (3 March 2022) is superseded in its entirety by Rev 4. Obsolete clauses from Rev 2 (allowing 7 distinct large wire sizes, 4 parallel sets, 5-foot termination allowance, 20°C earth ambient, and 2% feeder VD) are strictly excluded from design.
- `E-601 Rev A` (8 February 2026) was superseded by Revision C dated 12 June 2026 following reselection of the chiller plant at 500 tons and addition of Building 4212 shop loads. Obsolete ratings (such as 1200A service switchboard) have been eliminated.
- `Meridian Cable MC-BW-2025` is explicitly marked "NOT THE BASIS OF DESIGN" and is excluded. The sole basis of design for cable engineering data and pricing is `Cascadia Wire and Cable Engineering Data Section 4, Issue 2026-1` and `Price List 2026`.

---

## 2. Environmental Parameters & Provenance

Every thermal and environmental parameter used in ampacity derating and voltage-drop calculations is derived from project records:
1. **Outdoor Design Dry-Bulb Temperature**: **42.0°C**. Derived per EDS-26 Section 5.4 as the highest daily normal maximum temperature in the station climate record (`NOAA daily normals 1991-2020 USW00003145`, Yuma MCAS) of 106.8°F (41.56°C), rounded up to the next whole degree Celsius.
2. **Roof Ambient Temperature**: **46.0°C**. Derived per EDS-26 Section 5.4 and Mechanical Coordination Memorandum M-501-C Note 2 by adding a 4 K roof film allowance to the 42.0°C outdoor dry-bulb temperature.
3. **Earth Ambient Temperature**: **27.45°C**. Derived per EDS-26 Section 5.3.2 as the annual mean of the daily average temperature normals (76.00°F = 24.45°C) plus 3 K. Field-logged ground temperatures (22.1–28.4°C) reported in GEO-4210-T Section 2.4 were rejected for design because the monitoring period did not span the summer maximum.
4. **Soil & Encasement Thermal Resistivity**:
   - `rho_e = 0.60 K·m/W`: Per GEO-4210-T Section 2.2, both duct banks DB-1 and DB-2 are 100% surrounded by fluidized thermal backfill (sand-cement slurry per Section 31 23 23) for the full trench width. The native soil design resistivity (0.95 K·m/W on the dry side of the dryout curve) is rejected because the native soil does not contact the encasement envelope.
   - `rho_c = 0.55 K·m/W`: Concrete encasement envelope thermal resistivity per GEO-4210-T Section 2.3.
5. **Solar Irradiance Parameters**: Per EDS-26 Section 5.4, solar gain on the unroofed roof cable tray CT-R1 is evaluated with solar irradiance $S = 1030	ext{ W/m}^2$, absorptivity $lpha_s = 0.60$, and convection/radiation film coefficient $h = 14.0	ext{ W/(m2\cdot	ext{K)}$.
6. **Interior Raceway Ambients**: Governed by Coordination Memorandum M-501-C:
   - Mechanical Room 121 and Fire Pump Room 105: **45.0°C** for all circuits whose route enters these rooms (F-01, F-03, B-11, B-12, B-13, B-14, B-15).
   - Ceiling cavities, return plenums, and unconditioned shop (Building 4212): **40.0°C** for all other interior power circuits.

---

## 3. Voltage-Drop Allocation, Starting Point, and Path Budgets

### 3.1 Point of Government Ownership & Starting Point
Per `WRPU Electric Service Availability Letter WRPU-2026-0412` and `UFC 3-501-01 paragraph 3-2.7.4.2`, the point of government ownership is the **secondary lug compartment of utility pad-mount transformer T-1**. All voltage drop calculations start at T-1 secondary lugs at nominal voltage (480Y/277V). Per UFC 3-501-01 paragraph 3-2.7.4.1, utility transformer taps are prohibited from being used to compensate for voltage drop.

### 3.2 Transformer Voltage Drop Reset
Per `UFC 3-501-01 paragraph 3-2.7.4.5.3`, voltage drop through low-voltage dry-type transformers (such as K-13, 225 kVA 480-208Y/120V) is modeled as zero internal loss drop, and **the cumulative percentage carries directly across the transformer**. The voltage drop count **DOES NOT RESTART** at K-13 secondary. Branch circuits fed from LP-1 inherit the full cumulative percentage spent by upstream feeders SE-1, F-02, F-06, and F-07.

### 3.3 Allocation Along Feeder Chains
- **Total Voltage Drop Budget**: Limited to **5.00%** cumulative from T-1 to the farthest load.
- **Feeder Chain Limit**: Feeders are strictly limited to **3.00%** cumulative voltage drop.
- **LP-1 Chain**:
  - `SE-1` (320 ft, 6 sets 500 kcmil Cu): $\Delta V = 5.01	ext{ V} 
ightarrow 1.043\%$
  - `F-02` (62 ft, 1 set 500 kcmil Cu): $\Delta V = 1.74	ext{ V} 
ightarrow 0.363\%$
  - `F-06` (36 ft, 1 set 500 kcmil Cu): $\Delta V = 0.67	ext{ V} 
ightarrow 0.140\%$
  - `F-07` (127 ft, 3 sets 350 kcmil Cu): $\Delta V = 2.18	ext{ V} 
ightarrow 1.046\%$
  - **Cumulative Feeder Drop at LP-1**: $1.043\% + 0.363\% + 0.140\% + 1.046\% = \mathbf{2.592\%} \le 3.00\%$.
  - All 10 branch circuits fed from LP-1 (B-01 through B-10) operate within the remaining $5.00\% - 2.592\% = 2.408\%$ budget and their individual $\le 3.00\%$ limit.
- **Building 4212 Chain**:
  - `SE-1`: $1.043\%$
  - `F-05` (716 ft, 3 sets 500 kcmil Cu in DB-2): $\Delta V = 5.69	ext{ V} 
ightarrow 1.185\%$
  - **Cumulative Feeder Drop at DP-3**: $1.043\% + 1.185\% = \mathbf{2.228\%} \le 3.00\%$.
  - All shop branch circuits (B-16, B-17, B-18) satisfy $\le 5.00\%$ total at their utilization terminals without exceeding equipment lug limits.
- **MCC-1 Chain**:
  - `SE-1`: $1.043\%$
  - `F-01` (246 ft, 2 sets 350 kcmil Cu): $\Delta V = 6.57	ext{ V} 
ightarrow 1.368\%$
  - **Cumulative Feeder Drop at MCC-1**: $1.043\% + 1.368\% = \mathbf{2.411\%} \le 3.00\%$.
  - Motor feeders B-11 through B-15 remain below $3.50\%$ cumulative drop.
- **Fire Pump Feeder (F-03)**:
  - Governed by `NFPA 70 Article 695` and `EDS-26 Section 4.6.3`.
  - At running full-load current (96 A): cumulative drop is $1.043\% + 0.295\% = 1.338\% \le 5.00\%$.
  - At locked-rotor current (543 A): cumulative drop is $1.043\% + 1.012\% = 2.055\% \le 15.00\%$.

---

## 4. Service-Entrance Sizing & Duct-Bank Thermal Modeling

### 4.1 Service-Entrance Sizing Decision
Under `UFC 3-501-01 paragraph 3-2.3.3` and `EDS-26 Section 2.2`, service entrance conductors are sized for continuous load current not less than the **ampacity of the main bus of the service equipment** (MSB-1 bus rating: **2000 A**), rather than the 1600 A main circuit breaker rating.

### 4.2 Duct Bank DB-1 Assignment & Thermal Consequences
- Duct Bank DB-1 consists of 12 conduits (5-inch EPC-40) in a $4 	imes 3$ concrete encasement (39.6" W $	imes$ 29.6" D) with 30 inches of cover.
- Per E-619, ducts D11 (owner reserve) and D12 (existing site lighting) are reserved. Ten ducts (D1–D10) are available.
- **SE-1 Assignment**: Six (6) parallel sets installed in ducts **D1, D2, D3, D4, D5, D6**. Operating current per set is $1732	ext{ A} / 6 = 288.67	ext{ A}$. Design current per set is $2000	ext{ A} / 6 = 333.33	ext{ A}$.
- **F-10 Assignment**: Standby ATS-1 feeder installed in ducts **D8 and D10**. Operating current per set is $432	ext{ A} / 2 = 216.0	ext{ A}$. Design current per set is $600	ext{ A} / 2 = 300.0	ext{ A}$.
- Ducts D7 and D9 are deliberately left empty to decouple thermal plumes.
- **Neher-McGrath Results**:
  - Mutual heating rise $\Delta T_m$ peaks at **27.14 K** (at duct D6).
  - Minimum corrected ampacity across SE-1 ducts is **369.3 A** (in duct D6), exceeding the required 333.33 A. Total service capacity is $6 	imes 369.3	ext{ A} = \mathbf{2215.9	ext{ A}} \ge 2000	ext{ A}$.
  - F-10 corrected ampacity is **376.8 A** per set (total $753.7	ext{ A} \ge 600	ext{ A}$).

### 4.3 Duct Bank DB-2 Assignment
- Duct Bank DB-2 consists of 4 conduits (4-inch EPC-40) in a $2 	imes 2$ encasement (19.5" W $	imes$ 19.5" D) with 30 inches of cover.
- Duct E4 is reserved for communications. Ducts E1, E2, and E3 carry the three parallel sets of `F-05` (500 kcmil Cu).
- Mutual heating rise is only **2.20 K**. Corrected ampacity is limited by the 75°C termination rating to **403.0 A** per set (total $1209.0	ext{ A} \ge 400	ext{ A}$).

---

## 5. Material & Standardization Decisions

### 5.1 Size Standardization Gate (EDS-26 Section 3.4.2)
EDS-26 Section 3.4.2 strictly limits the design to **no more than FIVE distinct phase-conductor sizes larger than #1 AWG across the whole project**.
The finalized design standardizes on exactly **THREE (3)** distinct sizes larger than #1 AWG:
1. `4/0 AWG`: Used for F-08 (AL), F-13 (AL), and F-09 (CU).
2. `350 kcmil`: Used for F-01 (CU), F-04 (CU), F-07 (CU), and F-12 (CU).
3. `500 kcmil`: Used for SE-1 (CU), F-02 (CU), F-05 (CU), F-06 (CU), and F-10 (CU).

All other circuits utilize conductor sizes $\le 	ext{#1 AWG}$ (#12, #8, #6, #4, #2, #1 AWG), which do not count against the standardisation quota.

### 5.2 Value-Engineering Conductor Material (EDS-26 Section 3.2)
Per UFC 3-520-01 paragraph 3-6.3.1 and EDS-26 Section 3.2, aluminum alloy conductors are permitted for sizes #4 AWG and larger where terminals are listed AL/CU.
- Feeders `F-08` and `F-13` (packaged rooftop units RTU-1 and RTU-2 in roof tray CT-R1) utilize **4/0 AWG Aluminum**, providing an installed cost saving of $1,967 compared to copper while satisfying tray ampacity (191.0 A > 151.25 A) and voltage drop ($\le 1.12\%$).
- All equipment grounding conductors are specified in **Copper** per EDS-26 Section 3.2.

---

## 6. Cost Ledger & Procurement Optimization

### 6.1 Campus Quantity Break (Cascadia Wire Price List Note)
The Cascadia Wire price list provides a project-wide **6.0% discount on installed conductor price** (material and labour) when total conductor footage reaches 38,000 feet.
- Selecting 6 parallel sets of 500 kcmil for SE-1 (in lieu of 5 sets of 600 kcmil) yields a total project conductor footage of **38,352 feet** (including phase and equipment grounding conductors).
- This successfully unlocks the campus quantity break, deducting **$8,041.94** from the installed package cost.

### 6.2 Installed Package Cost Summary
- **Conductors (net of 6% quantity discount)**: $125,990.39
- **Terminations (compression connectors)**: $8,709.96
- **Interior Raceways (rigid steel conduit)**: $45,060.50
- **Total Material Content**: $130,222.78
- **Total Labour Content**: $49,538.07
- **Total Installed Cost**: **$179,760.85**
