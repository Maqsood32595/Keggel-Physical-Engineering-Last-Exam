```json
{
  "codes_of_record": {
    "nfpa70_edition": "2023",
    "ibc_edition": "2024",
    "adopted_by": "UFC 1-200-01",
    "precedence": "most restrictive"
  },
  "environment": {
    "outdoor_design_dry_bulb_c": 42.0,
    "roof_ambient_c": 46.0,
    "earth_ambient_c": 27.45,
    "soil_thermal_resistivity_k_m_w": 0.6,
    "solar_irradiance_w_m2": 1030.0
  },
  "sources": {
    "outdoor_design_dry_bulb_c": "NOAA Station USW00003145 per EDS-26 Rev 4 paragraph 5.4",
    "roof_ambient_c": "NOAA Station USW00003145 + 4 K roof film allowance per EDS-26 Rev 4 paragraph 5.4 and M-501-C",
    "earth_ambient_c": "NOAA Station USW00003145 annual mean of daily average normals + 3 K per EDS-26 Rev 4 paragraph 5.3.2",
    "soil_thermal_resistivity_k_m_w": "GEO-4210-T paragraph 2.2 (fluidised thermal backfill)",
    "solar_irradiance_w_m2": "EDS-26 Rev 4 paragraph 5.4"
  },
  "voltage_drop": {
    "start_point": "T-1 secondary lugs (point of government ownership)",
    "transformer_reset": false,
    "feeder_chain_pct": 2.373,
    "branch_limit_pct": 3.0,
    "total_limit_pct": 5.0
  },
  "cost": {
    "conductor_usd": 133420.95,
    "termination_usd": 9342.96,
    "raceway_usd": 48116.0,
    "material_usd": 138814.7,
    "labor_usd": 52065.21,
    "total_usd": 190879.91
  },
  "duct_assignment": {
    "SE-1": [
      "D1",
      "D2",
      "D3",
      "D4",
      "D5",
      "D6"
    ],
    "F-10": [
      "D7",
      "D8"
    ],
    "F-05": [
      "E1",
      "E2",
      "E3"
    ]
  },
  "mutual_heating_rise_k": 27.03
}
```

# Engineering Design Basis & Narrative
## Project P-4210: Building 4210, Consolidated Support Facility
### Naval Support Activity Whitmore Ridge

## 1. Codes of Record and Order of Precedence

This low-voltage power conductor sizing package was engineered strictly against the contract documents and the governing codes of record fixed on Sheet G-001 (14 July 2025):
- **Primary Adopting Document:** UFC 1-200-01, *DoD Building Code* (01 September 2022, incorporating Change 4 of 17 December 2024).
- **Building Code:** International Building Code (IBC), 2024 Edition, as adopted and modified by UFC 1-200-01.
- **National Electrical Code:** NFPA 70, National Electrical Code (NEC), 2023 Edition, via reference from UFC 3-501-01.
- **Tri-Service Engineering Criteria:** UFC 3-501-01 *Electrical Engineering* (27 November 2024) and UFC 3-520-01 *Interior Electrical Systems* (16 January 2025).
- **Installation Standard:** Naval Support Activity Whitmore Ridge Electrical Design Standard EDS-26 Rev 4 (issued 12 June 2026).

**Order of Precedence:** Per Sheet G-001 and EDS-26 § 1.1, where two documents set different limits for the same parameter, the **most restrictive requirement governs**. Where EDS-26 is silent, the governing UFC criteria control. Superseded documents (EDS-26 Rev 2, E-601 Rev A, Meridian Cable MC-BW-2025) and non-power drawings (E-401) are strictly excluded from design inputs.

## 2. Environmental Parameters & Provenance

1. **Outdoor Design Dry-Bulb Temperature (42.0 °C):** Derived from the station climate record (NOAA Station USW00003145, 1991–2020 Normals). The highest daily normal maximum temperature is 106.8 °F (41.56 °C). In accordance with EDS-26 § 5.4, this value is rounded up to the next whole degree Celsius (42.0 °C).
2. **Roof Ambient Temperature (46.0 °C):** Calculated per EDS-26 § 5.4 by adding the mandatory 4 K roof film allowance to the outdoor dry-bulb (42.0 + 4.0 = 46.0 °C). This is consistent with Mechanical Coordination Memorandum M-501-C.
3. **Earth Ambient Temperature (27.45 °C):** Derived per EDS-26 § 5.3.2 as the annual mean of daily average normals in the NOAA station record (76.00 °F = 24.45 °C) plus 3 K, yielding 27.45 °C at duct-bank burial depth.
4. **Soil & Encasement Thermal Resistivity:** Per Geotechnical Investigation GEO-4210-T § 2.2, duct banks DB-1 and DB-2 are encased in concrete and completely surrounded by fluidized thermal backfill (sand-cement slurry, Section 31 23 23) for the entire excavation width. Therefore, the stable thermal resistivity of the backfill (0.60 K·m/W) governs all earth-portion and mutual-heating terms. The native soil resistivity (0.95 K·m/W) was evaluated and formally rejected because native soil is physically isolated from the thermal envelope. Concrete encasement resistivity is 0.55 K·m/W per GEO-4210-T § 2.3.
5. **Solar Irradiance:** S = 1030 W/m², absorption coefficient α_s = 0.60, and heat dissipation film coefficient h = 14.0 W/(m²·K) per EDS-26 § 5.4.

## 3. Voltage Drop Allocation & Feeder Chain Architecture

- **Starting Point:** Point of government ownership at the secondary lug compartment of pad-mounted utility transformer T-1 (nominal 480Y/277 V), per WRPU availability letter and UFC 3-501-01 § 3-2.7.4.2.
- **Transformer Reset:** As mandated by UFC 3-501-01 § 3-2.7.4.5.3, voltage drop percentage **does not reset** at dry-type transformer K-13. The secondary bus inherits the exact cumulative percentage (1.546%) present at the primary terminations.
- **Feeder Budget Allocation:**
  * Service Entrance SE-1: 1.043% drop at MSB-1 main bus.
  * Feeder F-01 to MCC-1: 1.122% drop (cumulative at MCC-1 = 2.165% <= 3.00%).
  * Feeder F-02 to DP-2: 0.363% drop (cumulative at DP-2 = 1.406% <= 3.00%).
  * Transformer Primary F-06 to K-13: 0.140% drop (cumulative at K-13 = 1.546% <= 3.00%).
  * Transformer Secondary F-07 to LP-1: 0.827% drop (cumulative at LP-1 = 2.373% <= 3.00%).
  * Feeder F-05 to DP-3 (Building 4212): 1.185% drop across 3 sets of 500 kcmil (cumulative at DP-3 = 2.228% <= 3.00%).
  * Feeder F-10 to ATS-1: 1.180% drop (cumulative at ATS-1 = 2.223% <= 3.00%).
  * All 13 downstream branch circuits fed from LP-1 and DP-3 inherit their panel's upstream drop and strictly maintain total cumulative drop <= 5.00% at the load terminals.

## 4. Service Entrance & Duct Bank Thermal Interactions

- **Service Entrance Sizing (SE-1):** In strict accordance with UFC 3-501-01 § 3-2.3.3 and EDS-26 § 2.2, SE-1 is sized for the continuous ampacity of the main bus of MSB-1 (2000 A), rather than the 1600 A trip rating or 1732 A connected load. Sizing to 2000 A requires 6 parallel sets of 500 kcmil CU.
- **Duct Bank DB-1 Assignment:** DB-1 provides 10 available 5-inch EPC-40 ducts (D1 through D10), with D11 (spare) and D12 (existing site lighting) reserved. SE-1 occupies ducts D1 through D6 (6 sets). Feeder F-10 occupies ducts D7 and D8 (2 sets). Exactly 8 ducts are loaded, leaving 2 available spare ducts (D9, D10) and 2 reserved ducts untouched.
- **Mutual Heating Impact:** Neher-McGrath mutual heating was modeled at operating currents (1732/6 = 288.7 A per set for SE-1; 432/2 = 216.0 A per set for F-10) with 100% load factor. The peak mutual heating temperature rise occurs at duct D6 (27.03 K) and D7 (28.66 K). The resulting thermal ampacity is 368.0 A per set for SE-1 (total 2208 A >= 2000 A) and 359.5 A per set for F-10 (total 719 A >= 600 A).
- **Duct Bank DB-2 Assignment (F-05):** DB-2 contains 3 available 4-inch EPC-40 ducts (E1, E2, E3) and 1 reserved communications duct (E4). F-05 is assigned across all 3 available ducts (E1, E2, E3) with 500 kcmil CU. This critical design decision reduces the voltage drop of this 716-ft run from 1.778% to 1.185%, lowering cumulative voltage drop at DP-3 to 2.228%. This ensures that downstream compressor CMP-1 (circuit B-17) meets the 5.00% cumulative drop limit using #6 AWG wire, fitting directly into CMP-1's listed #6 terminal without requiring field splicing or reduction adapters.

## 5. Material & Standardization Decisions

- **Conductor Material:** Class B compact stranded copper with XHHW-2 insulation (90 °C wet/dry) is selected across all circuits to ensure maximum reliability and compact raceway fill. All equipment grounding conductors are 100% copper per EDS-26 § 3.2.
- **Size Standardization Gate (EDS-26 § 3.4.2):** The completed design utilizes exactly **THREE** distinct phase-conductor sizes larger than #1 AWG across the entire facility: **500 kcmil**, **350 kcmil**, and **250 kcmil**. This strictly complies with the project cap of not more than five distinct large sizes.
- **Roof Cable Tray CT-R1 Fill:** Sized for 1 set of 350 kcmil each for chillers CH-1 and CH-2, and 1 set of 250 kcmil each for RTU-1 and RTU-2. Total cable diameter sum is 8.23 inches (9.38 inches including EGCs), which occupies only 51.7% to 57.9% of the 16.20-inch maximum usable tray width (90% of 18 inches).

## 6. Installed Cost Ledger & Commercial Optimisation

The conductor package was cost-modeled directly with Cascadia 2026 unit prices and the P-4210 Unit Price Book:
- Conductor Gross Cost: $141,937.18
- Campus Quantity Break Discount (6% on conductor material and labour): $-8,516.23 (achieved because total conductor length of 38,352.0 ft exceeds the 38,000-ft campus threshold)
- Net Installed Conductor Cost: $133,420.95
- Termination Cost: $9,342.96
- Interior Raceway Cost: $48,116.00
- **Total Installed Package Cost: $190,879.91** (Material: $138,814.70, Labour: $52,065.21)
