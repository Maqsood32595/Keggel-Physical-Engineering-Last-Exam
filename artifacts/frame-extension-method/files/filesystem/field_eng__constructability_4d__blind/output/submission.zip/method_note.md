# Method Note — Frame Extension Over Occupied Ground Floor

## Governing Document

Where the issued project documents disagree with themselves, TWP-09 revision C governs.
TWP-09 clause 1.2 confirms that revision C supersedes revision B (marked SUPERSEDED and
not in force). The five adopted public criteria are 29 CFR 1926.451 (scaffolds),
29 CFR 1926.703 (cast-in-place concrete), 29 CFR 1926.250 (material storage),
29 CFR 1926.34 (means of egress), and 29 CFR 1926.1408 (power line safety). TWP-09
clause 6.1 establishes the shoring design load as slab self-weight plus 10 psf
formwork plus 50 psf (pump) or 75 psf (crane and bucket) construction live load, plus
15 psf protective deck where the space below remains in occupation.

## Striking and Reshoring Method

All slabs are struck at the mix's early-strike age — 7 days for M40-PUMP and 4 days
for M50-HE — with reshoring in place as the original shores are removed, as permitted
by 29 CFR 1926.703(b)(10) and TWP-09 clause 6.3. Reshoring uses RS-16 posts at 8 ft
centres in both directions per TWP-09 clause 6.4, and remains until the slab reaches
its full-strength age of 28 days per 29 CFR 1926.703(e)(2). Early striking frees
shore posts for the next level while reshoring (only 25% of zone area in the yard per
TWP-09 8.3) preserves shoring stock.

## Constraint That Governs Each Zone

The governing constraint varies by zone-lift:

- **Bands A-C, L2 (Z-A-N, Z-A-S, Z-B-N, Z-B-S, Z-C-N, Z-C-S):** Medium-duty scaffold
  (TWP-09 5.4, occupied below) and protective deck (15 psf added to shoring design
  load). Stair-core zones Z-A-N and Z-B-S share the single-stair-core-shored limit
  (TWP-09 7.3).

- **Band D, L2 (Z-D-N, Z-D-S):** Light-duty scaffold, pump-placed slab, 50 psf live
  load. Shoring at SP-16, 4.0 ft spacing.

- **Bands E-G, all levels (Z-E-N through Z-G-S):** Heavy-duty scaffold (TWP-09 5.3,
  crane and bucket placement), 75 psf live load. Shoring at SP-16, 3.5 ft spacing.

- **L3-L4, bands A-D:** Light-duty scaffold, pump-placed slab, 50 psf live load.
  No protective deck (space below not occupied).

- **L3-L4, bands E-G:** Heavy-duty scaffold, crane and bucket, 75 psf live load.

## Margins Applied

Shoring post selection checks design load per post against rated capacity with the
post's maximum extension exceeding the required extension (soffit minus lift base
minus 0.75 ft form depth). Scaffold height-to-base ratio is checked against the 4:1
limit; ties are placed at the closest horizontal member to the 4:1 height, repeated
at 26-ft intervals for scaffolds wider than 3 ft, with the top tie within 4:1 height
of the top. Crane radius is measured from standing position to zone centroid, with
rated capacity interpolated from the crane chart and verified above the heaviest pick.
Option 3 encroachment is adopted for the 34.5 kV overhead line with a 10 ft minimum
approach distance. Platform capacity is 4x the maximum intended load per 29 CFR
1926.451(a)(1), and guardrails are 42 in high (within the 38-45 in range) on all
open sides and ends.

## Attribution

The building design (storey elevations, column grid and sections, slab thickness, and
zone breakdown) is derived from the LivingBIM Dataset: As-designed and As-built
Dataset for an Academic Building including BIM 3d models, Point Clouds, and Panoramic
Images, DOI 10.5281/zenodo.17934615, licensed CC BY 4.0.
