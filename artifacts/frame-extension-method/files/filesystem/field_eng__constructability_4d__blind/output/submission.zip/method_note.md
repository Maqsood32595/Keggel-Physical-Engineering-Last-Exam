# Method Note

Initial placeholder draft.
