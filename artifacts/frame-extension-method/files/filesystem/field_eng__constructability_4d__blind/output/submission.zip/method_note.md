# Method Note

Initial draft.
