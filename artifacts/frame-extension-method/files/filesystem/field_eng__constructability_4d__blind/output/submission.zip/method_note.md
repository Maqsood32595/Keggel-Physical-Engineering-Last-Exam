# Construction Engineering Method Note — Three-Lift RC Frame Extension (`TWP-09` Rev C)

## 1. Governing Documents and Resolution of Corpus Disagreements

Where the project record set contains conflicting revisions or out-of-scope documents, strict authority and chronological precedence has been applied:

1. **Temporary Works Procedure (`rules/TWP-09_temporary_works_procedure.md` Revision C and `rules/TWP-09_parameters.csv` govern over `rules/TWP-09_rev_B_SUPERSEDED.md` Revision B):**
   - **Revision C** is the issued procedure in force; **Revision B** is marked `SUPERSEDED` and is excluded completely from design inputs and `constraint_register.csv`.
   - Specifically, Revision C tightens seven site-wide parameters relative to superseded Revision B:
     - Contract completion deadline: **250 days** (Rev C, Clause 3.3) vs. 310 days (Rev B).
     - Yard shoring stock capacity: **3,600.0 sf** of soffit (Rev C, Clause 8.3) vs. 4,500 sf (Rev B).
     - Yard scaffold stock capacity: **120.0 ft** of scaffold face (Rev C, Clause 8.3) vs. 160 ft (Rev B).
     - Maximum concurrent work gangs: **8 gangs** (Rev C, Clause 8.2) vs. 10 gangs (Rev B).
     - Tower crane daily shift capacity: **10.0 crane hours/day** (Rev C, Clause 8.1) vs. 12 crane hours/day (Rev B).
     - Reshore post grid spacing: **8.0 ft** centres in both directions using `RS-16` (Rev C, Clause 6.4) vs. 10 ft centres (Rev B).
     - Concrete full-strength age: **28 days** (Rev C, Clauses 2.3 & 6.3) vs. 21 days (Rev B).
     - Striking condition: Revision C revokes Revision B's allowance for un-reshored early striking and mandates immediate reshoring whenever forms and shores are removed at the concrete mix's early-strike age (`Clause 6.3`).
2. **Programme Takeoff (`programme/activity_list.csv` and `programme/precedence_index.csv` govern over `programme/SUPERSEDED_baseline_programme_revA.csv`):**
   - The issued `activity_list.csv` (294 activities across 42 zone-lifts) and `precedence_index.csv` (308 finish-to-start links) govern over `SUPERSEDED_baseline_programme_revA.csv`, which carried superseded 4-day `SHOR` durations (instead of 2 days) and omitted inter-lift scaffold strike-to-erect (`SCST -> SCAF`) dependencies.
3. **Exclusion of Out-of-Scope Method Statement (`method_statements/MS-14_facade_replacement_OTHER_SCOPE.md`):**
   - `MS-14` governs east-elevation curtain wall glazing replacement under a separate order in a subsequent season. Its mast-climbing platform, rope-access provisions, and 8-day cycle are excluded from this package and from `constraint_register.csv`.
4. **Adopted Public Criteria (`TWP-09` Section 1):**
   - Five OSHA construction standards are adopted in force alongside `TWP-09` Revision C: `29 CFR 1926.451` (Scaffolds, together with definitions in `29 CFR 1926.450`), `29 CFR 1926.703` (Cast-in-Place Concrete), `29 CFR 1926.250` (General Requirements for Storage), `29 CFR 1926.34` (Means of Egress), and `29 CFR 1926.1408` (Power Line Safety up to 350 kV, including Table A).

---

## 2. Striking and Reshoring Method Adopted

To satisfy the **250-day** completion deadline (`Clause 3.3`), the **3,600.0 sf** yard shoring soffit cap (`Clause 8.3`), the **120.0 ft** yard scaffold face cap (`Clause 8.3`), and the single shored stair-core egress limit (`Clause 7.3`), **early striking with immediate reshoring** is adopted across all 42 zone-lifts in accordance with `TWP-09` Clauses 2.3, 6.3, 6.4, and 8.3 and `29 CFR 1926.703(b)(10)`, `(e)(1)(i)`, and `(e)(2)`:

- **Early-Strike Curing Age (`catalogue/concrete_mix_schedule.csv`):**
  - **Bands A to D (`M40-PUMP`, 4,000 psi pumped mix):** Primary formwork and `SP-16` shores remain in place for **7 days** after slab placement finishes (`STRK.start_day = POUR.finish_day + 7`).
  - **Bands E to G (`M50-HE`, 5,000 psi high-early crane-and-bucket mix):** Primary formwork and `SP-16` shores remain in place for **4 days** after slab placement finishes (`STRK.start_day = POUR.finish_day + 4`).
- **Immediate Reshoring (`RS-16` at `8.0 ft` Centres):**
  - As original forms and `SP-16` shores are struck on `install_day = STRK.start_day`, each slab is immediately reshored using `RS-16` posts (`16.0 ft` max extension, `6,000 lb` capacity, `4` cost units/post) on an `8.0 ft x 8.0 ft` grid (`64.0 sf` tributary area per post, `reshore.posts = ceil(area_sf / 64.0)`).
  - Reshores remain in place until the supported slab reaches its **28-day** full-strength age (`remove_day = POUR.finish_day + 28`). During the reshoring period, each reshored zone occupies **25 percent** (`0.25 * area_sf`) of its plan area in the site yard shoring stock (`Clause 8.3`).
  - In addition, no upper lift (`L3` or `L4`) commences activity occupation in any zone until the slab of the lift below has both completed `SCST` and reached its full 28-day curing age (`remove_day`), eliminating multi-level vertical reshore accumulation.

---

## 3. Governing Constraints by Zone and Lift

Each zone and lift is governed by specific structural, geometric, occupational, and site-access constraints from the corpus:

1. **Shore Post Extension across All Zones (`L2`, `L3`, `L4` — `Clause 6.1`):**
   - Subtracting the `0.75 ft` form assembly depth from the clear storey height (`14.576 ft` on `L2`/`L4`; `14.586 ft` on `L3`) yields a required shore extension of **`13.826 ft`** (`L2`/`L4`) and **`13.836 ft`** (`L3`). This disqualifies `SP-09` (`9.0 ft`) and `SP-13` (`13.0 ft`), making **`SP-16`** (`16.0 ft` max extension, `6,000 lb` rated capacity, `5` units) the governing shore post for every zone-lift.
2. **Ground-Floor Occupied Zones (`L2-Z-A-N`, `L2-Z-A-S`, `L2-Z-B-N`, `L2-Z-B-S`, `L2-Z-C-N`, `L2-Z-C-S` — `Clauses 5.4 & 6.1`):**
   - Because the ground floor of Bands A to C remains in occupation throughout construction (`site/existing_occupation.csv`), these six `L2` zone-lifts require a `15.0 psf` protective deck and a **medium-duty** access scaffold (`1,000 lb/bay`).
   - Combined with the `25.0 in` slab self-weight (`312.6 psf`), formwork (`10.0 psf`), and pumped live load (`50.0 psf`), the governing shoring design load is **`387.6 psf`**. At `4.0 ft` spacing the post load would be `6,201.60 lb > 6,000 lb`; therefore a **`3.5 ft` shore grid** governs (`4,748.10 lb/post <= 6,000 lb`).
   - For the medium-duty scaffold (`4 x 1,000 = 4,000 lb` required capacity), **3 `PL-95` planks per bay** (`28.5 in >= 18 in` width, `4,500 lb >= 4,000 lb` capacity) on system **`SF-3`** (`3.0 ft = 36 in` base width) govern.
3. **Unoccupied Pumped Zones (`L2-Z-D-N`, `L2-Z-D-S`, and `L3`–`L4` Bands A to D — `Clauses 5.1 & 6.1`):**
   - Without an occupied floor directly beneath the shoring, the shoring design load is **`372.6 psf`** (`312.6 + 10.0 + 50.0 psf`), permitting a **`4.0 ft` shore grid** (`5,961.60 lb/post <= 6,000 lb`).
   - The access scaffold is **light duty** (`750 lb/bay`, `4 x 750 = 3,000 lb` required capacity), governed by **2 `PL-95` planks per bay** (`19.0 in >= 18 in` width, `3,000 lb` capacity) on system **`SF-3`**.
4. **Crane-and-Bucket Placed Zones (`L2`, `L3`, `L4` Bands E to G: `Z-E-N` to `Z-G-S` — `Clauses 5.3 & 6.1`):**
   - Located east of the concrete pump's reach (`x >= 110.0 ft`), these 18 zone-lifts are placed by crane and bucket (`M50-HE`), imposing a `75.0 psf` construction live load and requiring a **heavy-duty** scaffold (`1,750 lb/bay`).
   - The governing shoring design load is **`397.6 psf`** (`312.6 + 10.0 + 75.0 psf`), requiring a **`3.5 ft` shore grid** (`4,870.60 lb/post <= 6,000 lb`, as `4.0 ft` yields `6,361.60 lb > 6,000 lb`).
   - The heavy-duty scaffold requires `4 x 1,750 = 7,000 lb` platform capacity, governing **5 `PL-95` planks per bay** (`7,500 lb >= 7,000 lb` capacity, `47.5 in` width). Because `47.5 in` exceeds `SF-3`'s `36 in` base width and `7,000 lb` exceeds `SF-3`'s `6,000 lb` leg capacity, system **`SF-5`** (`5.0 ft = 60 in` base width, `10,000 lb` leg capacity) governs all Band E–G zone-lifts.
5. **Stair-Core Egress Zones (`Z-A-N`, `Z-B-S`, `Z-E-S` on `L2`, `L3`, `L4` — `Clause 7.3` & `29 CFR 1926.34`):**
   - Two unobstructed means of egress must remain open on every level at all times, so **no more than 1 stair-core zone may be shored on any day**. All 9 stair-core zone-lifts are scheduled strictly in series with zero shoring overlap.
6. **Heavy Column Pick Zones (`Z-D-N` and `Z-D-S` — `Clause 9.1`):**
   - `Z-D-N` and `Z-D-S` carry `30" x 30"` precast columns weighing **`13,665.0 lb`** (`L2`, `L4`) and **`13,674.0 lb`** (`L3`), compared to `8,746.0`–`8,752.0 lb` (`24" x 24"`) in all other zones. Standing positions `CP-W` (radius `104.88 ft`, capacity `9,444.4 lb`) and `CP-E` (radius `102.91 ft`, capacity `9,748.7 lb`) cannot lift `Z-D-N`. Central standing position **`CP-C` (`98.0, 118.0 ft`)** gives radius `78.55 ft` and capacity `16,114.4 lb >= 13,674.0 lb` for `Z-D-N`, and satisfies all 14 zones within a maximum radius of `105.14 ft <= 140.0 ft`.
7. **Upper-Lift Access Scaffolds (`L3` at `35.42 ft`, `L4` at `52.08 ft` — `Clauses 4.4 & 4.6`):**
   - Exceeding the `35.0 ft` ladder rest-platform interval (`29 CFR 1926.451(e)(2)(iii)`), all `L3` and `L4` scaffolds carry **`2` platform levels** (compared to `1` on `L2` at `18.75 ft`).
   - Where `height_to_base_ratio > 4.0`, ties (`TIE-1`) are placed at `2` horizontal columns (`face_length_ft <= 30.0 ft`) at frame-header elevations `[13.0]` ft (`L2` `SF-3`), `[13.0, 32.5]` ft (`L3` `SF-3`), `[13.0, 32.5, 52.0]` ft (`L4` `SF-3`), `[19.5]` ft (`L3` `SF-5`), and `[19.5, 45.5]` ft (`L4` `SF-5`), while `L2` `SF-5` (`ratio = 3.75 <= 4.0`) requires no ties.
8. **Lateral Stability (`Clause 6.2`):**
   - In all 42 zone-lifts, the **2% notional lateral load** (`6,025.63 lb` in `L2-Z-A-S` up to `9,511.70 lb` in `L2-Z-B-N`) governs over the `12.0 psf` wind load (`844.80` to `1,450.80 lb`). Where an adjacent zone at the same level has completed `POUR` and cured to its early-strike age before `SHOR.start_day` (25 of 42 zone-lifts), the completed **`adjacent_diaphragm`** (`braced_bays = 0`) provides lateral restraint; for the remaining 17 zone-lifts, **`temporary_bracing`** (`XB-1` at `4,000 lb/bay`: `3` bays = `12,000 lb` in `Z-B-N`/`Z-B-S`, `2` bays = `8,000 lb` elsewhere) is installed.

---

## 4. Engineering and Resource Margins Applied

| Governing Criterion | Clause / Standard | Limit | Declared Design / Programme Value | Applied Safety Margin |
|---|---|---|---|---|
| Programme completion day | `TWP-09` 3.3 | `<= 250` days | **Day 198** (last `SCST`); **Day 217** (last reshore removal) | **52 days** (activities) / **33 days** (reshores) |
| Daily tower crane shift hours | `TWP-09` 8.1 | `<= 10.0` hr/day | **9.65 hr/day** peak | **0.35 hr/day** (`3.5%`) |
| Concurrent active gangs | `TWP-09` 8.2 | `<= 8` gangs | **7 gangs** peak | **1 gang** (`12.5%`) |
| Yard shoring + reshoring stock | `TWP-09` 8.3 | `<= 3,600.0` sf | **3,551.83 sf** peak (even with strike-day overlap) | **48.17 sf** (`1.34%`) |
| Yard scaffold face stock | `TWP-09` 8.3 | `<= 120.0` ft | **115.83 ft** peak | **4.17 ft** (`3.48%`) |
| Site material laydown stock | `TWP-09` 8.4 | `<= 16` units | **15 units** peak | **1 unit** (`6.25%`) |
| Shored stair-core zones | `TWP-09` 7.3 / `1926.34` | `<= 1` zone/day | **1 zone/day** (with `>= 1` day buffer between cores) | **0 overlap** (`+1 day` buffer) |
| Shore post load (`SP-16`) | `TWP-09` 6.1 / `1926.703` | `<= 6,000.0` lb | **4,748.10 lb** (`3.5 ft` occ), **4,870.60 lb** (`3.5 ft` bucket), **5,961.60 lb** (`4.0 ft` pump) | **38.40 lb to 1,251.90 lb** |
| Shore post extension (`SP-16`) | `TWP-09` 6.1 | `>= 13.836` ft | **16.00 ft** max extension | **2.164 ft** (`15.6%`) |
| Scaffold platform width | `TWP-09` 4.2 / `1926.451(b)(2)` | `>= 18.0` in | **19.0 in** (light), **28.5 in** (medium), **47.5 in** (heavy) | **1.0 in to 29.5 in** |
| Scaffold platform capacity | `TWP-09` 4.1 / `1926.451(a)(1)` | `>= 4x` intended load | **3,000 lb** (`4x750`), **4,500 lb** (`>= 4x1000`), **7,500 lb** (`>= 4x1750`) | **0 lb to 500 lb** above `4x` |
| Front edge gap (no inner rail) | `TWP-09` 4.3 / `1926.451(b)(3)` | `<= 14.0` in | **12.0 in** | **2.0 in** |
| Guardrail toprail height | `TWP-09` 4.7 / `1926.451(g)(4)(ii)` | `38.0` to `45.0` in | **42.0 in** | **4.0 in** above min / **3.0 in** below max |
| Mudsill ground bearing pressure | `TWP-09` 4.5 / `1926.451(c)(2)` | `<= 2,000.0` psf | **517.50 to 1,496.00 psf** | **504.00 to 1,482.50 psf** |
| Crane pick capacity at `CP-C` | `TWP-09` 9.1 | `>= heaviest_pick_lb` | **9,403.2 lb** vs `8,752 lb` (`Z-A-N`); **16,114.4 lb** vs `13,674 lb` (`Z-D-N`) | **651.2 lb to 29,254.0 lb** |
| Power line demarcated radius | `TWP-09` 9.2 / `1926.1408` | `105.14 <= R <= 145.0` ft | **140.0 ft** (`15.0 ft` clearance to `34.5 kV` line vs `10.0 ft` Table A min) | **5.0 ft** extra line clearance |

---

## 5. Attribution

The building in this corpus — its storey elevations, its column grid and sections, its slab thickness and its stair cores — is derived from:

> LivingBIM Dataset: As-designed and As-built Dataset for an Academic Building including BIM 3d models, Point Clouds, and Panoramic Images.
> DOI `10.5281/zenodo.17934615`. Licensed under **CC BY 4.0**.
