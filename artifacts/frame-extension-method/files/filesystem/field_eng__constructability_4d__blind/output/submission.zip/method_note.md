# Engineering Method Note — Three-Lift Reinforced Concrete Frame Extension Over an Occupied Ground Floor

**Project Package**: Three-Lift Frame Extension (`L2`, `L3`, `L4` across Bands `A`–`G`, Strips `N`/`S` — 42 Zone-Lifts, 294 Activities)  
**Qualified Temporary Works Designer**: A. Rivera, PE — Principal Temporary Works Engineer  
**Drawing Reference**: `TWP-09-DWGS-REV-C` (Sheets `TW-101` to `TW-142`, Formwork, Shoring, Reshoring, Access Scaffold & Crane Layout)

---

## 1. Governing Documents and Resolution of Disagreements in the Issued Set

Where documents in the project record set disagree, chronological and procedural authority governs as follows:

1. **Temporary Works Procedure `TWP-09` Revision C vs. Revision B (`SUPERSEDED`)**:
   - **`rules/TWP-09_temporary_works_procedure.md` (Revision C)** and its parameter schedule **`rules/TWP-09_parameters.csv`** are the issued governing site procedure in force. They explicitly supersede **`rules/TWP-09_rev_B_SUPERSEDED.md` (Revision B)**, which is retained only for historical reference to superseded shop copies and is strictly excluded from design and constraint registration.
   - Specifically, Revision C governs on all seven conflicting parameters:
     - **Contract completion deadline**: **250 days** from day 0 (Clause 3.3), superseding 310 days in Revision B.
     - **Yard stock limits**: **3,600.0 sf** of soffit shoring and **120.0 ft** of scaffold face (Clause 8.3), superseding 4,500 sf and 160 ft in Revision B.
     - **Gang cap**: **8 concurrent gangs** / active activities per day (Clause 8.2), superseding 10 gangs in Revision B.
     - **Tower crane shift capacity**: **10.0 crane hours per day** (Clause 8.1), superseding 12 crane hours in Revision B.
     - **Reshoring grid spacing**: **8.0 ft centres** in both directions using `RS-16` posts (Clause 6.4), superseding 10 ft centres in Revision B.
     - **Full-strength concrete age**: **28 days** (Clauses 2.3 and 6.3), superseding 21 days in Revision B.
     - **Early striking condition**: Forms and shores may be struck at the mix's early-strike age (`7 days` for `M40-PUMP`, `4 days` for `M50-HE`) **only where the slab is reshored as the original shores are removed** (Clause 6.3 and `29 CFR 1926.703(b)(10)`), superseding Revision B's permission to strike early without reshoring.
2. **Issued Activity List vs. Baseline Programme Revision A (`SUPERSEDED`)**:
   - **`programme/activity_list.csv`** and **`programme/precedence_index.csv`** govern all 294 activity durations, crane hours, and logic links (including 2-day `SHOR` durations), superseding **`programme/SUPERSEDED_baseline_programme_revA.csv`** (which carried 4-day `SHOR` durations and is not in force).
3. **Exclusion of Out-of-Scope Facade Package (`MS-14`)**:
   - **`method_statements/MS-14_facade_replacement_OTHER_SCOPE.md`** governs a separate east-elevation curtain wall replacement contract above Level 3 (using mast-climbing platforms, rope access, and an 8-day cycle) and forms no part of this frame extension package.
4. **Adopted Public Regulatory Standards**:
   - In accordance with `TWP-09` Revision C, the five adopted federal standards in force are **`29 CFR 1926.451`** (*Scaffolds — General requirements*, shipped print through paragraph `(g)(4)(ii)` together with definitions in **`29 CFR 1926.450`**), **`29 CFR 1926.703`** (*Requirements for cast-in-place concrete*), **`29 CFR 1926.250`** (*General requirements for storage*), **`29 CFR 1926.34`** (*Means of egress*), and **`29 CFR 1926.1408`** (*Power line safety up to 350 kV — equipment operations*).

---

## 2. Striking and Reshoring Method Adopted

To satisfy the 250-day completion date under the tight **3,600.0 sf** yard shoring soffit limit and minimize total zone-lift price under Clause 10.2 (`4.0 cost units/day`), we adopt **early striking with immediate reshoring** (`reshore.required = "yes"`) across all 42 zone-lifts in accordance with `TWP-09` Clauses 2.3, 6.3, 6.4, and 8.3 and `29 CFR 1926.703(b)(10)`, `(e)(1)(i)`, and `(e)(2)`:

1. **Primary Shoring (`SP-16`)**:
   - Lift clear heights are `14.576 ft` (`L2`, `L4`) and `14.586 ft` (`L3`). Subtracting the `0.75 ft` formwork assembly depth (Clause 6.1) yields required shore extensions of `13.826 ft` (`L2`, `L4`) and `13.836 ft` (`L3`), which exceed `SP-09` (`9.0 ft`) and `SP-13` (`13.0 ft`). We therefore select **`SP-16`** (`max_extension_ft = 16.0 ft`, `rated_capacity_lb = 6,000 lb`, `cost_units = 5`) for all 42 zone-lifts.
2. **Early-Strike Ages**:
   - **Bands A to D (`M40-PUMP`, 4,000 psi pump mix)**: Primary formwork and `SP-16` shores are struck at the **7-day** early-strike age (`STRK.start_day = POUR.finish_day + 7`).
   - **Bands E to G (`M50-HE`, 5,000 psi high-early mix)**: Primary formwork and `SP-16` shores are struck at the **4-day** early-strike age (`STRK.start_day = POUR.finish_day + 4`).
3. **Reshoring Installation and Removal (`RS-16` at 8.0 ft Centres)**:
   - As original `SP-16` shores are removed on `install_day = STRK.start_day`, **`RS-16`** reshore posts (`max_extension_ft = 16.0 ft`, `rated_capacity_lb = 6,000 lb`, `cost_units = 4`) are installed on an **8.0 ft × 8.0 ft** grid (`64.0 sf` tributary area per post, `posts = ceil(area_sf / 64.0)` = 13 to 20 posts per zone-lift).
   - Reshores remain in place until the supported slab reaches its **28-day full-strength age** (`remove_day = POUR.finish_day + 28`), occupying `25%` (`0.25 × area_sf`) of the zone's soffit area in the yard stock during `[install_day, remove_day)`.
   - Economic trade-off: Installing 13 to 20 `RS-16` posts costs `52 to 80 units` per zone-lift, whereas holding primary shores for 28 days would delay each zone-lift by 21 to 24 days (`84 to 96 units` direct duration cost per lift plus severe cascading delays across upper lifts and shared yard stock).

---

## 3. Governing Constraints by Zone and Level

Each zone and level is governed by a distinct combination of occupancy, placement, lifting, geometric, egress, and electrical clearance constraints:

1. **Level L2 Bands A to C (`L2-Z-A-N`, `L2-Z-A-S`, `L2-Z-B-N`, `L2-Z-B-S`, `L2-Z-C-N`, `L2-Z-C-S`) — Occupied Ground Floor Below**:
   - Governed by continued ground-floor occupancy (`site/existing_occupation.csv`, Clauses 5.4 and 6.1).
   - **Shoring**: Requires a `15.0 psf` protective deck in addition to slab self-weight (`312.6 psf`), formwork (`10.0 psf`), and pump live load (`50.0 psf`), giving `q_shor = 387.6 psf`. At `4.0 ft` spacing, post load (`6,201.6 lb`) would exceed the `6,000 lb` rating of `SP-16`; therefore **`3.5 ft` spacing** (`design_load_per_post_lb = 4,748.1 lb <= 6,000 lb`) governs.
   - **Scaffold**: Clause 5.4 mandates **medium-duty** scaffolding (`maximum_intended_load_lb = 1,000 lb/bay`, requiring `4 × 1,000 = 4,000 lb` plank capacity under Clause 4.1). Using **`SF-3`** (`3.0 ft = 36 in` base width, `7.0 ft` bay length) with **3 `PL-95` planks per bay** (`9.5 in` wide, `1,500 lb` capacity each) provides `4,500 lb >= 4,000 lb` capacity, `28.5 in >= 18 in` platform width, and a residual gap of `36.0 - 28.5 = 7.5 in <= 9.5 in` (`29 CFR 1926.451(b)(1)(ii)`).
2. **Level L2 Band D (`L2-Z-D-N`, `L2-Z-D-S`) and Levels L3 & L4 Bands A to D (`L3/L4-Z-A-N` to `Z-D-S`) — Pump Placement Without Occupied Space Below**:
   - **Shoring**: Placed by concrete pump without protective deck (`q_shor = 312.6 + 10.0 + 50.0 = 372.6 psf`). Governed by **`4.0 ft` shore spacing** (`design_load_per_post_lb = 5,961.6 lb <= 6,000 lb`), minimizing shore post count and cost.
   - **Scaffold**: Governed by **light-duty** classification (`750 lb/bay`, requiring `3,000 lb` plank capacity) and the `29 CFR 1926.451(b)(1)(ii)` full-planking gap limit (`<= 9.5 in`), which requires **3 `PL-95` planks per bay** (`28.5 in` width, `7.5 in` residual gap, `4,500 lb` capacity) on **`SF-3`** frames.
3. **Band D (`Z-D-N`, `Z-D-S` on `L2`, `L3`, `L4`) — Heaviest Precast Column Picks**:
   - Governed by the `30" × 30"` precast columns (`C-*-089-020` in `Z-D-N` and `C-*-089-071` in `Z-D-S`), which are the heaviest picks on site: **`13,665.0 lb`** (`L2`, `L4`) and **`13,674.0 lb`** (`L3`).
   - Standing positions `CP-W` and `CP-E` fail to lift `Z-D-N` (`9,444.4 lb` and `9,748.7 lb` rated capacity < `13,674.0 lb`, and out-of-radius `> 140 ft` on the opposite end of the building). Only the **central standing position `CP-C` (`x = 98.0 ft, y = 118.0 ft`)** satisfies all 42 zone-lifts, reaching `Z-D-N` at `78.55 ft` (`16,114.4 lb >= 13,674.0 lb`) and `Z-D-S` at `38.49 ft` (`38,000.0 lb >= 13,674.0 lb`).
4. **Bands E to G (`Z-E-N` to `Z-G-S` on `L2`, `L3`, `L4`) — Crane-and-Bucket Placement & Heavy-Duty Scaffold**:
   - Governed by Clause 5.3: East of Band D, concrete is placed by crane and bucket (`M50-HE`), imposing a **`75.0 psf` construction live load** (`q_shor = 312.6 + 10.0 + 75.0 = 397.6 psf`, requiring `SP-16` at **`3.5 ft` spacing** with `4,870.6 lb/post <= 6,000 lb`), high `POUR` crane demand (`7.95 to 9.49 crane hours` over 2 days), and **heavy-duty** scaffolding (`maximum_intended_load_lb = 1,750 lb/bay`).
   - Heavy-duty scaffolding requires `4 × 1,750 = 7,000 lb` plank capacity (`>= 5` `PL-95` planks = `47.5 in` minimum width), which cannot fit on `SF-3` (`36 in` width, `6,000 lb` leg capacity). Therefore, **`SF-5`** (`5.0 ft = 60 in` base width, `10,000 lb` leg ultimate capacity) with **6 `PL-95` planks per bay** (`platform_width_in = 57.0 in`, residual gap `60.0 - 57.0 = 3.0 in <= 9.5 in`, `platform_capacity_lb = 9,000 lb >= 7,000 lb`) governs all 18 zone-lifts in Bands E to G.
5. **Band B (`Z-B-N`, `Z-B-S`) & Band G (`Z-G-N`, `Z-G-S`) — Envelope & Lateral Demand Peaks**:
   - `Z-B-N` (`1,227.0 sf`) and `Z-B-S` (`1,177.8 sf`) have the largest slab areas (`30.0 ft` face = 5 scaffold bays, `5` laydown units) and highest lateral stability demands (`9,511.70 lb` and `9,130.31 lb` on `L2`, requiring 3 `XB-1` braced bays = `12,000 lb` capacity when temporarily braced).
   - `Z-G-N` and `Z-G-S` have `24.03 ft` exterior faces requiring `ceil(24.03 / 7.0) = 4` scaffold bays.
6. **Stair-Core Zones (`Z-A-N`, `Z-B-S`, `Z-E-S`) — Egress Continuity**:
   - Governed by Clause 7.3 and `29 CFR 1926.34(a), (c)`: two means of egress must remain open on every level at all times, so **no more than 1 stair-core zone** may be shored on any day. All 9 stair-core zone-lifts are sequenced strictly non-overlapping.
7. **Upper Lifts (`L3` at `35.42 ft`, `L4` at `52.08 ft`) — Vertical Workspace Exclusivity, Rest Platforms & Ties**:
   - Governed by Clause 7.2 (`L(k+1)` cannot start in a zone until `L(k).SCST` finishes) and Clause 4.6 / `29 CFR 1926.451(e)(2)(iii)` (scaffolds exceeding `35.0 ft` require rest platforms at `<= 35 ft` intervals, governing `platform_levels = 2` on all `L3` and `L4` scaffolds vs. `platform_levels = 1` on `L2` at `18.75 ft`).
   - Tie elevations (`Clause 4.4` and `29 CFR 1926.451(c)(1)(ii)`) are placed at frame horizontal members (`6.5 ft` multiples): `[13.0] ft` (`L2 SF-3`), `[13.0, 32.5] ft` (`L3 SF-3`), `[13.0, 32.5, 52.0] ft` (`L4 SF-3`), `[]` (`L2 SF-5`, where ratio `18.75 / 5.0 = 3.75 <= 4.0`), `[19.5] ft` (`L3 SF-5`), and `[19.5, 45.5] ft` (`L4 SF-5`).
8. **North Boundary Overhead Power Line (`OHL-1`, 34.5 kV)**:
   - Governed by Clause 9.2 and `29 CFR 1926.1408(a)(2)(iii)` (`option3`): `OHL-1` is an uninsulated `34.5 kV` line `155.0 ft` north of `CP-C`. Because the crane operated to its `140.0 ft` maximum radius could approach within `15.0 ft < 20.0 ft`, Option 3 is adopted with a Table A minimum clearance of **`10.0 ft`** (`up to 50 kV`) and a demarcated work zone radius of **`140.0 ft`** (`<= 155.0 - 10.0 = 145.0 ft` and `>= 105.14 ft` maximum zone centroid radius).

---

## 4. Engineering and Resource Margins Applied

| Governing Criterion | Clause / Standard | Limit | Designed / Peak Value | Safety Margin |
|---|---|---|---|---|
| Contract completion date | `TWP-09` 3.3 | `<= 250 days` | **205 days** | **45 days (18.0%)** |
| Daily tower crane shift | `TWP-09` 8.1 | `<= 10.00 hr/day` | **9.33 hr/day** | **0.67 hr/day (6.7%)** |
| Concurrent active gangs | `TWP-09` 8.2 | `<= 8 gangs` | **6 gangs** | **2 gangs (25.0%)** |
| Yard shoring + reshoring stock | `TWP-09` 8.3 | `<= 3,600.0 sf` | **3,320.2 sf** (3,546.2 sf w/ strike overlap) | **279.8 sf (7.8%)** |
| Yard scaffold face stock | `TWP-09` 8.3 | `<= 120.00 ft` | **117.03 ft** | **2.97 ft (2.5%)** |
| Site laydown area capacity | `TWP-09` 8.4 / `1926.250(a)(2)(i)` | `<= 16 units` | **12 units** | **4 units (25.0%)** |
| Stair-core zones shored | `TWP-09` 7.3 / `1926.34(a),(c)` | `<= 1 zone` | **1 zone** | **Zero overlap** |
| Shore post load (`SP-16`) | `TWP-09` 6.1 / `1926.703(a)(1)` | `<= 6,000 lb` | **4,564.35 to 5,961.60 lb** | **38.4 to 1,435.65 lb** |
| Shore post extension (`SP-16`) | `TWP-09` 6.1 | `<= 16.00 ft` | **13.826 to 13.836 ft** | **2.164 ft (13.5%)** |
| Scaffold plank capacity (`SF-3`) | `TWP-09` 4.1 / `1926.451(a)(1)` | `>= 3,000 / 4,000 lb` | **4,500 lb** (3 × `PL-95`) | **+500 to +1,500 lb** |
| Scaffold plank capacity (`SF-5`) | `TWP-09` 4.1 / `1926.451(a)(1)` | `>= 7,000 lb` | **9,000 lb** (6 × `PL-95`) | **+2,000 lb (28.6%)** |
| Platform width & residual gap | `TWP-09` 4.2 / `1926.451(b)(1)-(2)` | `>= 18 in`, gap `<= 9.5 in` | **28.5 in / 57.0 in**, gap **7.5 in / 3.0 in** | **+10.5 to +39.0 in width** |
| Mudsill ground bearing pressure | `TWP-09` 4.5 / `1926.451(c)(2)` | `<= 2,000.0 psf` | **540.0 to 1,541.0 psf** | **459.0 to 1,460.0 psf** |
| Lateral bracing / diaphragm | `TWP-09` 6.2 | `>= 5,794 to 9,512 lb` | **8,000 to 12,000 lb** (32 adj. diaphragm, 10 `XB-1`) | **+185 to +2,869 lb** |
| Crane pick capacity (`CP-C`) | `TWP-09` 9.1 | `>= 8,746 to 13,674 lb` | **9,403.2 to 38,000.0 lb** | **+651.2 to +29,254 lb** |
| Power line demarcated radius | `TWP-09` 9.2 / `1926.1408` Opt. 3 | `105.14 <= R <= 145.0 ft` | **140.0 ft** (`min_approach = 10.0 ft`) | **5.0 ft to Table A line** |

---

## 5. Attribution

The building in this corpus — its storey elevations, its column grid and sections, its slab thickness and its stair cores — is derived from:

> LivingBIM Dataset: As-designed and As-built Dataset for an Academic Building including BIM 3d models, Point Clouds, and Panoramic Images.  
> DOI `10.5281/zenodo.17934615`. Licensed under **CC BY 4.0** (Creative Commons Attribution 4.0 International).
