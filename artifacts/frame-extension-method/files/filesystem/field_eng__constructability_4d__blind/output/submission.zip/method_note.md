
# Method Note

This method note outlines the proposed construction sequence and temporary works design for the three-lift reinforced concrete frame extension over an occupied ground floor. The design of the permanent structure is fixed, and this package focuses on the buildability and temporary works, adhering strictly to the project specifications and regulatory requirements.

## Document Hierarchy and Discrepancies
In cases of conflicting information, the hierarchy of documents is as follows: `TWP-09_temporary_works_procedure.md` (Revision C) governs over its superseded Revision B and any other project-specific documents where it explicitly states precedence. Furthermore, specific OSHA regulations (e.g., 29 CFR 1926.451, 29 CFR 1926.703, 29 CFR 1926.250, 29 CFR 1926.34, 29 CFR 1926.1408) are adopted and take precedence in their respective scopes, as outlined in TWP-09. All parameters from `TWP-09_parameters.csv` are considered hard constraints derived directly from TWP-09.

## Striking and Reshoring Method
The concrete striking and reshoring strategy will follow the guidelines in TWP-09, Clause 6.3 and 6.4. Formwork and shores will not be removed until the concrete has achieved sufficient strength. If early striking is desired, which occurs at the concrete mix's early-strike age (as per `catalogue/concrete_mix_schedule.csv`), then immediate reshoring of the slab is mandatory as the original shores are removed. These reshores will be `RS-16` posts at an 8-foot grid in both directions and will remain in place until the supported slab reaches its full-strength age of 28 days. If early striking with reshoring is not utilized, forms and shores must remain in place until the slab reaches its full-strength age of 28 days. This approach ensures structural integrity throughout the concrete curing process and minimizes risks to personnel and the existing occupied floor below.

## Zone-Specific Constraints
Each zone-lift will be programmed to respect critical constraints, including but not limited to:
*   **Sequential Construction:** Only one zone-lift activity will be active in a given zone at any time (TWP-09, Clause 7.2).
*   **Occupancy:** The ground floor bands A to C will remain occupied, necessitating strict adherence to protective measures and load limits for temporary works directly above these areas (TWP-09, Clause 5.4, `site/existing_occupation.csv`).
*   **Stair Core Shoring:** A maximum of one stair-core zone can be shored on any given day to maintain egress (TWP-09, Clause 7.3).
*   **Crane Operations:** Crane use will be carefully planned to not exceed the daily 10 crane-hour limit (TWP-09, Clause 8.1) and to ensure safe clearances from the overhead power line, adhering to Option (3) of 29 CFR 1926.1408 with a demarcated radius (TWP-09, Clause 9.2).
*   **Yard Stock Limits:** Shoring and scaffold stock in the yard will be managed to stay within the 3600 sq ft soffit and 120 ft face limits, respectively (TWP-09, Clause 8.3).
*   **Laydown Area:** Staged materials will not exceed the 16-unit laydown capacity (TWP-09, Clause 8.4) and will be placed according to 29 CFR 1926.250(a)(2)(i) and (b)(1) requirements.

## Applied Margins
Safety factors and operational margins are incorporated into the temporary works design. For scaffolding, a safety factor of 4 times the maximum intended load will be used, as per 29 CFR 1926.451(a)(1) and TWP-09 Clause 4.1. Shoring designs will account for slab self-weight, formwork, construction live loads (50 psf for pump, 75 psf for crane/bucket), and protective deck loads (15 psf where applicable), with post capacities verified against `catalogue/shoring_catalogue.csv`. Lateral stability checks will consider the greater of 12 psf wind pressure or 2% of the vertical load, as per TWP-09 Clause 6.2. These margins ensure that all temporary structures can safely withstand anticipated and unforeseen loads, providing a robust and compliant construction environment.

