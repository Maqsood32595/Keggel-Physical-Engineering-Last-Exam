# Reconnaissance Summary (slice_01_recon)

## Project Objective
The primary objective is to act as the construction engineer for a three-lift reinforced concrete frame extension built over an occupied ground floor. This involves developing a comprehensive construction method package, encompassing the construction sequence and all necessary temporary works, while strictly adhering to design specifications, site-specific constraints, and regulatory requirements. The design of the permanent structure is fixed, but the construction methodology and temporary works are the responsibility of the engineer.

## Key Deliverables
The following six files must be generated and placed in the `output/` directory, and subsequently packaged into `output/submission.zip`:

1.  `construction_sequence.csv`: A detailed activity program including `activity_id`, `zone`, `level`, `activity_type`, `predecessors`, `duration_days`, `start_day`, `finish_day`, `crew`, `crane_hours`, and `workspace_volume_cf`. It must cover every zone-lift in the zone work schedule and every activity in the issued activity list.
2.  `stability_check.csv`: One row per zone-lift, verifying structural stability with columns `stage_id`, `zone`, `level`, `lateral_system` (must be `temporary_bracing` or `adjacent_diaphragm`), `demand_lb`, `capacity_lb`, and `verdict` (must be `pass` for satisfied checks).
3.  `occupancy_report.csv`: One row per zone-lift, detailing `zone_lift`, `zone`, `level`, `occupied_from_day`, `occupied_to_day`, `shored_from_day`, `shored_to_day`, `crane_hours_total`, and `laydown_units`. This report must align with the declared construction sequence.
4.  `temporary_works.json`: A single JSON object containing `designer`, `drawing_reference`, and `zone_lifts`. Each `zone_lift` entry will include detailed specifications for `shoring`, `reshore`, `scaffold`, `bracing`, and `crane` components, with specific fields as outlined in `task.md`.
5.  `constraint_register.csv`: Documents all applied requirements, with columns `requirement`, `document`, `clause`, `value`, `unit`, and `items_bound`. This register is subject to recall (0.55) and value-agreement (0.40) floors.
6.  `method_note.md`: A prose document of at least 200 words, describing the adopted construction method, striking/reshoring strategy, governing constraints for each zone, and applied margins.

## Hard-Gate Constraints and Critical Information Sources

### Design & Geometry:
*   **Source:** `model/` directory (e.g., `storey_schedule.csv`, `column_schedule.csv`, `slab_schedule.csv`, `zone_schedule.csv`, `grid_schedule.csv`, `L1_HW_IFC.ifc`, `L3_HW_IFC.ifc`).
*   **Constraints:** Fixed storey elevations, column grid and sections, slab thickness, and zone breakdown. These define the structural geometry and loads for temporary works design.

### Programme & Logistics:
*   **Source:** `programme/` directory (e.g., `activity_list.csv`, `zone_work_schedule.csv`, `precedence_index.csv`).
*   **Constraints:**
    *   `duration_days` must match issued durations exactly.
    *   `finish_day` must equal `start_day + duration_days`.
    *   All activities from `activity_list.csv` and all zone-lifts from `zone_work_schedule.csv` must be included.
    *   Unprogrammed work is charged against site-wide limits (crane hours, shored area, scaffold face, laydown units, gangs) at the busiest declared day.
    *   Dependencies from `precedence_index.csv` must be respected.

### Site Conditions:
*   **Source:** `site/` directory (e.g., `existing_occupation.csv`, `crane_chart.csv`, `crane_standing_positions.csv`, `overhead_services.csv`, `power_line_clearance_table_A.csv`).
*   **Constraints:**
    *   Ground floor bands A to C remain occupied throughout.
    *   One tower crane with specific `crane_chart.csv` and `crane_standing_positions.csv` data.
    *   One laydown area.
    *   Fixed number of gangs and yard capacity.
    *   Two means of egress must remain open on every level.
    *   Overhead line along the north boundary, requiring adherence to clearance rules (`power_line_clearance_table_A.csv`).

### Temporary Works Equipment & Procedures:
*   **Source:** `catalogue/` directory (e.g., `shoring_catalogue.csv`, `scaffold_catalogue.csv`, `scaffold_components.csv`, `scaffold_duty_classes.csv`, `shoring_grid_options.csv`, `concrete_mix_schedule.csv`).
*   **Source:** `rules/` directory (e.g., `TWP-09_temporary_works_procedure.md`, `TWP-09_parameters.csv`, 29 CFR regulations like `29_CFR_1926_451.md` for scaffolding, `29_CFR_1926_703.md` for concrete/masonry construction).
*   **Constraints:** All temporary works design (shoring, scaffolding, bracing, crane setup) must comply with specifications and capacities found in these documents. Specific parameters for scaffold (`base_width_ft`, `height_to_base_ratio`, `tie_levels_ft`, `guardrail_height_in`, `platform_width_in`, `platform_capacity_lb`, `maximum_intended_load_lb`, `front_edge_gap_in`, `bearing_pressure_psf`), shoring (`design_load_per_post_lb`, `spacing_ft`, `post_type`), and crane (`radius_ft`, `rated_capacity_lb`, `min_approach_ft`, `demarcated_radius_ft`) are critical. `access_means` and `fall_protection` in `temporary_works.json` have specific enumerated values.

### Verifier Tolerances (from `task.md`):
*   `shoring.design_load_per_post_lb`: 2 percent
*   `stability_check.csv` `demand_lb`: 5 percent
*   `scaffold.maximum_intended_load_lb`: exact
*   `workspace_volume_cf`: 5 percent
*   `occupancy_report.csv` `crane_hours_total`: 0.02 hours
*   `occupancy_report.csv` day columns and `laydown_units`: exact
*   `scaffold.platform_capacity_lb`: exact
*   `crane.rated_capacity_lb`: 2 percent
*   `crane.radius_ft`: 2 ft
*   `scaffold.height_ft`: 0.51 ft
*   `scaffold.height_to_base_ratio`: 0.05
*   `scaffold.tie_levels_ft`: half a frame lift
*   `duration_days` and `finish_day − start_day`: exact

## General Requirements
*   All CSV headers are matched case- and punctuation-insensitively.
*   Extra columns in CSVs are ignored.
*   `method_note.md` must be at least 200 words.
*   Attribution for LivingBIM Dataset (DOI 10.5281/zenodo.17934615, CC BY 4.0) must be included if reproducing design schedules.
*   The final submission is `output/submission.zip`, containing all six deliverables. It must be updated iteratively.
*   No verifier or evaluation data is available; rely solely on the brief and documents.
