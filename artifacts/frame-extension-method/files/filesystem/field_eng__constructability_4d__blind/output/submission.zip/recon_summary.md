# Reconnaissance & Constraints Extraction Summary (`recon_summary.md`)

## 1. Workspace Inventory & BIM/IFC Geometry Verification

A complete reconnaissance of `/filesystem/field_eng__constructability_4d__blind` was executed across all directories:

| Directory / File | Status | Description & Key Contents |
|---|---|---|
| `handover/instruction_to_engineer.md` | **ACTIVE** | Defines package scope, corpus structure, site occupation (ground floor bands A–C), single tower crane, laydown area, gang cap, yard stock, two means of egress, and north overhead power line. |
| `model/storey_schedule.csv` | **ACTIVE** | 3 extension lifts: `L2` (lift base 551.17 ft, soffit 565.746 ft, slab top 567.83 ft, clear height 14.576 ft, height above grade 18.75 ft, supported by `L1-existing-on-grade`), `L3` (lift base 567.83 ft, soffit 582.416 ft, slab top 584.50 ft, clear height 14.586 ft, height above grade 35.42 ft, supported by `L2`), `L4` (lift base 584.50 ft, soffit 599.076 ft, slab top 601.16 ft, clear height 14.576 ft, height above grade 52.08 ft, supported by `L3`). |
| `model/zone_schedule.csv` | **ACTIVE** | 14 plan zones across 7 West-to-East bands (`A` through `G`) and 2 North/South strips (`N`, `S`). Stair cores located in 3 zones: `Z-A-N`, `Z-B-S`, and `Z-E-S`. |
| `model/slab_schedule.csv` | **ACTIVE** | 42 zone-lift slabs (25.0 in thickness, 312.6 psf self-weight). Bands `A`–`D` use `M40-PUMP` (`pump`); Bands `E`–`G` use `M50-HE` (`crane_bucket`). |
| `model/column_schedule.csv` | **ACTIVE** | 78 precast columns across `L2`, `L3`, `L4` (26 column grid locations per level). 24"x24" columns weigh 8,746 lb (`L2`/`L4`) or 8,752 lb (`L3`); 30"x30" columns in `Z-D-N` (`C-*-089-020`) and `Z-D-S` (`C-*-089-071`) weigh 13,665 lb (`L2`/`L4`) or 13,674 lb (`L3`). |
| `model/grid_schedule.csv` | **ACTIVE** | Structural gridlines `X1` (21.555 ft) through `X8` (176.03 ft) and `A` (20.043 ft) through `F` (92.591 ft). |
| `model/L1_HW_IFC.ifc`, `model/L3_HW_IFC.ifc` | **ACTIVE** | Architect's IFC2X3 exports (LivingBIM Dataset, DOI 10.5281/zenodo.17934615, CC BY 4.0). Programmatic verification confirmed all 22 unique `IFCCOLUMN` entities in `L1_HW_IFC.ifc` and all 4 unique `IFCCOLUMN` entities in `L3_HW_IFC.ifc` referenced by `column_schedule.csv`. |
| `programme/activity_list.csv` | **ACTIVE** | 294 issued activities (7 activities per zone-lift × 42 zone-lifts: `COL`, `SCAF`, `SHOR`, `RBAR`, `POUR`, `STRK`, `SCST`) with fixed `duration_days`, `crane_hours`, and `predecessors`. |
| `programme/precedence_index.csv` | **ACTIVE** | 308 mandatory finish-to-start precedence relationships (252 intra-zone-lift links + 56 inter-lift links: `L(k).STRK -> L(k+1).COL` and `L(k).SCST -> L(k+1).SCAF`). |
| `programme/zone_work_schedule.csv` | **ACTIVE** | 42 zone-lifts with `area_sf`, `n_columns`, `heaviest_pick_lb`, `face_length_ft`, `scaffold_height_ft`, `clear_height_ft`, `mix_id`, `laydown_units`, and `wind_exposed_sf`. |
| `site/crane_chart.csv` | **ACTIVE** | Tower crane rated capacity curve from 40 ft (38,000 lb) to 140 ft (5,000 lb). |
| `site/crane_standing_positions.csv` | **ACTIVE** | 3 candidate positions at `y = 118.0 ft`, `max_radius_ft = 140 ft`, `distance_to_power_line_ft = 155.0 ft`: `CP-W` (`x = 30.0 ft`), `CP-C` (`x = 98.0 ft`), `CP-E` (`x = 166.0 ft`). |
| `site/existing_occupation.csv` | **ACTIVE** | 6 zone-lifts with occupied ground floor space below requiring a protective deck (`15 psf`) and medium-duty scaffold (`1,000 lb/bay`): `L2-Z-A-N`, `L2-Z-A-S`, `L2-Z-B-N`, `L2-Z-B-S`, `L2-Z-C-N`, `L2-Z-C-S`. |
| `site/overhead_services.csv` & `power_line_clearance_table_A.csv` | **ACTIVE** | `OHL-1`: uninsulated 34.5 kV overhead distribution line along north boundary, 155.0 ft from crane standing positions. Table A minimum clearance for up to 50 kV is `10 ft`. |
| `catalogue/*.csv` | **ACTIVE** | Component catalogs for concrete mixes (`M40-PUMP`, `M50-HE`), scaffold systems (`SF-3`, `SF-5`, `SF-7`), scaffold components (`PL-95`, `TIE-1`, `XB-1`), scaffold duty classes (`light`, `medium`, `heavy`), shoring posts (`SP-09`, `SP-13`, `SP-16`, `SP-20`, `RS-16`), and shoring grids (`3.0`, `3.5`, `4.0`, `4.5`, `5.0 ft`). |
| `rules/TWP-09_temporary_works_procedure.md` & `TWP-09_parameters.csv` | **ACTIVE** | Governing Temporary Works Procedure **Revision C** and its 31-row parameter schedule. |
| `rules/29_CFR_1926_*.md` | **ACTIVE** | Adopted federal safety standards: `29 CFR 1926.451` (print runs through `(g)(4)(ii)`), `29 CFR 1926.450`, `29 CFR 1926.703`, `29 CFR 1926.250`, `29 CFR 1926.34`, and `29 CFR 1926.1408`. |
| `rules/TWP-09_rev_B_SUPERSEDED.md` | **SUPERSEDED** | Superseded Revision B of TWP-09. **Excluded** from active design and constraint register. |
| `programme/SUPERSEDED_baseline_programme_revA.csv` | **SUPERSEDED** | Superseded baseline programme Revision A (4-day `SHOR` durations). **Excluded**. |
| `method_statements/MS-14_facade_replacement_OTHER_SCOPE.md` | **OUT OF SCOPE** | Separate contract package for east elevation curtain wall replacement above L3 (mast-climbing platform, rope-access, 8-day cycle). **Excluded**. |

---

## 2. Authority & Chronological Precedence Resolution

1. **TWP-09 Revision C vs. Revision B (`SUPERSEDED`)**:
   - **TWP-09 Revision C** explicitly supersedes Revision B. All Revision B parameters are excluded from `constraint_register.csv` and design calculations:
     - Completion deadline: **250 days** (Rev C, Clause 3.3) vs. ~~310 days~~ (Rev B).
     - Yard stock limits: **3,600 sf** shoring soffit and **120 ft** scaffold face (Rev C, Clause 8.3) vs. ~~4,500 sf~~ and ~~160 ft~~ (Rev B).
     - Gang cap: **8 gangs** (Rev C, Clause 8.2) vs. ~~10 gangs~~ (Rev B).
     - Crane shift capacity: **10.0 crane hours/day** (Rev C, Clause 8.1) vs. ~~12 crane hours/day~~ (Rev B).
     - Reshoring grid spacing: **8.0 ft** centres using `RS-16` (Rev C, Clause 6.4) vs. ~~10 ft centres~~ (Rev B).
     - Full-strength concrete age: **28 days** (Rev C, Clauses 2.3 & 6.3) vs. ~~21 days~~ (Rev B).
     - Early striking rule: Forms and shores may be struck at early-strike age (`7 days` for `M40-PUMP`, `4 days` for `M50-HE`) **only where reshored (`RS-16` at 8 ft centres) as original shores are removed** (Rev C, Clause 6.3 & `29 CFR 1926.703(b)(10)`), whereas Rev B permitted un-reshored early strike.
2. **Issued Activity List (`programme/activity_list.csv`) vs. Baseline Programme Rev A (`SUPERSEDED`)**:
   - `programme/activity_list.csv` governs all activity durations (`SHOR` duration is `2 days`, not `4 days` as in superseded Rev A).
3. **Out-of-Scope Method Statement (`MS-14`)**:
   - `MS-14_facade_replacement_OTHER_SCOPE.md` applies to a separate east-elevation curtain wall contract and is strictly excluded from `constraint_register.csv`.
4. **Shipped Print Boundary of `29 CFR 1926.451`**:
   - The corpus print of `29 CFR 1926.451` explicitly runs through paragraph `(g)(4)(ii)`. No clauses beyond `(g)(4)(ii)` exist in the shipped document.

---

## 3. Atomic Sub-Clause Decomposition & Key Engineering Gates

All compound clauses and sub-clauses across `TWP-09` (Clauses `1.1`–`10.3`) and the adopted 29 CFR standards (`1926.450`, `1926.451`, `1926.703`, `1926.250`, `1926.34`, `1926.1408`) have been decomposed into **160 atomic rows** in `output/constraint_register.csv`, capturing both quantitative thresholds and qualitative completeness gates:

- **Joint Discrete Scaffold Plank Sizing (`TWP-09` 4.1, 4.2 & `29 CFR 1926.451(a)(1)`, `(b)(1)(i)-(ii)`, `(b)(2)`)**:
  - `PL-95` planks are `9.5 in` wide with `1,500 lb` ultimate capacity.
  - Under `29 CFR 1926.451(b)(1)` and `(b)(1)(ii)`, working platforms must be fully planked between uprights such that the residual open space `base_width_in - planks_per_bay * 9.5 <= 9.5 in`, simultaneously satisfying `planks_per_bay * 9.5 >= 18 in` (`(b)(2)`) and `planks_per_bay * 1500 >= 4 * maximum_intended_load_lb` (`(a)(1)`):
    - `SF-3` (`3.0 ft = 36 in` base width): requires `planks_per_bay = 3` (`platform_width_in = 28.5 in`, residual gap `7.5 in <= 9.5 in`, `platform_capacity_lb = 4,500 lb`, sufficient for `light` 3,000 lb and `medium` 4,000 lb).
    - `SF-5` (`5.0 ft = 60 in` base width): requires `planks_per_bay = 6` (`platform_width_in = 57.0 in`, residual gap `3.0 in <= 9.5 in`, `platform_capacity_lb = 9,000 lb`, sufficient for `heavy` 7,000 lb).
    - `SF-7` (`7.0 ft = 84 in` base width): requires `planks_per_bay = 8` (`platform_width_in = 76.0 in`, residual gap `8.0 in <= 9.5 in`, `platform_capacity_lb = 12,000 lb`).
- **Shoring Design Loads & Post Selection (`TWP-09` 6.1 & `29 CFR 1926.703(a)(1)`)**:
  - Required post extension: `L2` and `L4` require `14.576 - 0.75 = 13.826 ft`; `L3` requires `14.586 - 0.75 = 13.836 ft`. Only `SP-16` (`max_extension_ft = 16.0 ft`, `rated_capacity_lb = 6,000 lb`, cost `5 units`) and `SP-20` (`max_extension_ft = 20.0 ft`, `rated_capacity_lb = 4,200 lb`, cost `7 units`) satisfy the extension gate (`> 13.0 ft`).
  - Shoring design load `q_design`:
    - `L2` Bands `A`–`C` (pump + occupied protective deck): `312.6 + 10 + 50 + 15 = 387.6 psf`.
    - `L2` Band `D` and `L3`/`L4` Bands `A`–`D` (pump, no protective deck): `312.6 + 10 + 50 = 372.6 psf`.
    - `L2`, `L3`, `L4` Bands `E`–`G` (crane & bucket, no protective deck): `312.6 + 10 + 75 = 397.6 psf`.
  - At `spacing_ft = 3.5 ft` (`spacing^2 = 12.25 sf/post`) with `SP-16` (`6,000 lb` capacity):
    - `387.6 * 12.25 = 4,748.1 lb <= 6,000 lb`
    - `372.6 * 12.25 = 4,564.35 lb <= 6,000 lb`
    - `397.6 * 12.25 = 4,870.6 lb <= 6,000 lb`
- **Tower Crane Position & Power Line Clearance (`TWP-09` 9.1, 9.2 & `29 CFR 1926.1408`)**:
  - Central standing position `CP-C` (`x = 98.0 ft, y = 118.0 ft`) reaches every zone centroid within `67.1 ft to 96.4 ft` (`<= 140 ft` max radius), providing `>= 10,200 lb` rated capacity everywhere and `>= 20,256 lb` at `Z-D-N`/`Z-D-S` (where heaviest 30"x30" column pick is `13,674 lb`).
  - Under Option 3 (`option3`), `min_approach_ft = 10.0 ft` for the 34.5 kV line (`OHL-1` at `155.0 ft`), giving maximum demarcated radius `155.0 - 10.0 = 145.0 ft`.
