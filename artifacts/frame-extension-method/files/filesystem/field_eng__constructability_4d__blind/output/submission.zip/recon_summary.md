# Reconnaissance Summary

This document summarizes the key constraints and requirements extracted from the project documents, specifications, code, and catalogue files during the reconnaissance phase. The objective is to provide a comprehensive overview of the governing clauses, numerical parameters, and hard-gate limits that will inform the development of the construction sequence and temporary works design.

## General Project Constraints
*   **Method Package Deliverables:** The method package must include: construction sequence, temporary-works design, stability check sheet, workspace and resource occupancy report, constraint register, and method note (TWP-09, Clause 1.2).
*   **Program Completion Date:** The entire program must be completed by day 250 (TWP-09, Clause 3.3).
*   **Zone-Lift Definition:** A zone-lift encompasses one zone of one level, including its columns, slab, and associated temporary works (TWP-09, Clause 1.3).
*   **Activity Definitions:** Specific activities for a zone-lift include COL, SCAF, SHOR, RBAR, POUR, STRK, and SCST (TWP-09, Clause 2.1).
*   **Work Exclusions:** Activities not included in `construction_sequence.csv` will still be charged against site-wide limits at the busiest declared day (Task.md).
*   **Attribution:** Any reproduction from design schedules must include the LivingBIM Dataset attribution and CC BY 4.0 license (Task.md, Attribution).

## Scaffold-Related Constraints
*   **Scaffold Capacity:** Each scaffold and component must support its own weight and at least 4 times the maximum intended load (TWP-09, Clause 4.1; 29 CFR 1926.451(a)(1)).
*   **Platform Width:** Each scaffold platform and walkway must be at least 18 inches wide (TWP-09, Clause 4.2; 29 CFR 1926.451(b)(2)). Exceptions apply for specific scaffold types and narrow areas.
*   **Front Edge Distance:** The front edge of a platform must be no more than 14 inches from the face of the work, unless guardrails or personal fall arrest systems are used (TWP-09, Clause 4.3; 29 CFR 1926.451(b)(3)).
*   **Height to Base Width Ratio:** Scaffolds with a height to base width ratio greater than 4:1 must be restrained by guying, tying, or bracing (TWP-09, Clause 4.4; 29 CFR 1926.451(c)(1)).
*   **Tie Intervals:** Ties are required at specific vertical and horizontal intervals based on scaffold width and height (TWP-09, Clause 4.4; 29 CFR 1926.451(c)(1)(ii)).
*   **Mudsill Bearing Pressure:** Ground bearing pressure under a mud sill shall not exceed 2000 pounds per square foot (TWP-09, Clause 4.5).
*   **Access and Rest Platforms:** A means of access is required for platforms more than 2 feet above or below the point of access. Rest platforms are required at maximum 35-foot vertical intervals for scaffolds over 35 feet high (TWP-09, Clause 4.6; 29 CFR 1926.451(e)(1), (e)(2)(iii)).
*   **Fall Protection:** Employees on scaffolds more than 10 feet above a lower level must be protected from falling. Toprail height for guardrails must be between 38 and 45 inches (TWP-09, Clause 4.7; 29 CFR 1926.451(g)(1), (g)(4)(ii)).
*   **Plank Overlap:** Planks like PL-95 (10 ft long) must overlap over bearers on systems with shorter bays (TWP-09, Clause 4.8; 29 CFR 1926.451(b)(7)).
*   **Scaffold Duty Classes:** Duty class depends on the work served. Bands E to G (crane and bucket) require heavy duty. Occupied spaces with protective decks require medium duty (TWP-09, Clauses 5.3, 5.4).
*   **Scaffold Design:** Scaffolds must be designed by a qualified person (TWP-09, Clause 6.5; 29 CFR 1926.451(a)(6)).
*   **Scaffold Inspection:** Scaffolds must be inspected by a competent person before each work shift and after any event affecting structural integrity (29 CFR 1926.451(f)(3)).
*   **Platform Deflection:** Platforms must not deflect more than 1/60 of the span when loaded (29 CFR 1926.451(f)(16)).

## Shoring and Reshoring Constraints
*   **Formwork Design:** Formwork must be designed to carry all anticipated vertical and lateral loads without failure (TWP-09, Clause 6.1; 29 CFR 1926.703(a)(1)).
*   **Shoring Design Load:** Includes slab self-weight, 10 psf for formwork, 50 psf (pump) or 75 psf (crane/bucket) construction live load, and 15 psf for protective deck if applicable (TWP-09, Clause 6.1).
*   **Shoring Required Extension:** Height from lift base to soffit less 0.75 ft for form assembly depth (TWP-09, Clause 6.1).
*   **Shore Post Capacity:** Design load per post must not exceed the post's rated capacity (TWP-09, Clause 6.1).
*   **Lateral Stability:** Frame must resist greater of 12 psf wind pressure or 2% of vertical load. Achieved by temporary cross-bracing (XB-1) or adjacent diaphragm (TWP-09, Clause 6.2).
*   **Early Strike Condition:** Forms and shores can be struck at early-strike age *only if* the slab is reshored as original shores are removed. Otherwise, full-strength age (28 days) is required (TWP-09, Clause 6.3; 29 CFR 1926.703(e)(1)).
*   **Reshoring Specifications:** `RS-16` posts at 8 feet centers in both directions. Reshoring not removed until slab reaches full-strength age (TWP-09, Clause 6.4; 29 CFR 1926.703(e)(2)).
*   **Shoring Equipment Inspection:** Equipment must be inspected before erection, and immediately before, during, and after concrete placement (29 CFR 1926.703(b)(1), (b)(3)). Damaged equipment is not to be used or must be reinforced (29 CFR 1926.703(b)(2), (b)(4)).
*   **Tiered Shoring:** Requires design by a qualified designer, inspection by an engineer, vertical alignment, splicing to prevent misalignment, and bracing in two perpendicular directions (29 CFR 1926.703(b)(8)).

## Workspace and Resource Constraints
*   **Workspace Volume:** Volume occupied by activity plus temporary works (shoring, scaffold) (TWP-09, Clause 7.1).
*   **Zone-Lift Concurrency:** Only one zone-lift allowed per zone at a time (TWP-09, Clause 7.2).
*   **Stair Core Shoring:** Maximum of 1 stair-core zone shored per day (TWP-09, Clause 7.3).
*   **Crane Limit:** One tower crane available, 10 crane hours per shift (TWP-09, Clause 8.1).
*   **Gangs Limit:** Maximum of 8 gangs concurrently (TWP-09, Clause 8.2).
*   **Yard Stock:** 3600 sq ft for shoring soffit, 120 ft for scaffold face. Reshoring occupies 25% of zone area until full strength (TWP-09, Clause 8.3).
*   **Laydown Area:** 16 units capacity for staged material, not placed within 6 feet of floor opening (TWP-09, Clause 8.4; 29 CFR 1926.250(b)(1)).

## Crane and Overhead Line Constraints
*   **Crane Capacity:** Rated capacity at radius must exceed heaviest pick (TWP-09, Clause 9.1).
*   **Overhead Line Clearance:** 34.5 kV line on north boundary. Minimum approach distance (Table A from 29 CFR 1926.1408) to be used with Option (3): work zone demarcated to prevent closer approach than minimum approach distance (TWP-09, Clause 9.2). For 34.5 kV, Table A indicates 10 ft minimum clearance.

## Pricing
*   **Temporary Works Pricing:** Guardrail bay at 1 unit (TWP-09, Clause 10.1).
*   **Zone-Lift Program Cost:** 4 units per day from program start to its last activity finish (TWP-09, Clause 10.2).

## Tolerances
*   **Shoring design load:** 2 percent (Task.md).
*   **Stability check demand:** 5 percent (Task.md).
*   **Scaffold maximum intended load:** exact (Task.md).
*   **Workspace volume:** 5 percent (Task.md).
*   **Occupancy report crane hours:** 0.02 hours (Task.md).
*   **Occupancy report day columns and laydown units:** exact (Task.md).
*   **Scaffold platform capacity:** exact (Task.md).
*   **Crane rated capacity:** 2 percent (Task.md).
*   **Crane radius:** 2 ft (Task.md).
*   **Scaffold height:** 0.51 ft (Task.md).
*   **Scaffold height to base ratio:** 0.05 (Task.md).
*   **Scaffold tie levels:** half a frame lift (Task.md).
*   **Duration days:** exact (Task.md).
