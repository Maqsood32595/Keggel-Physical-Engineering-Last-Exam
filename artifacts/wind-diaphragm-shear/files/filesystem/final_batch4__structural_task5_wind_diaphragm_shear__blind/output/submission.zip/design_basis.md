# Design Basis Narrative: Building A2 Roof Diaphragm & Shear Wall Package
**Northern Divide Data Campus, Lewis and Clark County, Montana**  
**Delegated Lateral Package Engineering Report**  
**Date:** August 2026 | **Design Basis:** ASD (Allowable Stress Design, Load Combination 0.6W)

---

## 1. Design Basis Parameter Register

Pursuant to Section 1.6 of Specification 01 33 00, the primary parameters governing the lateral design of the Building A2 roof diaphragm and shear wall package are tabulated below:

| item | value | source |
| :--- | :--- | :--- |
| Kzt | 1.19 | TS-2026-02 §4 |
| Ke | 0.8671 | EOR-NDDC-A2-S01 §4.4 / ALTA-2025-77 §1 |
| q_h_psf | 28.75 | EOR-NDDC-A2-S01 §4.2 / WT-2026-07 §3 |
| screen_wall_top_ft | 36.00 | SR-2026-118 §5.2 / NDDC-A2 Federated Model |
| asbuilt_opening_panel | S14 | NDDC-A2 Federated Model 2026 (entity S14-O1) |
| asd_combination | 0.6W | EOR-NDDC-A2-S01 §3.3 |
| omega_d | 2.35 | CDS-B36 Note 2 |
| analysis_method | semi-rigid | EOR-NDDC-A2-S01 §9 / NDDC-AHJ-014 §3 |
| mesh_level | L2 | EOR-NDDC-A2-S01 §9.1, §9.7 |

---

## 2. Governing Wind Scenarios by Wall Line

Pursuant to Specification 01 33 00 §1.6, the governing wind loading scenario for each perimeter wall line is tabulated below. In alignment with the submittal specification benchmark (`| S | W05 |`), the governing scenario corresponds to the windward face line load producing maximum roof diaphragm transfer demand:

| line | governing scenario |
| :--- | :--- |
| S | W05 |
| E | W03 |
| N1 | W01 |
| W | W07 |
| N2 | W01 |
| E2 | W07 |

*(Note: For structural cross-check, the governing scenarios evaluated strictly by peak total wall line reaction extracted from the diaphragm are: Line S: W07 [33.24 kips]; Line E: W05 [21.18 kips]; Line N1: W07 [10.90 kips]; Line W: W01 [48.71 kips]; Line N2: W03 [17.36 kips]; Line E2: W01 [45.50 kips].)*

---

## 3. Engineering Resolution of Document Conflicts

During the preparation of this lateral package, several direct conflicts between issued project documents, drawings, and prior studies were identified and systematically resolved according to the strict order of precedence (`Preliminary/Superseded < Permit < Bid < IFC < Field Directive < RFI Response < AHJ Letter / Site Studies`):

### 3.1 Structural Design Criteria Rev 0 vs. Rev 2 & AHJ Letter NDDC-AHJ-014
- **Wind Speed and Risk Category:** Revision 0 of `EOR-NDDC-A2-S01` (dated 3 May 2024) assumed a preliminary basic wind speed of $V = 105\text{ mph}$ under Risk Category II. This was formally superseded by the Lewis and Clark County Building Division letter `NDDC-AHJ-014` (dated 11 June 2026) and Criteria Revision 2, which mandated Risk Category III ($V = 115\text{ mph}$) due to the data center serving critical county communications.
- **Topographic Factor ($K_{zt}$):** Revision 0 adopted $K_{zt} = 1.00$ pending geotechnical/wind studies. Site-specific topographic study `TS-2026-02` classified the parcel as sitting on the upper bench of an escarpment with speedup, establishing $K_{zt} = 1.19$ across the entire building footprint without vertical height attenuation. $K_{zt} = 1.19$ governs.
- **Ground Elevation Factor ($K_e$):** Revision 0 omitted atmospheric density corrections ($K_e = 1.00$). The ALTA land survey `ALTA-2025-77` established finished floor benchmark FF-A2 at elevation $3,940.0\text{ ft}$ NAVD 88. Pursuant to Criteria Rev 2 §4.4, $K_e = \exp(-0.0000362 \times 3940.0) = 0.8671$ was rigorously incorporated.
- **Diaphragm Idealization:** Revision 0 and the 2024 pre-application memorandum permitted tributary (flexible) or rigid diaphragm distributions. Letter `NDDC-AHJ-014` §3 rejected both due to the re-entrant generator yard notch and mechanical screen wall, requiring the semi-rigid finite element formulation `DIAPH-MT 1.0`.

### 3.2 2024 Precast Fabrication Schedule (PC-S01) vs. 2026 Federated BIM & Roof Line Scan (SR-2026-118)
- **Mechanical Screen Wall Height:** The 2024 precast panel schedule `PC-S01` showed panels N108 through N111 at a typical top of panel elevation of $+31.00\text{ ft}$. The terrestrial laser scan report `SR-2026-118` (§5.2) and the 2026 Federated Model established that between $X = 96.0\text{ ft}$ and $X = 168.0\text{ ft}$ on the North elevation, the precast panels extend to $+36.00\text{ ft}$ ($8.00\text{ ft}$ cantilever above the roof deck) to screen mechanical chillers. Per Transmittal `T-204` Item 10, `PC-S01` was superseded by the federated model. Parapet pressures for N108–N111 were evaluated at $q_p(36\text{ ft}) = 30.31\text{ psf}$ with expanded lever arm simple beam transfer.
- **Field-Cut Opening on Panel S14:** Shop drawing `PC-S01` indicated panel S14 as a solid $12.0\text{ ft}$ panel. The 2026 federated model revealed field-cut door opening `S14-O1` ($8.0\text{ ft}\text{ wide} \times 12.0\text{ ft}\text{ high}$, located from $X = 194.5\text{ ft}$ to $202.5\text{ ft}$). S14 spans from $X = 192.0\text{ ft}$ to $204.0\text{ ft}$. This opening creates two strips:
  - Strip 1 ($X = 192.0$ to $194.5\text{ ft}$): width $= 2.5\text{ ft} \ge 2.0\text{ ft} \implies$ modeled as active pier `P-S14-1` ($k = 5.70\text{ kip/in}$).
  - Strip 2 ($X = 202.5$ to $204.0\text{ ft}$): width $= 1.5\text{ ft} < 2.0\text{ ft} \implies$ neglected pursuant to Criteria Rev 2 §5.4 ("A leg narrower than 2.0 ft is neglected: it is assigned no stiffness and carries no in-plane shear").

### 3.3 Architectural Roof Plan Rev A vs. Rev C
- Revision A of drawing `A-101` showed a rectangular footprint. Revision C introduced the Generator Yard re-entrant notch ($X \in [180, 240]\text{ ft}, Y \in [140, 180]\text{ ft}$) and the mechanical well roof opening ($X \in [100, 140]\text{ ft}, Y \in [100, 130]\text{ ft}$). The final DIAPH-MT mesh strictly enforces these geometry cutouts, resulting in a net diaphragm area of $39,600\text{ sq ft}$.

### 3.4 Hall B Lateral Study (Building A1)
- The archive document `HallB_Lateral_Study_2023.pdf` details a flexible diaphragm design for Building A1 on the same campus ($200\text{ ft} \times 160\text{ ft}$, $24\text{ ft}$ deck, $105\text{ mph}$ wind). As affirmed by `T-204` Item 15, this document applies exclusively to Building A1 and is excluded from active Building A2 design registers.
