# Building A2 — Lateral Package Wind Design Basis Narrative

**Project:** Northern Divide Data Campus — Building A2  
**Location:** Lewis and Clark County, Montana  
**Code:** ASCE/SEI 7-22 / IBC 2024  
**Design Basis:** Allowable Stress Design (ASD)  

---

## 1. Primary Design Parameters

| Item | Value | Source |
| :--- | :---: | :--- |
| kzt | 1.19 | TS-2026-02 Topographic Wind Study §4 |
| ke | 0.867 | EOR-NDDC-A2-S01 §4.4 |
| q_h_psf | 28.75 | EOR-NDDC-A2-S01 §4.2 |
| screen_wall_top_ft | 36.0 | SR-2026-118 Roof Line Scan Report §5.2 |
| asbuilt_opening_panel | S14 | PC-S02 Precast Panel Elevations Rev 2 note 4 |
| asd_combination | 0.6D + 0.6W | EOR-NDDC-A2-S01 §3.3 |
| omega_d | 2.35 | CDS-B36 Diaphragm Design Manual Table 3 note 2 |
| analysis_method | semi-rigid | EOR-NDDC-A2-S01 §9.0 |
| mesh_level | L2 | EOR-NDDC-A2-S01 §9.1 |

---

## 2. Governing Wind Scenario per Wall Line

| Wall Line | Governing Scenario | Max Reaction (kips) |
| :--- | :---: | :---: |
| S | W02 | 39.6 |
| E | W04 | 24.2 |
| N2 | W06 | 24.3 |
| E2 | W02 | 38.8 |
| N1 | W08 | 34.3 |
| W | W01 | 54.2 |

---

## 3. Engineering Narrative & Conflict Resolutions
1. **Topographic Factor (Kzt = 1.19):** Topographic wind study TS-2026-02 identified ridge feature governing approach.
2. **Ground Elevation Factor (Ke = 0.867):** Site benchmark 3,940 ft yields velocity pressure qh = 28.75 psf.
3. **Screen Wall Parapet Lever (36.0 ft):** Wall line N1 parapet extends to 36.0 ft elevation.
4. **Field-Cut As-Built Panel (S14):** Enlarged generator yard opening accommodated on panel S14.
5. **Diaphragm Sizing & Deflection:** Zoned deck specification maintains stability and meets drift limits.
