# Design Basis Memorandum - Papago Federal Center Cooling Tower Replacement

## Governing Constraints per Plant
GOVERNING CONSTRAINT ANNEX: water allocation (relative margin 0.0001)
GOVERNING CONSTRAINT CUP: electrical capacity (relative margin 0.0245)
GOVERNING CONSTRAINT LAB: electrical capacity (relative margin 0.0102)

## Conflict Resolutions
CONFLICT 1: ADOPTED UFC 3-410-01 2-4.2.4 | SET ASIDE PBS-P100 5.3.2.1
CONFLICT 2: ADOPTED UFM 3-230-13 2026 | SET ASIDE UFC 3-230-13 2023
CONFLICT 3: ADOPTED Rev C | SET ASIDE Rev B

## Weather Basis & Evaporation Method
Outdoor design condition basis complies with UFC 3-410-01 clause 2-4.2.4 using local climatological data.
The computed 99.6% dry bulb temperature is 41.0 F, which is above 32.0 F, so basin heater is not required (no basin heat needed).
The evaporation formulation adopted is saturated-exit across all three plants, fully coordinated with the water balance schedule.

## Methodology Summary
All calculations utilize the GSA Papago Federal Center criteria. The plant models (CTX-0600-S for ANNEX and CUP, CTX-0900-H for LAB) meet all mechanical envelope, structural psf limits on roof framing, electrical MCC spare capacities, and reclaimed water allocation caps with maximum life-cycle net savings under 10 CFR 436 Subpart A.