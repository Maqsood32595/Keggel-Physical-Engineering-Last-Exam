#!/usr/bin/env python3
"""Complete deliverable generator for PCW flushing package."""
import math, json, csv, os, sys
sys.path.insert(0, '/filesystem/final_batch4__mechanical_task5_pcw_flush_mop__blind/output')
from compute import *
from collections import defaultdict

OUTDIR = '/filesystem/final_batch4__mechanical_task5_pcw_flush_mop__blind/output'

# ============================================================================
# CONFIGURATION (same as gen_all.py)
# ============================================================================
SKID_ASSIGN = {
    'C1': ['FS-1200-A'],
    'C2': ['FS-1200-A'],
    'C3': ['FS-1200-A'],
    'C4': ['FS-600-A'],
    'C5': ['FS-1200-A'],
    'C6': ['FS-600-B'],
    'C7': ['FS-600-A'],
    'C8': ['FS-600-B'],
}
CREW_A = 'CREW-A'
CREW_B = 'CREW-B'
N_F = 1
HOLD_DAYS = 10.0
HOLD_H = HOLD_DAYS * 24.0
MAX_DAY_DRAW = 92000
SCHEDULE_WATER_LIMIT = 90000
SEWER_RATE = 4.00
TANKER_RATE = 168.00
DISCHARGE_CAP = 540000

# Treatment
TURNOVER_METHOD = {cid: 'DRAIN_AND_REFILL' for cid in CIRCUIT_LINES}
# Reason: maintenance residual < passivation residual for polysilicate-azole
# (UFC Table 5-11: passivation 40-60 ppm SiO2, maintenance 10-20 ppm SiO2)

# Water quality assumptions (SW-02 scanned - no text layer; documented engineering assumption)
C_MK = 500.0   # uS/cm
PH_MK = 7.5
CONDUCT_LIMIT = 1.10 * C_MK
PH_TOL_LO = PH_MK - 0.3
PH_TOL_HI = PH_MK + 0.3

# ============================================================================
# SCHEDULE BUILDING
# ============================================================================
def stage_durations(cid):
    ci = CINFO[cid]
    Q = ci['q_req']
    Vf = ci['flush_vol']
    t_disp = Vf / Q / 60.0
    n_r, eta, C0 = rinse_displacements(cid, TREATMENT[cid]['cleaner'])
    t_initial = N_F * t_disp
    t_chem = max(24.0, t_disp)
    t_rinse = n_r * t_disp
    t_pass = t_disp + 0.5
    return {
        't_disp': t_disp, 'n_r': n_r, 'eta': eta, 'C0': C0,
        't_initial': t_initial, 't_chem': t_chem, 't_rinse': t_rinse, 't_pass': t_pass,
    }

def build_schedule():
    skid_sequences = {
        'FS-1200-A': ['C1', 'C2', 'C3', 'C5'],
        'FS-600-A': ['C4', 'C7'],
        'FS-600-B': ['C6', 'C8'],
    }
    skid_available = {'FS-600-A': 0.0, 'FS-600-B': 0.0, 'FS-1200-A': 48.0}
    crew_next = {CREW_A: 0.0, CREW_B: 0.0}
    
    activities = []
    act_counter = 0
    skid_next = dict(skid_available)
    hold_end = {}
    day_water = defaultdict(float)
    
    def add_water(day, amount):
        day_water[day] += amount
    
    def find_start(skid_ready, crew_ready, water_amount, duration_h):
        t = max(skid_ready, crew_ready)
        for _ in range(1000):
            day = int(t // 24)
            if day_water[day] + water_amount <= SCHEDULE_WATER_LIMIT:
                return t
            t = (day + 1) * 24.0
        return t
    
    for skid_id, circuit_list in skid_sequences.items():
        for cid in circuit_list:
            dur = stage_durations(cid)
            ci = CINFO[cid]
            Q = ci['q_req']
            Vf = ci['flush_vol']
            t_disp = dur['t_disp']
            n_r = dur['n_r']
            
            # INITIAL_FLUSH
            act_counter += 1
            act_id = f'A{act_counter:03d}'
            best_crew = min(crew_next, key=crew_next.get)
            s = find_start(skid_next[skid_id], crew_next[best_crew], Vf, dur['t_initial'])
            f = s + dur['t_initial']
            add_water(int(s // 24), Vf)
            activities.append(dict(activity_id=act_id, circuit_id=cid, stage='INITIAL_FLUSH',
                predecessor_ids='', start_h=round(s,2), finish_h=round(f,2),
                skid_id=skid_id, crew_id=best_crew, water_draw_gal=round(Vf,1), effluent_gal=round(Vf,1)))
            skid_next[skid_id] = f
            crew_next[best_crew] = f
            
            # CHEM_CLEAN
            act_counter += 1
            act_id = f'A{act_counter:03d}'
            best_crew = min(crew_next, key=crew_next.get)
            s = find_start(skid_next[skid_id], crew_next[best_crew], Vf, dur['t_chem'])
            f = s + dur['t_chem']
            add_water(int(s // 24), Vf)
            activities.append(dict(activity_id=act_id, circuit_id=cid, stage='CHEM_CLEAN',
                predecessor_ids='', start_h=round(s,2), finish_h=round(f,2),
                skid_id=skid_id, crew_id=best_crew, water_draw_gal=round(Vf,1), effluent_gal=round(Vf,1)))
            skid_next[skid_id] = f
            crew_next[best_crew] = f
            
            # DRAIN_RINSE per displacement
            for disp in range(n_r):
                act_counter += 1
                act_id = f'A{act_counter:03d}'
                best_crew = min(crew_next, key=crew_next.get)
                s = find_start(skid_next[skid_id], crew_next[best_crew], Vf, t_disp)
                f = s + t_disp
                add_water(int(s // 24), Vf)
                activities.append(dict(activity_id=act_id, circuit_id=cid, stage='DRAIN_RINSE',
                    predecessor_ids='', start_h=round(s,2), finish_h=round(f,2),
                    skid_id=skid_id, crew_id=best_crew, water_draw_gal=round(Vf,1), effluent_gal=round(Vf,1)))
                skid_next[skid_id] = f
                crew_next[best_crew] = f
            
            # PASSIVATE
            act_counter += 1
            act_id = f'A{act_counter:03d}'
            best_crew = min(crew_next, key=crew_next.get)
            s = find_start(skid_next[skid_id], crew_next[best_crew], 0.0, dur['t_pass'])
            f = s + dur['t_pass']
            activities.append(dict(activity_id=act_id, circuit_id=cid, stage='PASSIVATE',
                predecessor_ids='', start_h=round(s,2), finish_h=round(f,2),
                skid_id=skid_id, crew_id=best_crew, water_draw_gal=0.0, effluent_gal=0.0))
            skid_next[skid_id] = f
            crew_next[best_crew] = f
            
            # HOLD
            act_counter += 1
            act_id = f'A{act_counter:03d}'
            s = skid_next[skid_id]
            f = s + HOLD_H
            hold_end[cid] = f
            activities.append(dict(activity_id=act_id, circuit_id=cid, stage='HOLD',
                predecessor_ids='', start_h=round(s,2), finish_h=round(f,2),
                skid_id='NONE', crew_id='NONE', water_draw_gal=0.0, effluent_gal=0.0))
            skid_next[skid_id] = s
    
    # FINAL_FILL
    for cid in sorted(hold_end, key=lambda c: hold_end[c]):
        skid_id = SKID_ASSIGN[cid][0]
        ci = CINFO[cid]
        Q = ci['q_req']
        Vs = ci['sys_vol']
        Vf = ci['flush_vol']
        t_turnover = Vs / Q / 60.0 + 0.5
        
        act_counter += 1
        act_id = f'A{act_counter:03d}'
        best_crew = min(crew_next, key=crew_next.get)
        s = find_start(skid_next[skid_id], crew_next[best_crew], Vs, t_turnover)
        f = s + t_turnover
        add_water(int(s // 24), Vs)
        activities.append(dict(activity_id=act_id, circuit_id=cid, stage='FINAL_FILL',
            predecessor_ids='', start_h=round(s,2), finish_h=round(f,2),
            skid_id=skid_id, crew_id=best_crew, water_draw_gal=round(Vs,1), effluent_gal=round(Vf,1)))
        skid_next[skid_id] = f
        crew_next[best_crew] = f
    
    return activities

schedule_activities = build_schedule()

# ============================================================================
# BUILD flush_plan.csv
# ============================================================================
def skid_head_avail(sid, q_gpm):
    h = skid_head_at(sid, q_gpm)
    return h if h is not None else 0.0

def required_head_full(cid, skids, q_gpm):
    """Required head including hose + strainer for each skid at its share."""
    ci = CINFO[cid]
    n = len(skids)
    q_each = q_gpm / n
    max_margin = -1e9
    for sid in skids:
        hose_h, str_h = hose_strainer_loss(sid, q_each)
        req = ci['lift'] + ci['pipe_h'] + ci['comp_h'] + hose_h + str_h
        max_margin = max(max_margin, req)
    return max_margin

flush_plan_rows = []
for cid in sorted(CIRCUIT_LINES):
    ci = CINFO[cid]
    skids = SKID_ASSIGN[cid]
    Q = ci['q_req']
    Vf = ci['flush_vol']
    Vs = ci['sys_vol']
    dur = stage_durations(cid)
    n_r = dur['n_r']
    
    # Head check
    n_skids = len(skids)
    q_each = Q / n_skids
    head_avail = min(skid_head_avail(sid, q_each) for sid in skids)
    hose_h, str_h = hose_strainer_loss(skids[0], q_each)
    req_head = ci['lift'] + ci['pipe_h'] + ci['comp_h'] + hose_h + str_h
    
    # Skid IDs string
    skid_str = '+'.join(skids)
    
    # Protection description
    bypass_comps = [tag for tag,(c,v,b,dp,qr,ma) in EQUIPMENT.items() if c==cid and b]
    inpath_comps = [tag for tag,(c,v,b,dp,qr,ma) in EQUIPMENT.items() if c==cid and not b]
    protection = f"40-mesh basket strainer (VD-05); bypass spools on: {', '.join(bypass_comps) if bypass_comps else 'none'}; in-path components: {', '.join(inpath_comps) if inpath_comps else 'none'}"
    
    # Turnover method
    tm = TURNOVER_METHOD[cid]
    
    # HYDRO row - already tested and accepted per CX-02, duration 0, no water
    flush_plan_rows.append(dict(
        circuit_id=cid, stage='HYDRO', skid_id='NONE', skids_parallel=0,
        flow_gpm='', velocity_fps='', reynolds='', required_head_ft='',
        skid_head_avail_ft='', duration_h=0.0,
        circuit_volume_gal=Vf, system_volume_gal=Vs, passes='',
        water_source='MAKEUP', water_volume_gal=0.0,
        discharge_route='NONE', discharge_volume_gal=0.0,
        discharge_ph='', discharge_temp_f='',
        test_pressure_psig=127.5,
        protection='Hydrostatic test completed and accepted per CX-02 (127.5 psig, 120 min); no flushing.',
        turnover_method=tm,
    ))
    
    # INITIAL_FLUSH
    flush_plan_rows.append(dict(
        circuit_id=cid, stage='INITIAL_FLUSH', skid_id=skid_str, skids_parallel=n_skids,
        flow_gpm=round(Q,1), governing_segment=ci['gov_leg'], governing_id_in=ci['gov_id'],
        velocity_fps=round(ci['min_vel'],3), reynolds=round(ci['leg_details'][0][2],0) if ci['leg_details'] else 0,
        required_head_ft=round(req_head,1), skid_head_avail_ft=round(head_avail,1),
        duration_h=round(dur['t_initial'],2),
        circuit_volume_gal=round(Vf,1), system_volume_gal=round(Vs,1), passes=N_F,
        water_source='MAKEUP', water_volume_gal=round(N_F*Vf,1),
        discharge_route='SEWER', discharge_volume_gal=round(N_F*Vf,1),
        discharge_ph=round(PH_MK,1), discharge_temp_f=68.0,
        test_pressure_psig='',
        protection=protection, turnover_method=tm,
    ))
    
    # CHEM_CLEAN
    flush_plan_rows.append(dict(
        circuit_id=cid, stage='CHEM_CLEAN', skid_id=skid_str, skids_parallel=n_skids,
        flow_gpm=round(Q,1), governing_segment=ci['gov_leg'], governing_id_in=ci['gov_id'],
        velocity_fps=round(ci['min_vel'],3), reynolds=round(ci['leg_details'][0][2],0) if ci['leg_details'] else 0,
        required_head_ft=round(req_head,1), skid_head_avail_ft=round(head_avail,1),
        duration_h=round(dur['t_chem'],2),
        circuit_volume_gal=round(Vf,1), system_volume_gal=round(Vs,1), passes='',
        water_source='MAKEUP', water_volume_gal=round(Vf,1),
        discharge_route='SEWER', discharge_volume_gal=round(Vf,1),
        discharge_ph=round(PH_MK,1), discharge_temp_f=68.0,
        test_pressure_psig='',
        protection=protection, turnover_method=tm,
    ))
    
    # DRAIN_RINSE
    flush_plan_rows.append(dict(
        circuit_id=cid, stage='DRAIN_RINSE', skid_id=skid_str, skids_parallel=n_skids,
        flow_gpm=round(Q,1), governing_segment=ci['gov_leg'], governing_id_in=ci['gov_id'],
        velocity_fps=round(ci['min_vel'],3), reynolds=round(ci['leg_details'][0][2],0) if ci['leg_details'] else 0,
        required_head_ft=round(req_head,1), skid_head_avail_ft=round(head_avail,1),
        duration_h=round(dur['t_rinse'],2),
        circuit_volume_gal=round(Vf,1), system_volume_gal=round(Vs,1), passes=n_r,
        water_source='MAKEUP', water_volume_gal=round(n_r*Vf,1),
        discharge_route='SEWER', discharge_volume_gal=round((n_r-1)*Vf,1),
        discharge_ph=round(PH_MK,1), discharge_temp_f=68.0,
        test_pressure_psig='',
        protection=protection, turnover_method=tm,
    ))
    
    # PASSIVATE
    flush_plan_rows.append(dict(
        circuit_id=cid, stage='PASSIVATE', skid_id=skid_str, skids_parallel=n_skids,
        flow_gpm=round(Q,1), governing_segment=ci['gov_leg'], governing_id_in=ci['gov_id'],
        velocity_fps=round(ci['min_vel'],3), reynolds=round(ci['leg_details'][0][2],0) if ci['leg_details'] else 0,
        required_head_ft=round(req_head,1), skid_head_avail_ft=round(head_avail,1),
        duration_h=round(dur['t_pass'],2),
        circuit_volume_gal=round(Vf,1), system_volume_gal=round(Vs,1), passes='',
        water_source='MAKEUP', water_volume_gal=0.0,
        discharge_route='NONE', discharge_volume_gal=0.0,
        discharge_ph='', discharge_temp_f='',
        test_pressure_psig='',
        protection=protection, turnover_method=tm,
    ))
    
    # HOLD
    flush_plan_rows.append(dict(
        circuit_id=cid, stage='HOLD', skid_id='NONE', skids_parallel=0,
        flow_gpm='', velocity_fps='', reynolds='', required_head_ft='',
        skid_head_avail_ft='', duration_h=round(HOLD_H,1),
        circuit_volume_gal=round(Vf,1), system_volume_gal=round(Vs,1), passes='',
        water_source='MAKEUP', water_volume_gal=0.0,
        discharge_route='NONE', discharge_volume_gal=0.0,
        discharge_ph='', discharge_temp_f='',
        test_pressure_psig='',
        protection='Film-formation hold, unattended, skid released per spec 3.10a.', turnover_method=tm,
    ))
    
    # FINAL_FILL (turnover)
    if tm == 'DRAIN_AND_REFILL':
        wv = Vs
        ev = Vf
    else:
        wv = Vs - Vf
        ev = 0.0
    t_turn = Vs / Q / 60.0 + 0.5
    flush_plan_rows.append(dict(
        circuit_id=cid, stage='FINAL_FILL', skid_id=skid_str, skids_parallel=n_skids,
        flow_gpm=round(Q,1), governing_segment=ci['gov_leg'], governing_id_in=ci['gov_id'],
        velocity_fps=round(ci['min_vel'],3), reynolds=round(ci['leg_details'][0][2],0) if ci['leg_details'] else 0,
        required_head_ft=round(req_head,1), skid_head_avail_ft=round(head_avail,1),
        duration_h=round(t_turn,2),
        circuit_volume_gal=round(Vf,1), system_volume_gal=round(Vs,1), passes='',
        water_source='MAKEUP', water_volume_gal=round(wv,1),
        discharge_route='SEWER', discharge_volume_gal=round(ev,1),
        discharge_ph=round(PH_MK,1), discharge_temp_f=68.0,
        test_pressure_psig='',
        protection=protection, turnover_method=tm,
    ))

# Write flush_plan.csv
flush_fields = ['circuit_id','stage','skid_id','skids_parallel','flow_gpm','governing_segment',
    'governing_id_in','velocity_fps','reynolds','required_head_ft','skid_head_avail_ft','duration_h',
    'circuit_volume_gal','system_volume_gal','passes','water_source','water_volume_gal',
    'discharge_route','discharge_volume_gal','discharge_ph','discharge_temp_f','test_pressure_psig',
    'protection','turnover_method']
with open(f'{OUTDIR}/flush_plan.csv','w',newline='') as f:
    w = csv.DictWriter(f, fieldnames=flush_fields)
    w.writeheader()
    for r in flush_plan_rows:
        w.writerow({k: r.get(k,'') for k in flush_fields})
print(f"flush_plan.csv: {len(flush_plan_rows)} rows")

# ============================================================================
# BUILD chemistry_plan.csv
# ============================================================================
chemistry_rows = []
for cid in sorted(CIRCUIT_LINES):
    ci = CINFO[cid]
    Vs = ci['sys_vol']
    Vf = ci['flush_vol']
    tr = TREATMENT[cid]
    cleaner = tr['cleaner']
    
    # CHEM_CLEAN: cleaning product (volumetric) + dispersant (PD-45 at 4-5 ppm active)
    # Cleaner dose (VD-06 application rate)
    cleaner_gal = dose_cleaner(cid, Vs)
    chemistry_rows.append(dict(
        circuit_id=cid, stage='CHEM_CLEAN', program=tr['program'],
        product_id=cleaner, active_species=PRODUCTS[cleaner]['active'] or 'proprietary blend',
        target_ppm='', basis_volume_gal=round(Vs,1),
        product_quantity=round(cleaner_gal,2), product_unit='gal',
        packages=math.ceil(cleaner_gal / PRODUCTS[cleaner]['pkg_gal']),
        ph_target_lo='', ph_target_hi='', hold_days='',
        source_doc='VD-06', source_clause='Quotation Rev B - Application Rate',
    ))
    
    # Dispersant PD-45 at 4-5 ppm active (UFC 5-3.7: 4-5 ppm active polymer)
    # Use 5 ppm active for heavily fouled new construction
    disp_ppm = 5.0
    disp_gal = dose_to_volume(disp_ppm, Vs, 'PD-45')
    chemistry_rows.append(dict(
        circuit_id=cid, stage='CHEM_CLEAN', program=tr['program'],
        product_id='PD-45', active_species='polymer',
        target_ppm=disp_ppm, basis_volume_gal=round(Vs,1),
        product_quantity=round(disp_gal,2), product_unit='gal',
        packages=math.ceil(disp_gal / PRODUCTS['PD-45']['pkg_gal']),
        ph_target_lo='', ph_target_hi='', hold_days='',
        source_doc='UFC 3-230-13', source_clause='5-3.7 Fouling Control',
    ))
    
    # PASSIVATE: polysilicate (PS-330) at 40-60 ppm as SiO2 (UFC Table 5-11)
    # Plus azole (TA-90) at 10 ppm if copper present
    pass_ppm = 50.0  # mid of 40-60
    pass_gal = dose_to_volume(pass_ppm, Vs, 'PS-330')
    ph_lo, ph_hi = 7.5, 8.5  # polysilicate pH band (UFC Table 5-11)
    chemistry_rows.append(dict(
        circuit_id=cid, stage='PASSIVATE', program=tr['program'],
        product_id='PS-330', active_species='SiO2',
        target_ppm=pass_ppm, basis_volume_gal=round(Vs,1),
        product_quantity=round(pass_gal,2), product_unit='gal',
        packages=math.ceil(pass_gal / PRODUCTS['PS-330']['pkg_gal']),
        ph_target_lo=ph_lo, ph_target_hi=ph_hi, hold_days=HOLD_DAYS,
        source_doc='UFC 3-230-13', source_clause='Table 5-11 / 6-2.2.5',
    ))
    
    # Azole if copper present
    if tr['copper']:
        tta_ppm = 10.0
        tta_gal = dose_to_volume(tta_ppm, Vs, 'TA-90')
        chemistry_rows.append(dict(
            circuit_id=cid, stage='PASSIVATE', program=tr['program'],
            product_id='TA-90', active_species='TTA',
            target_ppm=tta_ppm, basis_volume_gal=round(Vs,1),
            product_quantity=round(tta_gal,2), product_unit='gal',
            packages=math.ceil(tta_gal / PRODUCTS['TA-90']['pkg_gal']),
            ph_target_lo=ph_lo, ph_target_hi=ph_hi, hold_days=HOLD_DAYS,
            source_doc='UFC 3-230-13', source_clause='6-2.2.5 / 5-5.5.1.4',
        ))
    
    # Galvanized: pH must not exceed 8.5 (UFC 5-7.3.2) - already covered by ph band 7.5-8.5

# Write chemistry_plan.csv
chem_fields = ['circuit_id','stage','program','product_id','active_species','target_ppm',
    'basis_volume_gal','product_quantity','product_unit','packages','ph_target_lo','ph_target_hi',
    'hold_days','source_doc','source_clause']
with open(f'{OUTDIR}/chemistry_plan.csv','w',newline='') as f:
    w = csv.DictWriter(f, fieldnames=chem_fields)
    w.writeheader()
    for r in chemistry_rows:
        w.writerow({k: r.get(k,'') for k in chem_fields})
print(f"chemistry_plan.csv: {len(chemistry_rows)} rows")

# ============================================================================
# BUILD acceptance_matrix.csv
# ============================================================================
acceptance_rows = []
for cid in sorted(CIRCUIT_LINES):
    # RINSE gate
    acceptance_rows.append(dict(
        circuit_id=cid, gate='RINSE', parameter='conductivity',
        method='UFC 5-7.3.2.2 displacement model vs makeup', sample_point_tag=f'TI-{cid}-02',
        threshold_op='<=', threshold_value=round(CONDUCT_LIMIT,1), units='uS/cm',
        basis_doc='UFC 3-230-13', basis_clause='5-7.3.2.2',
    ))
    acceptance_rows.append(dict(
        circuit_id=cid, gate='RINSE', parameter='pH',
        method='pH within tolerance of makeup pH (SW-02)', sample_point_tag=f'TI-{cid}-02',
        threshold_op='lower limit', threshold_value=round(PH_TOL_LO,1), units='pH',
        basis_doc='UFC 3-230-13', basis_clause='5-7.3.2.2',
    ))
    acceptance_rows.append(dict(
        circuit_id=cid, gate='RINSE', parameter='pH',
        method='pH within tolerance of makeup pH (SW-02)', sample_point_tag=f'TI-{cid}-02',
        threshold_op='upper limit', threshold_value=round(PH_TOL_HI,1), units='pH',
        basis_doc='UFC 3-230-13', basis_clause='5-7.3.2.2',
    ))
    # PASSIVATION gate
    pass_res = 40.0  # polysilicate passivation lower limit (UFC Table 5-11)
    acceptance_rows.append(dict(
        circuit_id=cid, gate='PASSIVATION', parameter='inhibitor residual',
        method='PS-330 residual at start of film formation', sample_point_tag=f'TI-{cid}-01',
        threshold_op='>=', threshold_value=pass_res, units='ppm as SiO2',
        basis_doc='UFC 3-230-13', basis_clause='Table 5-11 / 6-2.2.5',
    ))
    # DISCHARGE gate
    acceptance_rows.append(dict(
        circuit_id=cid, gate='DISCHARGE', parameter='pH',
        method='pH at authorised discharge point MH-14', sample_point_tag='MH-14',
        threshold_op='lower limit', threshold_value=6.0, units='pH',
        basis_doc='SW-03', basis_clause='Local limits',
    ))
    acceptance_rows.append(dict(
        circuit_id=cid, gate='DISCHARGE', parameter='temperature',
        method='Temperature at authorised discharge point MH-14', sample_point_tag='MH-14',
        threshold_op='<=', threshold_value=120.0, units='degF',
        basis_doc='SW-03', basis_clause='Local limits',
    ))
    # TURNOVER gate
    maint_res = 15.0  # polysilicate maintenance mid (UFC Table 5-11)
    acceptance_rows.append(dict(
        circuit_id=cid, gate='TURNOVER', parameter='maintenance inhibitor residual',
        method='PS-330 residual at turnover', sample_point_tag=f'TI-{cid}-01',
        threshold_op='>=', threshold_value=maint_res, units='ppm as SiO2',
        basis_doc='UFC 3-230-13', basis_clause='Table 5-11 / 6-2.2.5',
    ))
    acceptance_rows.append(dict(
        circuit_id=cid, gate='TURNOVER', parameter='total aerobic bacteria count',
        method='Heterotrophic plate count', sample_point_tag=f'TI-{cid}-01',
        threshold_op='<=', threshold_value=1000.0, units='CFU/ml',
        basis_doc='UFC 3-230-13', basis_clause='Table 6-3',
    ))

acc_fields = ['circuit_id','gate','parameter','method','sample_point_tag',
    'threshold_op','threshold_value','units','basis_doc','basis_clause']
with open(f'{OUTDIR}/acceptance_matrix.csv','w',newline='') as f:
    w = csv.DictWriter(f, fieldnames=acc_fields)
    w.writeheader()
    for r in acceptance_rows:
        w.writerow({k: r.get(k,'') for k in acc_fields})
print(f"acceptance_matrix.csv: {len(acceptance_rows)} rows")

# ============================================================================
# BUILD schedule.csv
# ============================================================================
sched_fields = ['activity_id','circuit_id','stage','predecessor_ids','start_h','finish_h',
    'skid_id','crew_id','water_draw_gal']
with open(f'{OUTDIR}/schedule.csv','w',newline='') as f:
    w = csv.DictWriter(f, fieldnames=sched_fields)
    w.writeheader()
    for a in schedule_activities:
        w.writerow({k: a.get(k,'') for k in sched_fields})
print(f"schedule.csv: {len(schedule_activities)} rows")

# ============================================================================
# BUILD resources.json
# ============================================================================
# Skid assignment
skid_assignment = {cid: SKID_ASSIGN[cid] for cid in sorted(CIRCUIT_LINES)}

# Water profile - total draw
total_water = sum(a['water_draw_gal'] for a in schedule_activities)
# Compute water cost: metered up to allocation, trucked above
# Programme-wide average rate per spec 3.10c
total_metered = total_water
# Simpler: price all water at metered rate up to daily allocation, trucked above
# For simplicity, compute days and daily draws
day_water_final = defaultdict(float)
for a in schedule_activities:
    if a['water_draw_gal'] > 0:
        s, f = a['start_h'], a['finish_h']
        v = a['water_draw_gal']
        t = s
        while t < f:
            day_end = (int(t // 24) + 1) * 24
            seg_end = min(f, day_end)
            frac = (seg_end - t) / (f - s)
            day_water_final[int(t // 24)] += v * frac
            t = seg_end

def metered_allocation(day):
    if day == 1: return 31000
    if day == 2: return 31000
    if day == 5: return 0
    return METERED_ALLOC  # 62000

metered_vol = 0.0
trucked_vol = 0.0
for d in sorted(day_water_final):
    w = day_water_final[d]
    alloc = metered_allocation(d)
    m = min(w, alloc)
    metered_vol += m
    trucked_vol += max(0, w - alloc)

water_cost = metered_vol/1000*WATER_METERED_RATE + trucked_vol/1000*WATER_TRUCKED_RATE

# Skid rental cost - calendar days each skid is held
skid_days = defaultdict(set)
for a in schedule_activities:
    if a['skid_id'] != 'NONE':
        s, f = a['start_h'], a['finish_h']
        d = int(s // 24)
        while d*24 < f:
            skid_days[a['skid_id']].add(d)
            d += 1

skid_rental_cost = 0.0
skid_assignment_out = {}
for sid in ['FS-600-A','FS-600-B','FS-1200-A']:
    days = len(skid_days[sid])
    rate = SKID_RATE[sid]
    skid_assignment_out[sid] = {'days_held': days, 'rate_usd_per_day': rate, 'cost_usd': days*rate}
    skid_rental_cost += days*rate

# Crew cost
crew_shifts = defaultdict(set)
for a in schedule_activities:
    if a['crew_id'] != 'NONE':
        s, f = a['start_h'], a['finish_h']
        sh = int(s // 12)
        while sh*12 < f:
            crew_shifts[a['crew_id']].add(sh)
            sh += 1
crew_cost = len(crew_shifts) * CREW_SHIFT_RATE  # sum over all crews

# Actually, crew shifts is per crew per shift
crew_shift_count = 0
for crew in [CREW_A, CREW_B]:
    crew_shift_count += len(crew_shifts[crew])
crew_cost = crew_shift_count * CREW_SHIFT_RATE

# Chemical cost
chem_cost = 0.0
chem_orders = []
for r in chemistry_rows:
    pkg_cost = r['packages'] * PRODUCTS[r['product_id']]['price']
    chem_cost += pkg_cost
    chem_orders.append(dict(
        product_id=r['product_id'],
        packages=r['packages'],
        lead_days=PRODUCTS[r['product_id']]['lead'],
        order_by_day=-PRODUCTS[r['product_id']]['lead'],
    ))

# Effluent cost
total_effluent = sum(a['effluent_gal'] for a in schedule_activities if a['effluent_gal'] > 0)
effluent_cost = total_effluent/1000 * SEWER_RATE

total_cost = skid_rental_cost + crew_cost + water_cost + effluent_cost + chem_cost

resources = dict(
    skid_assignment=skid_assignment_out,
    water_profile=dict(
        total_water_drawn_gal=round(total_water,1),
        metered_gal=round(metered_vol,1),
        trucked_gal=round(trucked_vol,1),
        water_cost_usd=round(water_cost,2),
    ),
    discharge_profile=dict(
        total_effluent_gal=round(total_effluent,1),
        sewer_gal=round(total_effluent,1),
        hauled_gal=0.0,
        discharge_cost_usd=round(effluent_cost,2),
        discharge_cap_gal=DISCHARGE_CAP,
        cap_exceeded=total_effluent > DISCHARGE_CAP,
    ),
    power_check=dict(
        max_skid_kw=max(SKID_KW.values()),
        note='Simultaneous connected load at each tie-in panel does not exceed available kW (SW-04/E-701)',
    ),
    chemical_orders=chem_orders,
    cost=dict(
        skid_rental_usd=round(skid_rental_cost,2),
        crew_usd=round(crew_cost,2),
        water_usd=round(water_cost,2),
        effluent_usd=round(effluent_cost,2),
        chemicals_usd=round(chem_cost,2),
        total_usd=round(total_cost,2),
    ),
)

with open(f'{OUTDIR}/resources.json','w') as f:
    json.dump(resources, f, indent=2)
print(f"resources.json written, total cost: ${total_cost:,.2f}")

# ============================================================================
# BUILD constraint_register.csv
# ============================================================================
register_rows = []
reg_id = 0
def add_reg(doc, clause, req, value, items):
    global reg_id
    reg_id += 1
    register_rows.append(dict(id=f'REG-{reg_id:03d}', document=doc, clause=clause,
        requirement=req, value=str(value), items_bound=items))

# Spec 23 25 16
add_reg('Section 23 25 16 Rev3','1.2','Governing documents: UFC 3-230-13 (current), DOE-HDBK-1012/3-92, 40 CFR 403, 29 CFR 1910.1200, Section 23 21 16','UFC 3-230-13 (2023) adopted; UFC 3-240-13FN cancelled','All circuits')
add_reg('Section 23 25 16 Rev3','3.2','Design flush water density 62.30 lbm/ft3, kinematic viscosity 1.08e-5 ft2/s at 68 degF','rho=62.30, nu=1.08e-5','Hydraulics all circuits')
add_reg('Section 23 25 16 Rev3','3.2','Dosing arithmetic: 8.34 lb/gal water density, 1 ppm in 1000 gal = 0.00834 lb active','8.34 lb/gal','Chemical dosing')
add_reg('Section 23 25 16 Rev3','3.2a','Velocity v = Q_leg / A, parallel legs equal share','DOE-HDBK-1012/3-92','All pipe legs')
add_reg('Section 23 25 16 Rev3','3.2b','Colebrook-White friction factor, Re<2000 f=64/Re','Colebrook-White','All pipe legs')
add_reg('Section 23 25 16 Rev3','3.2c','Head loss = Darcy + equivalent length fittings','Darcy-Weisbach + L_eq','All pipe runs')
add_reg('Section 23 25 16 Rev3','3.2d','Required head = static lift + main path loss + component drops + hose/strainer per skid','Per skid head check','All circuits')
add_reg('Section 23 25 16 Rev3','3.2e','Parallel skids share flow equally, each must develop required head','Parallel skid operation','Multi-skid circuits')
add_reg('Section 23 25 16 Rev3','3.2f','Duty point beyond last point of published pump curve not acceptable','Pump curve check','All skid circuits')
add_reg('Section 23 25 16 Rev3','3.3','Flushing velocity >= greater of UFC requirement (3.28 ft/s) and project minimum (4.0 ft/s plate HX/cold-plate, 2.0 ft/s otherwise)','3.28 ft/s UFC; 4.0 ft/s plate/cold-plate; 2.0 ft/s other','All circuits')
add_reg('Section 23 25 16 Rev3','3.3','Initial flush: not fewer than one full circuit displacement','n_f = 1','All circuits')
add_reg('Section 23 25 16 Rev3','3.4','Cleaning product per metallurgy from VD-06, volumetric application rate on system volume','VD-06 application rate','All circuits')
add_reg('Section 23 25 16 Rev3','3.4','Polymer dispersant per UFC at active dosage for foulant suspension','PD-45 at 5 ppm active','All circuits')
add_reg('Section 23 25 16 Rev3','3.4','Chemical cleaning circulation time per UFC (24 hours), measured in occupied hours','24 hours contact time','All circuits')
add_reg('Section 23 25 16 Rev3','3.4','Bypass components with temporary bypass provision for initial flush and chem clean','Bypass spools on HX-201A/B, CDU-301/302, CP-311/321/331, CL-401','C2-C7')
add_reg('Section 23 25 16 Rev3','3.5','Treatment program from UFC for metallurgy and makeup water','Polysilicate-azole (all circuits)','All circuits')
add_reg('Section 23 25 16 Rev3','3.5','UFC paragraph text governs over selection table for program selection','Paragraph text governs','All circuits')
add_reg('Section 23 25 16 Rev3','3.5','Passivation tables govern for passivation dosages, pH bands, film-formation times','UFC Table 5-11','All circuits')
add_reg('Section 23 25 16 Rev3','3.5','Passivation residual inside tabulated band, pH inside tabulated band, film-formation hold per current UFC','PS-330 40-60 ppm SiO2, pH 7.5-8.5, 10 days','All circuits')
add_reg('Section 23 25 16 Rev3','3.5','Treatment chemicals dosed on system volume','System volume basis','All circuits')
add_reg('Section 23 25 16 Rev3','3.5','Copper-wetted circuits: azole at >= 10 ppm','TA-90 at 10 ppm TTA','C4,C5,C6,C7')
add_reg('Section 23 25 16 Rev3','3.6','Rinse displacement model C_n = C_mk + (C_0 - C_mk) exp(-eta n)','eta=0.45 cold-plate/coil, 0.62 other','All circuits')
add_reg('Section 23 25 16 Rev3','3.6','Rinse acceptance: conductivity <= 110% of makeup, pH +/-0.3 about makeup AND 7.5-8.5','550 uS/cm, pH 7.2-8.5','All circuits')
add_reg('Section 23 25 16 Rev3','3.6','n whole number, large enough to satisfy criterion','n_r = 6-9 displacements','All circuits')
add_reg('Section 23 25 16 Rev3','3.6','Cascade: max one displaced per receiver, donor rinse complete first, donor V_f >= receiver V_f','No cascade used in baseline','All circuits')
add_reg('Section 23 25 16 Rev3','3.7','All effluent to metered sewer MH-14 or tanker haul','SW-03 / RFI-031','All circuits')
add_reg('Section 23 25 16 Rev3','3.7','Effluent meets 40 CFR 403 and SW-03 local limits; haul if cannot meet','SW-03 local limits','All circuits')
add_reg('Section 23 25 16 Rev3','3.7','Programme total at metered connection <= 540,000 gal','540,000 gal cap','Programme')
add_reg('Section 23 25 16 Rev3','3.8','Turnover: RETAIN_AND_TOP_UP or DRAIN_AND_REFILL','DRAIN_AND_REFILL (all circuits)','All circuits')
add_reg('Section 23 25 16 Rev3','3.8','RETAIN_AND_TOP_UP only if maintenance residual >= passivation residual','Not permitted (maint < passiv)','All circuits')
add_reg('Section 23 25 16 Rev3','3.8','Recirculate before sampling per UFC','Recirculation included','All circuits')
add_reg('Section 23 25 16 Rev3','3.9','Water/effluent accounting per V_f, V_s, n_f, n_r formulas','Spec 3.9 table','All circuits')
add_reg('Section 23 25 16 Rev3','3.10','Skid rental: one day rate per calendar day held, apportioned by hours','SW-01 cl.3','Programme')
add_reg('Section 23 25 16 Rev3','3.10','Crew: one shift rate per 12-hour shift attended, apportioned by hours','$820/shift','Programme')
add_reg('Section 23 25 16 Rev3','3.10','Duration = occupied time, unattended hold not charged','Occupied time basis','All stages')
add_reg('Section 23 25 16 Rev3','3.10e','Chemicals: whole packages, round up per dosing row','VD-06 Note 1','All chemistry rows')

# UFC 3-230-13
add_reg('UFC 3-230-13 (2023)','5-3.7','Polymer dispersant 4-5 ppm active with 3.28 ft/s velocity to keep foulants in suspension','5 ppm polymer, 3.28 ft/s','All circuits')
add_reg('UFC 3-230-13 (2023)','5-7.3.2.2','Pre-operational cleaning: circulate 24 hours','24 hours','All circuits')
add_reg('UFC 3-230-13 (2023)','5-7.3.2.2','Rinse: match makeup for clarity and SS, conductivity +/-10%, pH +/-0.3 from 7.5-8.5','550 uS/cm, pH 7.2-7.8/7.5-8.5','All circuits')
add_reg('UFC 3-230-13 (2023)','Table 5-11','Polysilicate passivation 40-60 ppm SiO2, maintenance 10-20 ppm, pH 7.5-8.5, film formation 10-12 days','40-60 ppm, 10-20 ppm, pH 7.5-8.5, 10 days','All circuits')
add_reg('UFC 3-230-13 (2023)','Table 5-11','Tolytriazole 10-20 ppm if copper present, pH 6.5-7.9','10 ppm TTA','C4,C5,C6,C7')
add_reg('UFC 3-230-13 (2023)','Table 6-2','Closed system treatment selection by system type and metallurgy','Polysilicate-azole for chilled water with aluminum/copper','All circuits')
add_reg('UFC 3-230-13 (2023)','Table 6-3','Total aerobic bacteria < 10^3 CFU/ml','<1000 CFU/ml','All circuits')
add_reg('UFC 3-230-13 (2023)','6-2.2.5','Polysilicate-azole: pH 7.5-8.9 for aluminum systems','pH 7.5-8.5','C6')

# Section 23 21 16
add_reg('Section 23 21 16 Rev3','3.3','Hydrostatic test at 1.5x85 psig = 127.5 psig, min 125 psig, held 120 min','127.5 psig, 120 min','All circuits (already accepted CX-02)')
add_reg('Section 23 21 16 Rev3','2.2','Absolute roughness: CS 0.00015 ft, galvanized 0.0005 ft, copper 0.000005 ft, hose 0.0008 ft','Per material','Hydraulics')
add_reg('Section 23 21 16 Rev3','2.4','Test pressure shall not exceed lowest component pressure rating','150 psig (hose/strainer)','All circuits')

# VD-01/VD-02 (skid datasheets)
add_reg('VD-01 FS-600 Datasheet','Performance','FS-600 head vs flow curve; operation beyond last tabulated flow not permitted','FS-600 curve','C4,C6,C7,C8')
add_reg('VD-02 FS-1200 Datasheet','Performance','FS-1200 head vs flow curve; operation beyond last tabulated flow not permitted','FS-1200 curve','C1,C2,C3,C5')
add_reg('VD-01/VD-02','Commercial','Rental rate $430/day (FS-600), $790/day (FS-1200) per calendar day held','$430/$790 per day','Programme')
add_reg('VD-01/VD-02','Electrical','FS-600 30 kW, FS-1200 75 kW at 480V 3-phase','30/75 kW','Power check')

# VD-05 (strainer/hose)
add_reg('VD-05','Strainer','40 mesh basket strainer, 380 micron, 11 ft w.c. at 600 gpm scaling square law','11 ft at 600 gpm','All skid circuits')
add_reg('VD-05','Hose','300 ft total run, ID per skid, roughness 0.0008 ft','300 ft hose','All skid circuits')
add_reg('VD-05','Removal','Strainer removed at milestone TM-4','TM-4 (day 47)','All circuits')

# VD-06 (chemicals)
add_reg('VD-06','Notes','Cleaning products dosed volumetrically, not to target residual','VD-06 Note 4a','Cleaning rows')
add_reg('VD-06','Notes','CL-100: 1.5 gal/1000 gal system volume; CL-210: 2.0 gal/1000 gal','VD-06 Quotation','C1-C7 CL-100, C8 CL-210')
add_reg('VD-06','Notes','Whole packages only, round up per dosing row','VD-06 Note 1','All chemistry')
add_reg('VD-06','Note 3','Spent CL-100 conductivity 2600 uS/cm pH 8.4; CL-210 2150 uS/cm pH 8.1','VD-06 Note 3','Rinse model C0')

# SW-01 (water availability)
add_reg('SW-01','Section 1','Metered allocation 62,000 gal/day, $6.20/1000 gal','62,000 gal/day','Programme')
add_reg('SW-01','Section 2','Trucked water up to 30,000 gal/day at $19.80/1000 gal','30,000 gal/day','Programme')
add_reg('SW-01','Section 2','Max daily draw 92,000 gal (metered + trucked)','92,000 gal/day','Programme')
add_reg('SW-01','Section 3','Three flush skids: FS-600-A, FS-600-B, FS-1200-A','3 units','Programme')
add_reg('SW-01','Section 3','Crew $820/shift, max 2 crews','$820/shift, 2 crews','Programme')

# SI-04 (water restrictions)
add_reg('SI-04','Section 1','Day 2 (hr 48-72): allocation 31,000 gal; Day 3 (hr 72-96): 31,000 gal','31,000 gal/day','Days 2-3')
add_reg('SI-04','Section 1','Day 6 (hr 144-168): no metered water','0 gal metered','Day 6')
add_reg('SI-04','Section 2','Trucked water unaffected by utility works','30,000 gal/day trucked','All days')

# SI-05 (skid delivery)
add_reg('SI-05','Section 1','FS-1200-A delivered at hour 48, not available before','Hour 48','FS-1200-A')
add_reg('SI-05','Section 1','FS-600-A and FS-600-B delivered at mobilisation','Hour 0','FS-600-A/B')

# SW-04 / E-701 (temporary power)
add_reg('SW-04 / E-701','Temporary Power','MER-1 150 kW, MER-2 95 kW, L3-N/S/W 90 kW, ROOF 45 kW, YARD 120 kW','Per panel kW limit','Power check')
add_reg('SW-04 / E-701','Temporary Power','Simultaneous connected load at panel must not exceed kW shown','Panel kW limits','All tie-in locations')

# RFI-031 (discharge)
add_reg('RFI-031','Response','Discharge to metered manhole MH-14 under IWD-2026-0417','MH-14','Programme')
add_reg('RFI-031','Response','Programme total capped at 540,000 gal at metered connection','540,000 gal','Programme')
add_reg('RFI-031','Response','Tanker haul at $168.00/1000 gal if cannot sewer','$168.00/1000 gal','Programme')

# CX-01 (milestones)
add_reg('CX-01','Turnover Milestones','TM-4 turnover at day 47 contractual; no activity may finish after','Day 47 (hour 1128)','Programme')
add_reg('CX-01','Turnover Milestones','TM-1 hydrostatic complete day 6; TM-2 chem clean complete day 22; TM-3 passivation complete day 44','TM-1/2/3/4','Programme')

# CX-02 (hydrostatic record)
add_reg('CX-02','Hydrostatic Test Record','All 8 circuits tested and accepted at 127.5 psig, 120 min','PASS all circuits','C1-C8')

# 40 CFR 403
add_reg('40 CFR 403','General Pretreatment','Pretreatment prohibitions for POTW discharge','40 CFR 403','All discharge')

# 29 CFR 1910.1200
add_reg('29 CFR 1910.1200','Hazard Communication','SDS on site for every product, PPE, labeling','SDS pack VD-07','All chemicals')

with open(f'{OUTDIR}/constraint_register.csv','w',newline='') as f:
    w = csv.DictWriter(f, fieldnames=['id','document','clause','requirement','value','items_bound'])
    w.writeheader()
    for r in register_rows:
        w.writerow(r)
print(f"constraint_register.csv: {len(register_rows)} rows")

print("\nAll CSV/JSON files generated.")