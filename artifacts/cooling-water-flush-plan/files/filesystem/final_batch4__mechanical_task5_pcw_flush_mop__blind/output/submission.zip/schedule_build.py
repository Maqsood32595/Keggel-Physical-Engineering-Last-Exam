#!/usr/bin/env python3
"""Generate all PCW flushing deliverables."""
import math, json, csv, os, sys
sys.path.insert(0, '/filesystem/final_batch4__mechanical_task5_pcw_flush_mop__blind/output')
from compute import *

OUTDIR = '/filesystem/final_batch4__mechanical_task5_pcw_flush_mop__blind/output'

# ============================================================================
# SCHEDULE PLANNING
# ============================================================================
# Skid assignments (each circuit gets its skid(s))
# C1: FS-1200-A (only skid that can do 1181 gpm)
# C2: FS-1200-A (624 gpm, works alone)
# C3: FS-1200-A (720 gpm, works alone)
# C4: FS-600-A (360 gpm)
# C5: FS-1200-A (476 gpm)
# C6: FS-600-B (360 gpm)
# C7: FS-600-A (295 gpm)
# C8: FS-600-B (151 gpm)

SKID_ASSIGN = {
    'C1': ['FS-1200-A'],
    'C2': ['FS-1200-A'],
    'C3': ['FS-1200-A'],
    'C4': ['FS-600-A'],
    'C5': ['FS-1200-A'],
    'C6': ['FS-600-B'],
    'C7': ['FS-600-A'],
    'C8': ['FS-600-B'],
}

# Crew IDs
CREW_A = 'CREW-A'
CREW_B = 'CREW-B'

# n_f: initial flush displacements (minimum 1)
N_F = 1

# Compute stage durations (attended hours)
def stage_durations(cid):
    ci = CINFO[cid]
    Q = ci['q_req']
    Vf = ci['flush_vol']
    t_disp = Vf / Q / 60.0  # hours per displacement (Q in gpm, Vf in gal)
    
    n_r, eta, C0 = rinse_displacements(cid, TREATMENT[cid]['cleaner'])
    
    # Attended time per spec 3.10
    t_initial = N_F * t_disp
    t_chem = max(24.0, t_disp)  # greater of circulation time (24h per UFC) and V_f/Q
    t_rinse = n_r * t_disp
    # Passivate: V_f/Q plus required recirculation (use 0.5h recirc per UFC practice)
    t_pass = t_disp + 0.5
    
    return {
        't_disp': t_disp,
        'n_r': n_r,
        'eta': eta,
        'C0': C0,
        't_initial': t_initial,
        't_chem': t_chem,
        't_rinse': t_rinse,
        't_pass': t_pass,
    }

# Build schedule: sequence circuits on each skid, respecting crew limits (2 crews max)
# We'll use a simple greedy schedule

def build_schedule():
    """Build schedule respecting skid availability, crew limits, water limits."""
    # Circuit order on each skid
    skid_sequences = {
        'FS-1200-A': ['C1', 'C2', 'C3', 'C5'],
        'FS-600-A': ['C4', 'C7'],
        'FS-600-B': ['C6', 'C8'],
    }
    
    skid_available = {'FS-600-A': 0.0, 'FS-600-B': 0.0, 'FS-1200-A': 48.0}  # SI-05
    crew_available = {CREW_A: 0.0, CREW_B: 0.0}  # crew becomes available at this hour
    
    activities = []  # (activity_id, circuit, stage, start, finish, skid, crew, water_draw)
    skid_next = dict(skid_available)
    crew_next = dict(crew_available)
    
    act_counter = 0
    
    for skid_id, circuit_list in skid_sequences.items():
        for cid in circuit_list:
            dur = stage_durations(cid)
            ci = CINFO[cid]
            loc = ci['location']
            
            # Determine start: max(skid_available, crew_available, skid_delivery)
            start = skid_next[skid_id]
            # Also need a crew
            # Find earliest crew available at or after start
            # Crews are shared across skids
            
            # Stages for this circuit (active stages only)
            stages = [
                ('INITIAL_FLUSH', dur['t_initial']),
                ('CHEM_CLEAN', dur['t_chem']),
                ('DRAIN_RINSE', dur['t_rinse']),
                ('PASSIVATE', dur['t_pass']),
            ]
            
            for stage_name, stage_dur in stages:
                act_counter += 1
                act_id = f'A{act_counter:03d}'
                
                # Start when skid is free AND a crew is free
                # Find earliest crew
                best_crew = min(crew_next, key=crew_next.get)
                crew_ready = crew_next[best_crew]
                s = max(start, crew_ready)
                f = s + stage_dur
                
                activities.append({
                    'activity_id': act_id,
                    'circuit_id': cid,
                    'stage': stage_name,
                    'predecessor_ids': '',
                    'start_h': round(s, 2),
                    'finish_h': round(f, 2),
                    'skid_id': skid_id,
                    'crew_id': best_crew,
                    'water_draw_gal': 0,  # computed later
                })
                
                start = f  # next stage on this skid starts after this one
                skid_next[skid_id] = f
                crew_next[best_crew] = f
            
            # HOLD stage (unattended, no crew, no skid)
            act_counter += 1
            act_id = f'A{act_counter:03d}'
            # Hold duration: film formation per UFC Table 5-11
            # Polysilicate: 10-12 days. Use 10 days = 240 hours
            hold_days = 10.0
            hold_h = hold_days * 24.0
            s = skid_next[skid_id]  # starts after last active stage on this skid
            f = s + hold_h
            activities.append({
                'activity_id': act_id,
                'circuit_id': cid,
                'stage': 'HOLD',
                'predecessor_ids': '',
                'start_h': round(s, 2),
                'finish_h': round(f, 2),
                'skid_id': 'NONE',
                'crew_id': 'NONE',
                'water_draw_gal': 0,
            })
            skid_next[skid_id] = f  # skid held during hold? No - spec says released for hold
            # Actually, skid is NOT held during film-formation hold per spec 3.10a
            # So skid_next should NOT advance during hold
            skid_next[skid_id] = s  # skid released at start of hold
            
            # TURNOVER / FINAL_FILL
            act_counter += 1
            act_id = f'A{act_counter:03d}'
            # DRAIN_AND_REFILL: draw V_s, fill at declared flow + recirculation
            Vf = ci['flush_vol']
            Vs = ci['sys_vol']
            t_fill = (Vs - Vf) / Q / 60.0 if 'RETAIN' else Vs / Q / 60.0
            # DRAIN_AND_REFILL: fill V_s at flow Q
            t_turnover = Vs / Q / 60.0 + 0.5  # fill + recirc
            s = max(f, skid_next[skid_id])  # after hold, skid is free
            best_crew = min(crew_next, key=crew_next.get)
            crew_ready = crew_next[best_crew]
            s = max(s, crew_ready)
            f = s + t_turnover
            activities.append({
                'activity_id': act_id,
                'circuit_id': cid,
                'stage': 'FINAL_FILL',
                'predecessor_ids': '',
                'start_h': round(s, 2),
                'finish_h': round(f, 2),
                'skid_id': skid_id,
                'crew_id': best_crew,
                'water_draw_gal': 0,
            })
            skid_next[skid_id] = f
            crew_next[best_crew] = f
    
    return activities

schedule_activities = build_schedule()

# Print schedule summary
print("=== SCHEDULE ===")
for a in schedule_activities:
    print(f"{a['activity_id']} {a['circuit_id']} {a['stage']:15s} {a['start_h']:8.2f}->{a['finish_h']:8.2f} {a['skid_id']:12s} {a['crew_id']}")

# Check TM-4 deadline (day 47 = hour 1128)
max_finish = max(a['finish_h'] for a in schedule_activities)
print(f"\nMax finish hour: {max_finish:.1f} (TM-4 deadline: hour 1128 = day 47)")
print(f"Within deadline: {max_finish <= 1128}")