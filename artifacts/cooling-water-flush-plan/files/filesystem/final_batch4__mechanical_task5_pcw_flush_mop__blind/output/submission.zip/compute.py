#!/usr/bin/env python3
"""PCW Flushing & Passivation - Comprehensive calculation engine."""
import math, json, csv, os

# ---------------------------------------------------------------------------
# Project constants (from specs and vendor data)
# ---------------------------------------------------------------------------
RHO = 62.30          # lbm/ft3, design flush water density (spec 3.2)
NU  = 1.08e-5        # ft2/s, kinematic viscosity at 68 degF (spec 3.2)
G   = 32.2           # ft/s2
GAL_PER_FT3 = 7.48052
GPM_PER_CFS = 448.831
DOSING_FACTOR = 0.00834 / 1000.0  # lb active per ppm per gal (spec 3.2: 1ppm in 1000gal = 0.00834 lb)

# UFC velocity for keeping foulants in suspension (UFC 3-230-13 5-3.7)
UFC_VELOCITY = 3.28  # ft/s

# Circuit -> lines (from P&ID drawings M-PID-101..104)
CIRCUIT_LINES = {
    'C1': ['1041','1042','1043','1044'],
    'C2': ['2011','2012','2013'],
    'C3': ['2021','2022','2023'],
    'C4': ['4021','4022','4023','4024'],
    'C5': ['4031','4032','4033','4034'],
    'C6': ['4041','4042','4043'],
    'C7': ['5011','5012','5013'],
    'C8': ['6011','6012','6013'],
}

# Line data: ID_in, length_per_leg_ft, parallel_legs, sum_LD, material, roughness_ft
LINE_DATA = {
    '1041': (11.938, 1830, 1, 260, 'CS', 0.00015),
    '1042': (11.938, 1620, 1, 220, 'CS', 0.00015),
    '1043': (6.065,  480, 4, 210, 'CS', 0.00015),
    '1044': (6.065,  440, 4, 190, 'CS', 0.00015),
    '2011': (7.981,  900, 1, 240, 'CS', 0.00015),
    '2012': (7.981,  780, 1, 220, 'CS', 0.00015),
    '2013': (4.026,  620, 3, 300, 'CS', 0.00015),
    '2021': (7.981,  840, 1, 235, 'CS', 0.00015),
    '2022': (7.981,  750, 1, 215, 'CS', 0.00015),
    '2023': (6.065,  690, 2, 260, 'CS', 0.00015),
    '4021': (6.065,  960, 1, 240, 'CS', 0.00015),
    '4022': (6.065,  880, 1, 220, 'CS', 0.00015),
    '4023': (4.026, 1260, 2, 330, 'CS', 0.00015),
    '4024': (2.945, 1080, 4, 280, 'CU', 0.000005),
    '4031': (6.065,  900, 1, 235, 'CS', 0.00015),
    '4032': (6.065,  820, 1, 215, 'CS', 0.00015),
    '4033': (4.026, 1200, 3, 320, 'CS', 0.00015),
    '4034': (2.945, 1020, 4, 270, 'CU', 0.000005),
    '4041': (6.065, 1140, 1, 250, 'CS', 0.00015),
    '4042': (6.065, 1040, 1, 230, 'CS', 0.00015),
    '4043': (2.945,  900, 3, 250, 'CU', 0.000005),
    '5011': (6.065,  990, 1, 270, 'CS', 0.00015),
    '5012': (6.065,  900, 1, 250, 'CS', 0.00015),
    '5013': (2.465, 1260, 4, 360, 'CU', 0.000005),
    '6011': (4.026, 1140, 1, 300, 'GALV', 0.0005),
    '6012': (4.026, 1040, 1, 280, 'GALV', 0.0005),
    '6013': (3.068,  780, 2, 260, 'GALV', 0.0005),
}

# Equipment: tag -> (circuit, hold_up_gal, bypass_provision, dp_rated_ft, q_rated_gpm, max_allow_dp_ft)
EQUIPMENT = {
    'PMP-101': ('C1', 2400, False, 0, 1200, 40),
    'BT-101':  ('C1', 5000, False, 0, 1200, 15),
    'HX-201A': ('C2', 2350, True,  46, 610, 58),
    'HX-201B': ('C3', 2350, True,  46, 610, 58),
    'CDU-301': ('C4', 1550, True,  38, 380, 48),
    'CP-311':  ('C4', 1030, True,  52, 380, 65),
    'CDU-302': ('C5', 1550, True,  38, 360, 48),
    'CP-321':  ('C5', 1030, True,  52, 360, 65),
    'CP-331':  ('C6', 1450, True,  58, 300, 72),
    'CL-401':  ('C7', 1950, True,  41, 250, 52),
    'ST-601':  ('C8', 3750, False, 6, 120, 25),
}

# Static lift from tie-in to circuit high point (ft, from M-ISO-2xx)
STATIC_LIFT = {'C1': 26, 'C2': 22, 'C3': 22, 'C4': 48, 'C5': 44, 'C6': 48, 'C7': 72, 'C8': 14}

# Circuit location (tie-in) -> power limit kW (from SW-04 / E-701)
CIRCUIT_LOCATION = {'C1':'MER-1','C2':'MER-1','C3':'MER-2','C4':'L3-N','C5':'L3-S','C6':'L3-W','C7':'ROOF','C8':'YARD'}
POWER_LIMIT = {'MER-1':150,'MER-2':95,'L3-N':90,'L3-S':90,'L3-W':90,'ROOF':45,'YARD':120}

# Skid data
SKID_KW = {'FS-600-A':30,'FS-600-B':30,'FS-1200-A':75}
SKID_RATE = {'FS-600-A':430.0,'FS-600-B':430.0,'FS-1200-A':790.0}
SKID_ID_IN = {'FS-600-A':4.026,'FS-600-B':4.026,'FS-1200-A':7.981}
SKID_DELIVERY_HR = {'FS-600-A':0,'FS-600-B':0,'FS-1200-A':48}  # SI-05: FS-1200 at hour 48

SKID_CURVES = {
    'FS-600':  [(0,182),(150,176),(300,163),(450,141),(600,106),(700,74)],
    'FS-1200': [(0,212),(300,204),(600,188),(900,159),(1200,117),(1400,82)],
}
def skid_type(sid): return sid.replace('-A','').replace('-B','')

def skid_head_at(sid, q_gpm):
    curve = SKID_CURVES[skid_type(sid)]
    if q_gpm <= curve[0][0]: return curve[0][1]
    if q_gpm >= curve[-1][0]: return None  # beyond curve
    for i in range(len(curve)-1):
        if curve[i][0] <= q_gpm <= curve[i+1][0]:
            q1,h1=curve[i]; q2,h2=curve[i+1]
            return h1 + (q_gpm-q1)/(q2-q1)*(h2-h1)
    return None

# ---------------------------------------------------------------------------
# Hydraulics
# ---------------------------------------------------------------------------
def colebrook_f(Re, e_over_D):
    if Re < 2000: return 64.0/Re
    f = 0.02
    for _ in range(60):
        fn = 1.0/(-2.0*math.log10(e_over_D/3.7 + 2.51/(Re*math.sqrt(f))))**2
        if abs(fn-f)<1e-12: break
        f = fn
    return f

def hose_strainer_loss(sid, q_gpm):
    """Hose + temporary strainer head loss for one skid at its share of flow (ft w.c.)."""
    D = SKID_ID_IN[sid]/12.0
    A = math.pi/4*D*D
    e = 0.0008   # hose roughness ft (spec 23 21 16 2.2)
    L = 300.0    # ft total run supply+return (VD-05)
    q_cfs = q_gpm/GPM_PER_CFS
    v = q_cfs/A
    Re = v*D/NU
    f = colebrook_f(Re, e/D)
    hose_h = f*(L/D)*v**2/(2*G)
    strainer_h = 11.0*(q_gpm/600.0)**2  # VD-05: 11 ft at 600 gpm, square law
    return hose_h, strainer_h

def compute_circuit(cid):
    lines = CIRCUIT_LINES[cid]
    # Determine min velocity: UFC 3.28 ft/s + project class
    plate_circuits = {'C2','C3','C4','C5','C6'}  # serve plate HX or cold-plate device
    min_vel = UFC_VELOCITY
    if cid in plate_circuits:
        min_vel = max(min_vel, 4.0)

    pipe_vol = 0.0
    max_q = 0.0
    gov_leg = None; gov_id = None
    total_pipe_h = 0.0
    leg_details = []

    for lid in lines:
        ID,L,nlegs,sumLD,mat,e = LINE_DATA[lid]
        Dft = ID/12.0
        A = math.pi/4*Dft*Dft
        pipe_vol += A*L*nlegs*GAL_PER_FT3
        # Flow needed so every leg >= min_vel: Q_total >= min_vel * nlegs * A
        q_req = min_vel * nlegs * A * GPM_PER_CFS
        if q_req > max_q:
            max_q = q_req; gov_leg = lid; gov_id = ID
        # Head loss at this flow (per leg, then summed over all legs since in series)
        q_leg_cfs = (max_q/GPM_PER_CFS)/nlegs  # use max_q for head calc at design flow
        v = q_leg_cfs/A
        Re = v*Dft/NU
        f = colebrook_f(Re, e/Dft)
        Leq = sumLD*Dft
        h = f*((L+Leq)/Dft)*v**2/(2*G)
        total_pipe_h += h
        leg_details.append((lid, v, Re, f, h))

    # System volume = pipe + all equipment hold-up
    sys_vol = pipe_vol
    flush_vol = pipe_vol
    comp_h = 0.0
    for tag,(circ,vol,bypass,dp_rated,q_rated,max_allow) in EQUIPMENT.items():
        if circ==cid:
            sys_vol += vol
            if not bypass:
                flush_vol += vol
                if dp_rated>0:
                    comp_h += dp_rated*(max_q/q_rated)**2

    lift = STATIC_LIFT[cid]
    base_head = lift + total_pipe_h + comp_h

    return {
        'cid':cid,'pipe_vol':pipe_vol,'sys_vol':sys_vol,'flush_vol':flush_vol,
        'q_req':max_q,'gov_leg':gov_leg,'gov_id':gov_id,
        'pipe_h':total_pipe_h,'comp_h':comp_h,'lift':lift,'base_head':base_head,
        'min_vel':min_vel,'leg_details':leg_details,
        'location':CIRCUIT_LOCATION[cid],
    }

# ---------------------------------------------------------------------------
# Skid assignment & head check (per skid at its share of flow)
# ---------------------------------------------------------------------------
def skid_assignment_head(cid, skids):
    """Check if given skid list can serve circuit. Returns (ok, margin_ft, details)."""
    cinfo = compute_circuit(cid)
    q = cinfo['q_req']
    n = len(skids)
    q_each = q/n
    lift = cinfo['lift']; pipe_h = cinfo['pipe_h']; comp_h = cinfo['comp_h']
    margins = []
    for sid in skids:
        h_avail = skid_head_at(sid, q_each)
        if h_avail is None:
            return False, None, f'{sid} beyond curve at {q_each:.0f} gpm'
        hose_h, str_h = hose_strainer_loss(sid, q_each)
        req = lift + pipe_h + comp_h + hose_h + str_h
        margins.append((sid, q_each, h_avail, req, h_avail-req))
    min_margin = min(m[4] for m in margins)
    return min_margin>0, min_margin, margins

# Pre-compute circuit info
CINFO = {cid: compute_circuit(cid) for cid in CIRCUIT_LINES}

# ---------------------------------------------------------------------------
# Rinse displacement model (spec 3.6)
# ---------------------------------------------------------------------------
# Makeup water assumptions (SW-02 scanned - OCR unavailable, documented assumptions)
C_MK = 500.0   # uS/cm, makeup conductivity
PH_MK = 7.5    # makeup pH

# Spent cleaning solution conductivity (VD-06 Note 3)
C0_CL100 = 2600.0
C0_CL210 = 2150.0

# Rinse criterion: conductivity <= 110% of makeup; pH within +/-0.3 of makeup AND 7.5-8.5
CONDUCT_LIMIT = 1.10*C_MK  # 550 uS/cm

def rinse_displacements(cid, cleaner):
    """Compute required rinse displacements n_r."""
    eta = 0.45 if cid in {'C4','C5','C6','C7'} else 0.62  # cold-plate/coil bank circuits
    C0 = C0_CL100 if cleaner=='CL-100' else C0_CL210
    # n >= -ln(0.1*C_mk/(C0-C_mk)) / eta
    ratio = 0.1*C_MK/(C0-C_MK)
    n_min = -math.log(ratio)/eta
    return int(math.floor(n_min))+1, eta, C0

# ---------------------------------------------------------------------------
# Treatment program selection & chemistry
# ---------------------------------------------------------------------------
# Program per circuit (metallurgy + UFC 3-230-13 Table 6-2 + spec 3.5)
# Polysilicate-azole used for all circuits (valid per Table 6-2 for chilled water,
# Table 5-11 has polysilicate passivation entry, safe for galvanized at pH<=8.5)
TREATMENT = {
    'C1':  {'program':'Polysilicate-azole','cleaner':'CL-100','copper':False,'aluminum':False,'galvanized':False},
    'C2':  {'program':'Polysilicate-azole','cleaner':'CL-100','copper':False,'aluminum':False,'galvanized':False},
    'C3':  {'program':'Polysilicate-azole','cleaner':'CL-100','copper':False,'aluminum':False,'galvanized':False},
    'C4':  {'program':'Polysilicate-azole','cleaner':'CL-100','copper':True,'aluminum':False,'galvanized':False},
    'C5':  {'program':'Polysilicate-azole','cleaner':'CL-100','copper':True,'aluminum':False,'galvanized':False},
    'C6':  {'program':'Polysilicate-azole','cleaner':'CL-100','copper':True,'aluminum':True,'galvanized':False},
    'C7':  {'program':'Polysilicate-azole','cleaner':'CL-100','copper':True,'aluminum':False,'galvanized':False},
    'C8':  {'program':'Polysilicate','cleaner':'CL-210','copper':False,'aluminum':False,'galvanized':True},
}

# Product data (VD-06)
PRODUCTS = {
    'CL-100': {'active':None,'density':None,'pkg_gal':5,'pkg_unit':'gal','price':112.0,'lead':10,'rate_gal_per_1000':1.5,'target_ppm':None},
    'CL-210': {'active':None,'density':None,'pkg_gal':5,'pkg_unit':'gal','price':128.0,'lead':14,'rate_gal_per_1000':2.0,'target_ppm':None},
    'MO-500': {'active':'Mo','density':10.9,'active_pct':10,'pkg_gal':5,'pkg_unit':'gal','price':172.0,'lead':21,'rate_gal_per_1000':None,'target_ppm':None},
    'PS-330': {'active':'SiO2','density':9.8,'active_pct':12,'pkg_gal':5,'pkg_unit':'gal','price':139.0,'lead':18,'rate_gal_per_1000':None,'target_ppm':None},
    'NB-700': {'active':'NO2','density':0.0,'active_pct':68,'pkg_lb':50,'pkg_unit':'lb','price':148.0,'lead':10,'rate_gal_per_1000':None,'target_ppm':None},
    'TA-90':  {'active':'TTA','density':8.9,'active_pct':50,'pkg_gal':1,'pkg_unit':'gal','price':92.0,'lead':12,'rate_gal_per_1000':None,'target_ppm':None},
    'PD-45':  {'active':'polymer','density':9.1,'active_pct':40,'pkg_gal':1,'pkg_unit':'gal','price':46.0,'lead':7,'rate_gal_per_1000':None,'target_ppm':None},
    'SA-100': {'active':'Na2CO3','density':0.0,'active_pct':99,'pkg_lb':50,'pkg_unit':'lb','price':62.0,'lead':5,'rate_gal_per_1000':None,'target_ppm':None},
}

def dose_to_volume(ppm_active, basis_gal, product_id):
    """Convert target ppm active to product volume (gal) at basis volume."""
    p = PRODUCTS[product_id]
    if p['active'] is None:
        return None  # volumetric cleaner
    active_lb = ppm_active * basis_gal * DOSING_FACTOR  # lb active
    active_frac = p['active_pct']/100.0
    product_lb = active_lb/active_frac
    product_gal = product_lb/p['density']
    return product_gal

def dose_cleaner(cid, basis_gal):
    """Cleaner dose: volumetric application rate (gal per 1000 gal system vol)."""
    cleaner = TREATMENT[cid]['cleaner']
    p = PRODUCTS[cleaner]
    return p['rate_gal_per_1000']/1000.0 * basis_gal  # gal of product

# ---------------------------------------------------------------------------
# Cost rates
# ---------------------------------------------------------------------------
CREW_SHIFT_RATE = 820.0   # SW-01
WATER_METERED_RATE = 6.20 # $/1000 gal (SW-01 cl.1)
WATER_TRUCKED_RATE = 19.80 # $/1000 gal (SW-01 cl.2)
METERED_ALLOC = 62000     # gal/day (SW-01)
TRUCKED_LIMIT = 30000     # gal/day (SW-01)
MAX_DAY_DRAW = 92000      # gal/day (SW-01 cl.2)
SEWER_RATE = 4.00         # $/1000 gal effluent (assumed from SW-03, scanned)
TANKER_RATE = 168.00      # $/1000 gal hauled (RFI-031)
DISCHARGE_CAP = 540000    # gal programme total at metered connection (RFI-031)

# SI-04 water restrictions (project days from mobilisation)
# Day 2 (hr 48-72): allocation 31000; Day 3 (hr 72-96): allocation 31000; Day 6 (hr 144-168): no metered water

if __name__=='__main__':
    for cid in sorted(CIRCUIT_LINES):
        ci = CINFO[cid]
        print(f"{cid}: Q={ci['q_req']:.1f} gpm, Vflush={ci['flush_vol']:.0f} gal, Vsys={ci['sys_vol']:.0f} gal, base_head={ci['base_head']:.1f} ft, loc={ci['location']}")
        n_r, eta, C0 = rinse_displacements(cid, TREATMENT[cid]['cleaner'])
        print(f"   rinse n_r={n_r}, eta={eta}, C0={C0}")