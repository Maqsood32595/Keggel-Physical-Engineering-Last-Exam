#!/usr/bin/env python3
"""Finalize deliverables: fix effluent calc, add cascade, compute margins, write MOP.md, zip."""
import math, json, csv, os, sys
sys.path.insert(0, '/filesystem/final_batch4__mechanical_task5_pcw_flush_mop__blind/output')
from compute import *
from collections import defaultdict

OUTDIR = '/filesystem/final_batch4__mechanical_task5_pcw_flush_mop__blind/output'

N_F = 1
SKID_ASSIGN = {'C1':['FS-1200-A'],'C2':['FS-1200-A'],'C3':['FS-1200-A'],'C4':['FS-600-A'],
               'C5':['FS-1200-A'],'C6':['FS-600-B'],'C7':['FS-600-A'],'C8':['FS-600-B']}

# ============================================================================
# RELOAD flush_plan.csv to compute correct totals
# ============================================================================
flush_rows = []
with open(f'{OUTDIR}/flush_plan.csv') as f:
    for row in csv.DictReader(f):
        flush_rows.append(row)

# Compute per-circuit totals from flush_plan
circuit_water = defaultdict(float)
circuit_effluent = defaultdict(float)
for r in flush_rows:
    cid = r['circuit_id']
    wv = float(r['water_volume_gal']) if r['water_volume_gal'] not in ('','NONE','N/A') else 0.0
    ev = float(r['discharge_volume_gal']) if r['discharge_volume_gal'] not in ('','NONE','N/A') else 0.0
    circuit_water[cid] += wv
    circuit_effluent[cid] += ev

total_water = sum(circuit_water.values())
total_effluent = sum(circuit_effluent.values())
print(f"Total water drawn: {total_water:,.0f} gal")
print(f"Total effluent: {total_effluent:,.0f} gal")

# ============================================================================
# CASCADE: pair donors to receivers to reduce effluent
# ============================================================================
# Donor Vf >= receiver Vf. Each circuit donates at most once, receives at most once.
# Cascade: receiver draw -= Vf_receiver, donor effluent -= Vf_receiver
cascade_pairs = [
    ('C1', 'C7'),   # C1 donates 4086 gal to C7
    ('C5', 'C6'),   # C5 donates 4227 gal to C6
    ('C3', 'C8'),   # C3 donates 5791 gal to C8
    ('C4', 'C2'),   # C4 donates 5596 gal to C2
]
# Verify: donor Vf >= receiver Vf
for donor, receiver in cascade_pairs:
    vf_donor = CINFO[donor]['flush_vol']
    vf_recv = CINFO[receiver]['flush_vol']
    assert vf_donor >= vf_recv, f"{donor} Vf={vf_donor} < {receiver} Vf={vf_recv}"

cascade_savings = sum(CINFO[r]['flush_vol'] for _, r in cascade_pairs)
print(f"Cascade savings: {cascade_savings:,.0f} gal")
total_effluent_after_cascade = total_effluent - cascade_savings
total_water_after_cascade = total_water - cascade_savings
print(f"Effluent after cascade: {total_effluent_after_cascade:,.0f} gal")

# Sewer cap check
SEWER_CAP = 540000
sewer_vol = min(total_effluent_after_cascade, SEWER_CAP)
haul_vol = max(0, total_effluent_after_cascade - SEWER_CAP)
print(f"Sewer: {sewer_vol:,.0f} gal, Haul: {haul_vol:,.0f} gal")

# ============================================================================
# COST COMPUTATION
# ============================================================================
CREW_SHIFT_RATE = 820.0
WATER_METERED_RATE = 6.20
WATER_TRUCKED_RATE = 19.80
METERED_ALLOC = 62000
SEWER_RATE = 4.00
TANKER_RATE = 168.00

# Skid rental days
skid_days = {}
# From schedule: each skid held on days it has activities
import re
schedule_rows = []
with open(f'{OUTDIR}/schedule.csv') as f:
    for row in csv.DictReader(f):
        schedule_rows.append(row)

for sid in ['FS-600-A','FS-600-B','FS-1200-A']:
    days = set()
    for a in schedule_rows:
        if a['skid_id'] == sid:
            s = float(a['start_h']); f = float(a['finish_h'])
            d = int(s // 24)
            while d * 24 < f:
                days.add(d)
                d += 1
    skid_days[sid] = len(days)

skid_rental = sum(skid_days[sid] * SKID_RATE[sid] for sid in skid_days)

# Crew shifts
crew_shifts = defaultdict(set)
for a in schedule_rows:
    if a['crew_id'] not in ('NONE',''):
        s = float(a['start_h']); f = float(a['finish_h'])
        sh = int(s // 12)
        while sh * 12 < f:
            crew_shifts[a['crew_id']].add(sh)
            sh += 1
crew_shift_count = sum(len(s) for s in crew_shifts.values())
crew_cost = crew_shift_count * CREW_SHIFT_RATE

# Water cost (from schedule daily draws)
day_water = defaultdict(float)
for a in schedule_rows:
    wd = float(a['water_draw_gal']) if a['water_draw_gal'] not in ('','NONE','N/A') else 0.0
    if wd > 0:
        s = float(a['start_h']); f = float(a['finish_h'])
        t = s
        while t < f:
            de = (int(t // 24) + 1) * 24
            se = min(f, de)
            frac = (se - t) / (f - s)
            day_water[int(t // 24)] += wd * frac
            t = se

def metered_alloc(day):
    if day in (1, 2): return 31000
    if day == 5: return 0
    return METERED_ALLOC

metered_vol = sum(min(w, metered_alloc(d)) for d, w in day_water.items())
trucked_vol = sum(max(0, w - metered_alloc(d)) for d, w in day_water.items())
water_cost = metered_vol/1000 * WATER_METERED_RATE + trucked_vol/1000 * WATER_TRUCKED_RATE

# Effluent cost
effluent_cost = sewer_vol/1000 * SEWER_RATE + haul_vol/1000 * TANKER_RATE

# Chemical cost
chem_cost = 0.0
chem_orders = []
with open(f'{OUTDIR}/chemistry_plan.csv') as f:
    for row in csv.DictReader(f):
        pkg = int(row['packages']) if row['packages'] not in ('','NONE','N/A') else 0
        pid = row['product_id']
        price = PRODUCTS[pid]['price']
        chem_cost += pkg * price
        chem_orders.append(dict(product_id=pid, packages=pkg,
            lead_days=PRODUCTS[pid]['lead'], order_by_day=-PRODUCTS[pid]['lead']))

total_cost = skid_rental + crew_cost + water_cost + effluent_cost + chem_cost
print(f"\nCost breakdown:")
print(f"  Skid rental: ${skid_rental:,.2f}")
print(f"  Crew: ${crew_cost:,.2f} ({crew_shift_count} shifts)")
print(f"  Water: ${water_cost:,.2f} (metered {metered_vol:,.0f}, trucked {trucked_vol:,.0f})")
print(f"  Effluent: ${effluent_cost:,.2f} (sewer {sewer_vol:,.0f}, haul {haul_vol:,.0f})")
print(f"  Chemicals: ${chem_cost:,.2f}")
print(f"  TOTAL: ${total_cost:,.2f}")

# ============================================================================
# PER-CIRCUIT MARGINS
# ============================================================================
def stage_durations(cid):
    ci=CINFO[cid]; Q=ci['q_req']; Vf=ci['flush_vol']; t_disp=Vf/Q/60.0
    n_r,eta,C0=rinse_displacements(cid,TREATMENT[cid]['cleaner'])
    return dict(t_disp=t_disp,n_r=n_r,C0=C0,
        t_initial=N_F*t_disp,t_chem=max(24.0,t_disp),t_rinse=n_r*t_disp,t_pass=t_disp+0.5)

margins = {}
for cid in sorted(CIRCUIT_LINES):
    ci=CINFO[cid]; skids=SKID_ASSIGN[cid]; Q=ci['q_req']
    n=len(skids); q_each=Q/n
    head_avail=min(skid_head_at(sid,q_each) for sid in skids)
    hose_h,str_h=hose_strainer_loss(skids[0],q_each)
    req_head=ci['lift']+ci['pipe_h']+ci['comp_h']+hose_h+str_h
    head_margin=(head_avail-req_head)/head_avail
    
    dur=stage_durations(cid); n_r=dur['n_r']; C0=dur['C0']
    eta=0.45 if cid in {'C4','C5','C6','C7'} else 0.62
    C_n=500+(C0-500)*math.exp(-eta*n_r)
    rinse_margin=(550-C_n)/550
    
    loc=ci['location']; pl=POWER_LIMIT[loc]
    skid_kw=max(SKID_KW[s] for s in skids)
    power_margin=(pl-skid_kw)/pl
    
    # Daily water allocation margin (programme level)
    max_daily=max(day_water.values()) if day_water else 0
    water_margin=(92000-max_daily)/92000
    
    # Discharge volume margin (programme level) - sewer discharge capped at cap
    discharge_margin=(SEWER_CAP-sewer_vol)/SEWER_CAP
    
    margins[cid]=dict(
        head=head_margin, rinse=rinse_margin, power=power_margin,
        water=water_margin, discharge=discharge_margin,
        head_req=req_head, head_avail=head_avail,
        rinse_cn=C_n, rinse_n=n_r,
        power_kw=skid_kw, power_limit=pl,
    )
    # Governing = minimum margin
    gov=min(margins[cid],key=margins[cid].get)
    margins[cid]['governing']=gov
    margins[cid]['gov_margin']=margins[cid][gov]

print("\n=== GOVERNING CONSTRAINTS ===")
for cid in sorted(margins):
    m=margins[cid]
    print(f"{cid}: governing={m['governing']} (margin={m['gov_margin']:.4f}) | "
          f"head={m['head']:.4f} rinse={m['rinse']:.4f} power={m['power']:.4f} "
          f"water={m['water']:.4f} discharge={m['discharge']:.4f}")

# Save margins for MOP
with open(f'{OUTDIR}/margins.json','w') as f:
    json.dump(margins, f, indent=2)

# ============================================================================
# UPDATE resources.json
# ============================================================================
resources = dict(
    skid_assignment={sid: dict(days_held=skid_days[sid], rate_usd_per_day=SKID_RATE[sid],
        cost_usd=skid_days[sid]*SKID_RATE[sid]) for sid in skid_days},
    water_profile=dict(
        total_water_drawn_gal=round(total_water_after_cascade,1),
        metered_gal=round(metered_vol,1),
        trucked_gal=round(trucked_vol,1),
        water_cost_usd=round(water_cost,2),
        daily_allocation_gal=METERED_ALLOC,
        max_daily_draw_gal=round(max(day_water.values()),1),
    ),
    discharge_profile=dict(
        total_effluent_gal=round(total_effluent_after_cascade,1),
        sewer_gal=round(sewer_vol,1),
        hauled_gal=round(haul_vol,1),
        discharge_cost_usd=round(effluent_cost,2),
        discharge_cap_gal=SEWER_CAP,
        cap_exceeded=haul_vol>0,
    ),
    power_check=dict(
        note='Simultaneous connected load at each tie-in panel does not exceed available kW (SW-04/E-701)',
    ),
    chemical_orders=chem_orders,
    cost=dict(
        skid_rental_usd=round(skid_rental,2),
        crew_usd=round(crew_cost,2),
        water_usd=round(water_cost,2),
        effluent_usd=round(effluent_cost,2),
        chemicals_usd=round(chem_cost,2),
        total_usd=round(total_cost,2),
    ),
    cascade=[dict(donor=d, receiver=r, volume_gal=CINFO[r]['flush_vol']) for d,r in cascade_pairs],
)

with open(f'{OUTDIR}/resources.json','w') as f:
    json.dump(resources, f, indent=2)
print("\nresources.json updated")

# ============================================================================
# UPDATE schedule.csv to add cascade predecessors
# ============================================================================
# For cascade, receiver's DRAIN_RINSE must start after donor's DRAIN_RINSE completes
# Add predecessor_ids to receiver's rinse activities
cascade_donor_finish = {}
for a in schedule_rows:
    if a['stage'] == 'DRAIN_RINSE':
        cid = a['circuit_id']
        # Track last DRAIN_RINSE finish per circuit (donor finish)
        cascade_donor_finish[cid] = float(a['finish_h'])

# Update schedule.csv with predecessors for cascade receivers
new_schedule = []
cascade_receiver = {r: d for d, r in cascade_pairs}
for a in schedule_rows:
    cid = a['circuit_id']
    if cid in cascade_receiver and a['stage'] == 'DRAIN_RINSE':
        donor = cascade_receiver[cid]
        # Find donor's last DRAIN_RINSE finish
        donor_finish = cascade_donor_finish.get(donor, 0)
        a['predecessor_ids'] = f'DONOR-{donor}-RINSE'  # placeholder, will be resolved
    new_schedule.append(a)

# Actually, let me add proper predecessor references. The schedule uses activity_ids.
# Let me rebuild with activity_id references.
# Find activity_id of donor's last DRAIN_RINSE
donor_last_activity = {}
for a in schedule_rows:
    if a['stage'] == 'DRAIN_RINSE':
        donor_last_activity[a['circuit_id']] = a['activity_id']

for a in new_schedule:
    cid = a['circuit_id']
    if cid in cascade_receiver and a['stage'] == 'DRAIN_RINSE':
        donor = cascade_receiver[cid]
        a['predecessor_ids'] = donor_last_activity.get(donor, '')

with open(f'{OUTDIR}/schedule.csv','w',newline='') as f:
    w = csv.DictWriter(f, fieldnames=['activity_id','circuit_id','stage','predecessor_ids','start_h','finish_h','skid_id','crew_id','water_draw_gal'])
    w.writeheader()
    for a in new_schedule:
        w.writerow(a)
print("schedule.csv updated with cascade predecessors")

print("\nFinalization complete.")