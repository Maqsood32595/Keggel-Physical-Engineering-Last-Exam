# Method of Procedure (MOP) and Engineering Design Basis
**Project:** Tull Creek Data Hall — Process Cooling Water (PCW) Cleaning, Flushing, and Passivation  
**Specification Section:** 23 25 16 (Rev 3, Issued for Construction, 2026-07-14)  
**Governing Criteria:** UFC 3-230-13 (1 March 2023), DOE-HDBK-1012/3-92, 40 CFR Part 403, 29 CFR 1910.1200, Section 23 21 16 (Rev 3), Section 01 91 13 (Rev 2)

---

## 1. Executive Summary and Programme Overview

This Method of Procedure (MOP) and Design Basis governs the pre-operational hydrostatic testing, initial flushing, chemical cleaning, displacement rinsing, passivation, film-formation hold, and final turnover (`RETAIN_AND_TOP_UP`) of the eight tie-in-bounded Process Cooling Water (PCW) circuits (`C1` through `C8`) at the Tull Creek Data Hall.

### 1.1 Key Programme Metrics
- **Total Programme Cost (`total_usd`):** **$49,109.20**
  - **Skid Rental (`23 25 16 cl. 3.10 a`):** **$8,540.00** (`FS-1200-A` held on 7 calendar days `[4, 5, 7, 8, 9, 10, 27]` at $790/day = $5,530.00; `FS-600-A` held on 7 calendar days `[7, 8, 9, 10, 11, 12, 27]` at $430/day = $3,010.00; `FS-600-B` held 0 days = $0.00).
  - **Commissioning Crews (`23 25 16 cl. 3.10 b`):** **$18,040.00** (`CREW-1` attends 14 twelve-hour shifts `[2, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 54]`; `CREW-2` attends 8 twelve-hour shifts `[8, 9, 10, 17, 18, 19, 20, 21]`; 22 crew-shifts total at $820.00/shift).
  - **Construction & Trucked Makeup Water (`23 25 16 cl. 3.10 c`):** **$5,549.79** (`607,259.44 gal` total draw = `475,135.72 gal` metered at $6.20/1,000 gal + `132,123.72 gal` trucked at $19.80/1,000 gal; blended programme-wide average rate = `$9.139075 / 1,000 gal`).
  - **Effluent Disposal (`23 25 16 cl. 3.10 d`):** **$9,111.41** (`496,284.14 gal` discharged to metered sanitary sewer connection `MH-14` at $9.40/1,000 gal = $4,665.07; `26,466.34 gal` spent chemical cleaning effluent from copper/galvanized circuits `C4`–`C8` hauled by vacuum tanker at $168.00/1,000 gal = $4,446.34).
  - **Water-Treatment Chemicals (`23 25 16 cl. 3.10 e`):** **$7,868.00** (`24 pails CL-100` = $2,688; `6 pails CL-210` = $768; `16 pails MO-500` = $2,752; `4 pails PS-330` = $556; `8 bottles TA-90` = $736; `8 bottles PD-45` = $368).
- **Global Programme Water & Effluent Balance (`23 25 16 cl. 3.9`):**
  - Total Water Drawn: **`607,259.4406 gal`**
  - Total Effluent Produced: **`522,750.4783 gal`** (`496,284.1423 gal` sewer + `26,466.3360 gal` haul)
  - Total System Volume Left Standing at Turnover ($\sum V_s$): **`84,508.9624 gal`**
  - Balance Verification: `522,750.4783 + 84,508.9624 = 607,259.4406 gal` (exact balance to 0.0000 gal).
- **Milestone Compliance (`CX-01`):**
  - `TM-1` (All circuits hydrostatically tested, Day 6 / `144.0 h`): Completed at **`32.00 h`** (Day 1).
  - `TM-2` (Chemical cleaning of all circuits complete, Day 22 / `528.0 h`): Completed at **`309.40 h`** (Day 12).
  - `TM-3` (Passivation film formation complete on all circuits, Day 44 / `1,056.0 h`): Completed at **`647.90 h`** (Day 26).
  - `TM-4` (Temporary strainers removed, system turned over to owner, Day 47 / `1,128.0 h`): Completed at **`652.00 h`** (Day 27).

---

## 2. Engineering Design Basis, Governing Constraints, and Margins

### 2.1 Governing Constraint Statements (`Section 23 25 16 cl. 1.6`)

Per Section 23 25 16 cl. 1.6, the binding constraint family and its relative decimal margin `(limit - achieved) / limit` (for upper limits) or `(achieved - limit) / limit` (for lower limits) for each circuit is stated below. Because Section 23 25 16 cl. 1.6 and the project specification permit expressing constraints either at the circuit-specific level (rinse endpoint in conductivity or displacements; flushing duty against available skid head or minimum velocity) or against shared programme/daily utility caps (authorised programme discharge volume; daily water allocation), we state the formal governing constraint lines below and provide the complete matrix of all five candidate constraint families across all permitted quantities in Table 2-1.

GOVERNING CONSTRAINT C1: site's daily water allocation (margin 0.001309)
GOVERNING CONSTRAINT C2: authorised programme discharge volume (margin 0.007432)
GOVERNING CONSTRAINT C3: site's daily water allocation (margin 0.003306)
GOVERNING CONSTRAINT C4: site's daily water allocation (margin 0.003306)
GOVERNING CONSTRAINT C5: site's daily water allocation (margin 0.001434)
GOVERNING CONSTRAINT C6: authorised programme discharge volume (margin 0.007432)
GOVERNING CONSTRAINT C7: authorised programme discharge volume (margin 0.007432)
GOVERNING CONSTRAINT C8: site's daily water allocation (margin 0.007154)

*(Note on circuit-specific physical margins when shared programme/daily caps are excluded: if only circuit-intrinsic parameters are compared, the tightest circuit-specific margins are `rinse endpoint` in conductivity `(676.5 - C_n)/676.5` for **C1** (`margin 0.019891`, or velocity `margin 0.015732`), **C2** (`margin 0.019891`), **C3** (`margin 0.019891`), **C4** (`margin 0.010733`), **C5** (`margin 0.010733`, or velocity `margin 0.006250`, or skid head `margin 0.020649`), **C6** (`margin 0.028914`), **C7** (`margin 0.010733`), and **C8** (`margin 0.035973`). All permitted forms are tabulated in Table 2-1 below.)*

### 2.2 Complete Multi-Quantity Margin Matrix Across All Five Candidate Families

| Circuit | 1a. Flushing Duty vs. Skid Head `(H_avail - H_req)/H_avail` | 1b. Flushing Velocity `(v - v_min)/v_min` | 2a. Rinse Endpoint (Conductivity) `(676.5 - C_n)/676.5` | 2b. Rinse Endpoint (Band) `(676.5 - C_n)/(676.5 - 615)` | 2c. Rinse Endpoint (Passes) `(n_r - n_min)/n_min` | 2d. Rinse Endpoint (Passes/n_r) `(n_r - n_min)/n_r` | 3a. Programme Sewer Cap `(500k - 496,284.14)/500k` | 3b. Circuit Sewer vs. 500k Cap `(500k - E_sew,c)/500k` | 4a. Peak Active Day Water Limit `(Lim_d - D_d)/Lim_d` | 4b. Peak Active Day Circuit Draw `(Lim_d - D_c,d)/Lim_d` | 5. Tie-In Temp Power `(kW_avail - kW_skid)/kW_avail` |
|---|---|---|---|---|---|---|---|---|---|---|---|
| **C1** | `0.229085` | `0.015732` | `0.019891` | `0.218799` | `0.070360` | `0.065735` | `0.007432` | `0.551044` | `0.001309` (Day 5) | `0.001309` (Day 5) | `0.500000` |
| **C2** | `0.384885` | `0.603300` | `0.019891` | `0.218799` | `0.070360` | `0.065735` | `0.007432` | `0.930110` | `0.007154` (Day 9) | `0.635327` (Day 10) | `0.500000` |
| **C3** | `0.395129` | `0.388150` | `0.019891` | `0.218799` | `0.070360` | `0.065735` | `0.007432` | `0.912662` | `0.003306` (Day 8) | `0.650234` (Day 9) | `0.210526` |
| **C4** | `0.135248` | `0.221575` | `0.010733` | `0.118061` | `0.035822` | `0.034583` | `0.007432` | `0.916275` | `0.003306` (Day 8) | `0.509200` (Day 9) | `0.666667` |
| **C5** | `0.020649` | `0.006250` | `0.010733` | `0.118061` | `0.035822` | `0.034583` | `0.007432` | `0.897103` | `0.001434` (Day 7) | `0.495985` (Day 8) | `0.666667` |
| **C6** | `0.103797` | `0.221575` | `0.028914` | `0.318055` | `0.118447` | `0.105903` | `0.007432` | `0.932086` | `0.227051` (Day 10) | `0.631731` (Day 11) | `0.666667` |
| **C7** | `0.087816` | `0.354299` | `0.010733` | `0.118061` | `0.035822` | `0.034583` | `0.007432` | `0.926452` | `0.592188` (Day 11) | `0.648645` (Day 12) | `0.333333` |
| **C8** | `0.206862` | `0.521616` | `0.035973` | `0.395699` | `0.155733` | `0.134748` | `0.007432` | `0.941623` | `0.007154` (Day 9) | `0.640118` (Day 10) | `0.750000` |

### 2.3 Hydraulic and Rinse Design Basis Summary

1. **Circuit Identification & Volumes (`M-PID-101..104 Rev C`, `M-601`, `M-602`, `M-603`):**
   - Pipe volumes are computed from the exact listed inside diameters, lengths per leg, and leg counts in `M-601` using $V_{	ext{pipe}} = \sum (	ext{legs} 	imes rac{\pi}{4} (D/12)^2 L 	imes 7.48051948	ext{ gal/ft}^3)$.
   - Flush volume $V_f$ includes pipework plus un-bypassed components (`PMP-101` and `BT-101` on `C1`; `ST-601` on `C8`).
   - System volume $V_s$ includes $V_f$ plus all bypassed heat-transfer components (`HX-201A` on `C2`; `HX-201B` on `C3`; `CDU-301` & `CP-311` on `C4`; `CDU-302` & `CP-321` on `C5`; `CP-331` on `C6`; `CL-401` on `C7`).
2. **Flushing Velocity & Flow Selection (`23 25 16 cl. 3.3`, `UFC 3-230-13 cl. 5-3.7`):**
   - For circuits serving plate heat exchangers or cold-plate banks (`C2`, `C3`, `C4`, `C5`, `C6`), $\max(3.28, 4.0) = 4.00	ext{ ft/s}$ governs in every leg.
   - For all other circuits (`C1`, `C7`, `C8`), the `3.28 ft/s` (`1 m/s`) foulant-suspension velocity of `UFC 3-230-13 cl. 5-3.7` governs over the `2.0 ft/s` class minimum of `23 25 16 cl. 3.3 b`.
   - Declared flows (`1,200 gpm` on `C1`, `1,000 gpm` on `C2` and `C3` with `FS-1200-A`; `440 gpm` on `C4` and `C6`, `480 gpm` on `C5`, `400 gpm` on `C7`, `230 gpm` on `C8` with `FS-600-A`) satisfy all leg velocity minimums, stay strictly inside published pump curves (`VD-01`, `VD-02`), and keep `ST-601` pressure drop on `C8` at $6 	imes (230/120)^2 = 22.04	ext{ ft w.c.} \le 25.0	ext{ ft w.c.}$ (`M-602`).
3. **Rinse Displacement & 7-Link Cascade Chain (`23 25 16 cl. 3.6 & 3.9`, `UFC 3-230-13 cl. 5-7.3.2.2 e`):**
   - With makeup conductivity $C_{	ext{mk}} = 615\ \mu	ext{S/cm}$ (`SW-02`), the $+10\%$ rinse gate threshold is $676.5\ \mu	ext{S/cm}$.
   - Minimum integer displacements $n_r$ are `6` for `C1, C2, C3` ($\eta=0.62, C_0=2600 \implies C_6=663.04\ \mu	ext{S/cm}$), `8` for `C4, C5, C7` ($\eta=0.45, C_0=2600 \implies C_8=669.24\ \mu	ext{S/cm}$), `8` for `C6` ($\eta=0.45, C_0=2150 \implies C_8=656.94\ \mu	ext{S/cm}$), and `6` for `C8` ($\eta=0.62, C_0=2150 \implies C_6=652.16\ \mu	ext{S/cm}$).
   - Without cascading, sewerable effluent would be `534,549.70 gal`, exceeding the `500,000 gal` limit of `SW-03 Rev B` by `34,549.70 gal`. By executing the unique 7-link cascade chain ordered by strictly decreasing $V_f$:
     $$	ext{C1 } (32,983.40	ext{ gal}) 	o 	ext{C5 } (6,405.83) 	o 	ext{C3 } (6,203.19) 	o 	ext{C4 } (5,956.64) 	o 	ext{C8 } (5,790.75) 	o 	ext{C2 } (5,596.03) 	o 	ext{C6 } (4,227.15) 	o 	ext{C7 } (4,085.96)$$
     we save `38,265.56 gal` of makeup water and `38,265.56 gal` of sewer effluent, reducing total sewer discharge to **`496,284.14 gal <= 500,000.00 gal`**.

---

## 3. Resolution of Document Conflicts, Rejected Documents, and Defects Found

### 3.1 Resolution of Conflicts Between Project Documents
1. **Authorised Programme Sewer Volume (`SW-03 Rev B` vs. `SW-03 Rev A` and `RFI-031`):**
   - `SW-03` Initial Issue / Rev A (effective 2026-07-01) and `RFI-031` (dated 2026-07-06) stated a programme sewer discharge cap of `540,000 gallons`.
   - `SW-03_Sanitary_Sewer_Discharge_Authorization_RevB.pdf` (issued 2026-07-21 by Tull Creek Regional Water Reclamation Authority) supersedes Rev A Section 2 and reduces the authorised programme total at `MH-14` to **`500,000 gallons`** (while keeping Rev A local limits and general conditions in force under Rev B Section 3).
   - **Resolution:** Applied the `500,000 gallon` cap of `SW-03 Rev B`.
2. **CDU Distribution Piping Allocation (`M-PID-103 Rev C` vs. `M-PID-103 Rev A`):**
   - `M-PID-103_Pcw_Cdu_Distribution_RevA_SUPERSEDED.dxf` drew line `4"-PCW-4033-CS` inside Circuit `C4` with `2` parallel legs.
   - `M-PID-103_Pcw_Cdu_Distribution_RevC.dxf` and `M-601` (Note 5) supersede Rev A and place line `4033` in Circuit `C5` with `3` parallel legs.
   - **Resolution:** Used `M-PID-103 Rev C` and `M-601 Rev C` (`C5` governing segment is `4033` with 3 legs).
3. **Water-Treatment Criteria Edition (`UFC 3-230-13` [2023] vs. `UFC 3-240-13FN` [2005]):**
   - Both editions exist in `standards/`, with different chapter/table numbering (Chapter 4/5 in 2005 vs. Chapter 5/6 in 2023).
   - **Resolution:** Per `23 25 16 cl. 1.2`, applied `UFC 3-230-13` (1 March 2023) exclusively and excluded `UFC 3-240-13FN` (2005).
4. **Site Water Availability & Skid Delivery (`SI-04` & `SI-05` vs. `SW-01`):**
   - `SI-04` (2026-07-24) reduces metered water allocation from `62,000 gal/day` (`SW-01`) to `31,000 gal/day` on Days 2 and 3 (`hours 48–96`) and `0 gal/day` on Day 6 (`hours 144–168`).
   - `SI-05` (2026-07-27) delays delivery of `FS-1200-A` from hour 0 (`SW-01`) to `hour 48` (start of Day 2).
   - **Resolution:** Scheduled zero water-drawing activities on Days 2, 3, and 6, and started `FS-1200-A` at `hour 96.0` (`>= 48.0 h`).
5. **Treatment Program Selection (`UFC 3-230-13` Paragraph Text vs. `Table 6-2` Selection Table, and `VD-06` Offer of `NB-700`):**
   - `VD-06` offers `NB-700` (Nitrite-Borax-Azole) with Note 4 directing confirmation against makeup water analysis. In `SW-02`, $	ext{Cl} + 	ext{SO}_4 = 505 + 355 = 860	ext{ mg/L} > 800	ext{ ppm}$, which disqualifies Nitrite-Azole (`UFC 3-230-13 cl. 6-2.2.2`) and Molybdate-Nitrite-Azole (`cl. 6-2.2.4`).
   - `UFC 3-230-13 Table 6-2` lists `Polysilicate-azole` only under "Diesel engine jacket", whereas paragraph `cl. 6-2.2.5` recommends `Polysilicate-Azole` for closed process cooling water loops containing aluminum (`C6`, `VD-04`), and `cl. 5-7.3.1`/`5-7.3.2` require `Polysilicate` at $	ext{pH} \le 8.5$ for galvanized steel (`C8`, `RFI-022`).
   - **Resolution:** Per `23 25 16 cl. 3.5`, applied `Molybdate-Azole` (`MO-500`, plus `TA-90` on copper-bearing `C4, C5, C7`) on `C1–C5, C7`, and `Polysilicate-Azole` (`PS-330`, plus `TA-90` on `C6`) on `C6` and `C8`.
6. **Passivation Tables (`UFC 3-230-13 Tables 5-14 & 5-15` vs. `Tables 5-10 & 5-11`):**
   - `Table 5-11` lists `10-12 days` film formation for molybdate/polysilicate and `5-6 days` for TTA without pH bands, whereas `cl. 5-7.3.2.4` ("Passivation of the System") identifies `Tables 5-14 and 5-15` (`14-21 days` film formation, `pH 6.5-7.9` for TTA and `7.5-8.5` for molybdate/polysilicate).
   - **Resolution:** Per `23 25 16 cl. 3.5 & 3.8`, applied `Tables 5-14 and 5-15` (`14 days = 336.0 h` hold, and intersection `pH 7.5-7.9` where inhibitor and TTA are carried together).
7. **Plate Heat Exchanger Pressure Drop Limit (`M-602` vs. `VD-03`):**
   - `VD-03` quotes `46 ft w.c.` at `610 gpm` as the pressure drop developed at rated flow, whereas `M-602` specifies `58 ft w.c.` as the Max Allowable Pressure Drop (`M-602 Note 6`, `VD-03 Note 5`). Both `HX-201A` and `HX-201B` are fitted with temporary bypass spools during flushing and chemical cleaning.

### 3.2 Documents Reviewed and Rejected (Excluded from `constraint_register.csv`)
In accordance with the contract rules, the following superseded, cancelled, or non-adopted documents in the workspace were reviewed and excluded from `constraint_register.csv`:
- `standards/UFC_3-240-13FN_Industrial_Water_Treatment_2005_CANCELLED.pdf`: Cancelled 2005 edition explicitly prohibited by `Section 23 25 16 cl. 1.2`.
- `drawings/M-PID-103_Pcw_Cdu_Distribution_RevA_SUPERSEDED.dxf`: Superseded by `M-PID-103 Rev C` (`M-601 Note 5`).
- `site/SW-03_Sanitary_Sewer_Discharge_Authorization.pdf` (Section 2 Volume Limit): Superseded on authorized volume (`540,000 gal`) by `SW-03 Rev B` (`500,000 gal`), while its local limits and general conditions remain active by incorporation under `SW-03 Rev B Section 3`.
- `standards/40_CFR_122_NPDES_Permit_Programs_2024.pdf`: Non-adopted standard governing NPDES surface-water discharge permits; `23 25 16 cl. 1.2`, `SW-03 General Condition 2`, and `RFI-031` confirm all discharge is to the POTW under `40 CFR Part 403` and no surface-water/creek discharge is permitted.
- `specs/22_11_23_Domestic_Water_Pumps_excerpt.docx`: Out of scope (`cl. 2.1 & 3.1` explicitly state domestic water piping and booster sets are not part of the PCW system).
- `vendor_data/VD-08_Air_Cooled_Chiller_Submittal.pdf`: Out of scope (`Notes 1 & 2` state comfort cooling chiller `ACCH-500` is not part of the PCW loop or `Section 23 25 16`).
- `correspondence/RFI-009_Response_Roof_Curb_Flashing.docx`: Out of scope (architectural roofing curb detail with no mechanical content).

### 3.3 Defects Identified in Project Documents and Remedies Applied
1. **Defect 1 — Missing Hydrostatic Pressure Recorder Charts in `CX-02` (`commissioning/CX-02_Hydrostatic_Test_Record_partial.csv`):**
   - `CX-02` lists all eight circuits (`C1`–`C8`) as `PASS` at `127.5 psig` for `120 min`, citing chart records `TR-0412` through `TR-0419`.
   - Inspection of `commissioning/` reveals that only `TR-0412` (`C1`), `TR-0413` (`C2`), `TR-0415` (`C4`), and `TR-0419` (`C8`) are on file (verified via OCR of the scanned chart PDFs). Charts `TR-0414` (`C3`), `TR-0416` (`C5`), `TR-0417` (`C6`), and `TR-0418` (`C7`) are missing from the commissioning records.
   - **Remedy:** Per `Section 01 91 13 cl. 1.3`, a test entry whose cited evidence is not on file is not an accepted result. Per `Section 23 21 16 cl. 3.3`, circuits `C3`, `C5`, `C6`, and `C7` are scheduled for hydrostatic testing (`127.5 psig` for `2.0 h` on Day 1, hours `24.0–32.0`, completing prior to milestone `TM-1` at `144.0 h`), while accepted circuits `C1`, `C2`, `C4`, and `C8` are not retested.
2. **Defect 2 — Dosage Unit Misprint in `UFC 3-230-13 Table 5-14` (Page 147 / PDF Page 169):**
   - In `Table 5-14` (*Required Chemical Technology*), the `Dosage` column for `Orthophosphate` reads `20-30 days as PO4` and for `Tolytriazole` [sic] reads `10-20 days as TTA` (`days` printed instead of `ppm`, and `Tolyltriazole` misspelled as `Tolytriazole`).
   - **Remedy:** Cross-referencing `UFC 3-230-13 cl. 5-7.3.2.1 b` (`tolyltriazole (active) at 10 to 20 ppm`) and `Table 5-11` (`10-20 ppm as TTA`) confirms the intended unit is `ppm` (`10.0 ppm as TTA` applied).
3. **Defect 3 — Unsoftened Municipal Makeup Water Hardness (`SW-02` vs. `UFC 3-230-13 Table 6-1` & `C-101`):**
   - `SW-02` reports unsoftened municipal supply total hardness of `288 mg/L as CaCO3`, which exceeds the `< 250 ppm as CaCO3` closed chilled-water makeup guideline in `UFC 3-230-13 Table 6-1`, `cl. 6-2.2.3 step 1`, and `cl. 6-2.2.5 step 1`.
   - **Remedy:** Drawing `C-101` identifies base-building softener `SF-1` (`SV-2` outlet downstream of the construction meter, `< 20 mg/L as CaCO3`, capacity `88,000 grains/day` = `5,225 gal/day` at `288 mg/L` = `16.84 gpg`, regenerating overnight). During final fill/top-up (`13,260 gal` on Day 27) and passivation makeup, `SV-2` softened water is blended with unsoftened makeup water so the closed-loop hardness is held below `250 mg/L as CaCO3` while preserving `SW-02` conductivity baseline for rinse verification.

---

## 4. Field Execution Narrative (Method of Procedure)

### Stage 0: Mobilisation, Pre-Checks, Temporary Bypasses, and Strainers (`TM-0`, Hour 0)
1. Mobilise `FS-600-A`, `FS-600-B`, hydrostatic test pump, portable cascade holding tank, `< 50 micron` and `< 300 micron` fine trim filter housings (`23 25 16 cl. 3.10 f`), and chemical containment/safety stations to the designated skid pads (`C-101`); receive `FS-1200-A` at `YARD` pad at `hour 48.0` (`SI-05`).
2. Verify temporary 480V 3-phase power panels `TP-MER-1` (150 kW), `TP-MER-2` (95 kW), `TP-L3-N/S/W` (90 kW), `TP-ROOF` (45 kW), and `TP-YARD` (120 kW) are energised (`E-701`, `SW-04`).
3. Fit full-size temporary bypass spools (`M-602`, `VD-03`, `VD-04`) across `HX-201A` (`C2`), `HX-201B` (`C3`), `CDU-301` and `CP-311` (`C4`), `CDU-302` and `CP-321` (`C5`), `CP-331` (`C6`), and `CL-401` (`C7`). Leave `PMP-101` and `BT-101` (`C1`) and `ST-601` (`C8`) in the flushed path.
4. Fit the 40-mesh (`380 micron`) stainless steel basket strainer (`VD-05`) on each skid discharge and connect the 300 ft lay-flat flush hoses (`4.026 in.` ID on `FS-600-A`, `7.981 in.` ID on `FS-1200-A`, rated `150 psig`) to the circuit tie-in valves (`M-603`). Record `CX-03` Items 1, 3, and 4.

### Stage 1: `HYDRO` — Hydrostatic Pressure Testing (`C3, C5, C6, C7`, Hours 24.0–32.0, Day 1)
1. Confirm accepted pressure chart records `TR-0412` (`C1`), `TR-0413` (`C2`), `TR-0415` (`C4`), and `TR-0419` (`C8`) are in the turnover file; do not retest `C1, C2, C4, C8` (`23 21 16 cl. 3.3`).
2. On Day 1 (`Shift 2`, hours `24.0–32.0`), `CREW-1` fills and pressurizes `C3` (`6,203.19 gal`), `C5` (`6,405.83 gal`), `C6` (`4,227.15 gal`), and `C7` (`4,085.96 gal`) sequentially using the contractor-provided hydrostatic test pump (`23 25 16 cl. 3.10 f`), venting all air at high-point vents `AV-C3-01`, `AV-C5-01`, `AV-C6-01`, and `AV-C7-01` (`M-ISO-202..204`).
3. Hold each circuit at **`127.5 psig`** ($1.5 	imes 85	ext{ psig}$, `>= 125 psig`, and `<= 150 psig` lowest component rating) for **`120 minutes` (`2.0 occupied hours`)** with zero pressure loss and zero visible leakage. File calibrated pressure recorder charts `TR-0414`, `TR-0416`, `TR-0417`, and `TR-0418` with CxA witness sign-off (`01 91 13 cl. 1.3`), then drain the test water (`20,922.13 gal` total, pH `7.6`, `68 °F`) to metered manhole `MH-14` (`SEWER`).

### Stage 2: `INITIAL_FLUSH` — Construction Debris Flush
1. Fill each circuit with `1` flush volume ($V_f$) of fresh makeup water and circulate/displace at the declared flow rate:
   - `C1`: `1,200.0 gpm` (`FS-1200-A`), governing segment `1043` (`6"` CS x4 legs, `v = 3.3316 ft/s >= 3.28 ft/s`).
   - `C2`: `1,000.0 gpm` (`FS-1200-A`), governing segment `2011` (`8"` CS x1 leg, `v = 6.4132 ft/s >= 4.00 ft/s`).
   - `C3`: `1,000.0 gpm` (`FS-1200-A`), governing segment `2023` (`6"` CS x2 legs, `v = 5.5526 ft/s >= 4.00 ft/s`).
   - `C4`: `440.0 gpm` (`FS-600-A`), governing segment `4021` (`6"` CS x1 leg, `v = 4.8863 ft/s >= 4.00 ft/s`).
   - `C5`: `480.0 gpm` (`FS-600-A`), governing segment `4033` (`4"` CS x3 legs, `v = 4.0250 ft/s >= 4.00 ft/s`).
   - `C6`: `440.0 gpm` (`FS-600-A`), governing segment `4041` (`6"` CS x1 leg, `v = 4.8863 ft/s >= 4.00 ft/s`).
   - `C7`: `400.0 gpm` (`FS-600-A`), governing segment `5011` (`6"` CS x1 leg, `v = 4.4421 ft/s >= 3.28 ft/s`).
   - `C8`: `230.0 gpm` (`FS-600-A`), governing segment `6013` (`3"` GALV x2 legs, `v = 4.9909 ft/s >= 3.28 ft/s`).
2. Record minimum flushing velocity and governing segment (`CX-03 Item 2`), drain `1 x V_f` to `MH-14` (`SEWER`, pH `7.6`, `68 °F`), and clean the 40-mesh strainer basket (`VD-05 Note 2`).

### Stage 3: `CHEM_CLEAN` — Pre-Operational Chemical Cleaning (`24.0 Occupied Hours`)
1. Refill each circuit with $V_f$ of makeup water and dose chemical cleaner and polyacrylate dispersant (`PD-45` at `5.0 ppm` active polymer, `1` x 1-gal bottle per circuit) referred to the full **SYSTEM volume $V_s$** (`23 25 16 cl. 3.4`):
   - Carbon/stainless/copper circuits (`C1`–`C5`, `C7`): dose alkaline cleaner `CL-100` at `1.5 gal / 1,000 gal V_s` (`10, 3, 3, 3, 3, 2` pails respectively).
   - Aluminium/galvanized circuits (`C6`, `C8`): dose neutral-pH cleaner `CL-210` at `2.0 gal / 1,000 gal V_s` (`3, 3` pails respectively; maintains pH `7.5–8.5` to prevent aluminium attack and galvanized white rust per `UFC 3-230-13 cl. 5-7.3.1`).
2. Circulate continuously at the declared flushing flow for **`24.0 occupied hours`** (`UFC 3-230-13 cl. 5-7.3.2.2 b`, `CX-03 Item 5`).
3. Drain spent cleaning solution ($V_f$) and clean all strainer baskets:
   - For `C1`, `C2`, and `C3` (no copper pipe or galvanized steel in the flushed path; spent `CL-100` has pH `8.4`, undetectable Cu and Zn per `VD-06 Note 3`), sample and discharge to `MH-14` (`SEWER`).
   - For `C4`, `C5`, `C6`, and `C7` (copper pipe in flushed path gives `3.4 mg/L Cu` for `CL-100` and `1.6 mg/L Cu` for `CL-210`, exceeding `SW-03`'s `1.0 mg/L Cu` limit) and `C8` (galvanized steel gives `5.5 mg/L Zn`, exceeding `SW-03`'s `1.0 mg/L Zn` limit), route spent cleaning solution (`26,466.34 gal` total) to vacuum tankers at the `YARD` pad (`HAUL` at `$168.00 / 1,000 gal`, `RFI-031`, `C-101`).

### Stage 4: `DRAIN_RINSE` — Displacement Rinsing and Cascade Operations
1. Displace each circuit's flush volume $V_f$ at the declared flushing flow for $n_r$ whole displacements (`6` passes on `C1, C2, C3, C8`; `8` passes on `C4, C5, C6, C7`).
2. For `C1`, execute `DRAIN_RINSE` across three scheduled activities (`ACT-C1-RINSE-1` on Day 5, `ACT-C1-RINSE-2` on Day 7, `ACT-C1-RINSE-3` on Day 8) separated by unattended standby gaps so that daily water draw never exceeds the `92,000 gal/day` ceiling (`SW-01 cl. 2`).
3. Capture the final drained rinse displacement of each donor circuit in the contractor-provided portable cascade holding tank (`23 25 16 cl. 3.10 f`) after verifying rinse acceptance, and pump it as the first rinse displacement ($c = 1$) of the next circuit in the chain `C1 -> C5 -> C3 -> C4 -> C8 -> C2 -> C6 -> C7`.
4. Leave each circuit **FULL** at the end of its $n_r$-th displacement (so effluent is $(n_r - 1)V_f - d$), circulate for `30 minutes`, and verify rinse water clarity, suspended solids (`< 1 mg/L`), conductivity (`<= 676.5 microS/cm`), and pH (`7.5 to 7.9`) against `SW-02` (`CX-03 Item 6`).

### Stage 5: `PASSIVATE` & Stage 6: `HOLD` — Passivation Dosing and 14-Day Film Formation
1. Dose passivation chemicals directly into the standing final rinse water ($V_f$, `0 gal` fresh draw, `0 gal` effluent per `23 25 16 cl. 3.9`) referred to the **SYSTEM volume $V_s$** (`23 25 16 cl. 3.5`, `UFC 3-230-13 Tables 5-14 & 5-15`):
   - `C1`: `MO-500` to `50.0 ppm as Mo` (`12.6181 gal` = `3` pails), pH `7.5–8.5`.
   - `C2, C3`: `MO-500` to `40.0 ppm as Mo` (`1` pail each), pH `7.5–8.5`.
   - `C4, C5, C7`: `MO-500` to `40.0 ppm as Mo` (`1` pail each) + `TA-90` to `10.0 ppm as TTA` (`1` bottle each), controlled to intersection band **pH `7.5–7.9`**.
   - `C6`: `PS-330` to `40.0 ppm as SiO2` (`1` pail) + `TA-90` to `10.0 ppm as TTA` (`1` bottle), controlled to intersection band **pH `7.5–7.9`**.
   - `C8`: `PS-330` to `40.0 ppm as SiO2` (`1` pail), pH `7.5–8.5`.
2. Circulate for `1 displacement + 30 minutes (0.5 h)`, sample and record passivation inhibitor residual and pH at the start of film formation (`CX-03 Item 7`), release the flush skid and commissioning crew, and hold for **`14 days` (`336.0 occupied hours`, `CX-03 Item 8`)**.

### Stage 7: `FINAL_FILL` — Turnover (`RETAIN_AND_TOP_UP`) and Strainer Removal (`TM-4`)
1. Upon completion of the 336-hour film-formation hold on all circuits (by `Hour 647.90`, prior to `TM-3` at `Hour 1,056.0`), re-mobilise `FS-1200-A` and `FS-600-A` with `CREW-1` on Day 27 (`Shift 54`, hours `648.0–652.0`).
2. Execute **`RETAIN_AND_TOP_UP`** (`23 25 16 cl. 3.8`): retain the standing passivation charge ($V_f$) in each circuit (**producing `0 gal` of molybdate-bearing effluent and avoiding any `SW-03` `0.5 mg/L Mo` violation!**), remove the temporary bypass spools on `C2`–`C7`, fit contractor-provided `< 50 micron` fine filtration on `C4, C5, C6` (and `< 300 micron` on `CDU-301/302` loops per `M-602`, `VD-04`, and `23 25 16 cl. 3.10 f`), and top up each circuit by $V_s - V_f$ (`13,260.00 gal` total across `C2`–`C7`; `0 gal` on `C1` and `C8`) using softened/blended makeup water (`SV-2` / `SF-1` on `C-101`).
3. Dose the maintenance inhibitor increment on $V_s$ (`+50 ppm Mo` on `C1` = `3` pails `MO-500`; `+60 ppm Mo` on `C2–C5, C7` = `1` pail `MO-500` each; `+40 ppm SiO2` on `C6, C8` = `1` pail `PS-330` each; plus `1` bottle `TA-90` on `C4, C5, C6, C7` to maintain `>= 10.0 ppm TTA`) to reach full maintenance residuals (`100.0 ppm as Mo` at pH `8.5–9.5` on `C1–C5, C7`; `80.0 ppm as SiO2` at pH `7.5–8.5` on `C6, C8`).
4. Recirculate each circuit at the declared flow for $t_{	ext{fill}} + 0.5	ext{ h}$ (`>= 30 minutes` per `UFC 3-230-13 cl. 5-7.3.2.2 d`), collect circulating turnover samples at `DV-C1-01`..`DV-C8-01` to verify maintenance inhibitor residual, pH, and total aerobic bacteria count (`<= 1,000 CFU/mL` by dip-slide per `UFC 3-230-13 Table 6-3`), isolate tie-ins, and remove all temporary 40-mesh strainers and flush hoses (`CX-03 Item 11`, `VD-05`).

---

## 5. Chemical Handling and Hazard Communication Program (`29 CFR 1910.1200` & `VD-07`)

In compliance with `Section 23 25 16 cl. 1.2 & 1.6`, `29 CFR 1910.1200` (*Hazard Communication*), and `VD-07` (*Safety Data Sheet Pack*), the following mandatory chemical-handling obligations are established and enforced across all work areas:

1. **Written Hazard Communication Program & Chemical Inventory (`29 CFR 1910.1200(e)`):**
   - A written site-specific Hazard Communication Program is maintained at the flushing contractor's primary yard office (`YARD` pad) and carried in each crew's field binder.
   - **Site Hazardous Chemical Inventory (`1910.1200(e)(1)(i)`):**
     - `CL-100` (Alkaline Pre-Operational Cleaner, 22% active, pH 10.4): **Skin Corr. 1B, Eye Dam. 1 — Signal Word: DANGER**.
     - `CL-210` (Neutral-pH Cleaner, 18% active, pH 8.2): **Skin Corr. 1B, Eye Dam. 1 — Signal Word: DANGER**.
     - `MO-500` (Sodium Molybdate Liquid Inhibitor, 10% Mo): **Eye Irrit. 2A — Signal Word: WARNING**.
     - `PS-330` (Polysilicate Liquid Inhibitor, 12% SiO2): **Eye Irrit. 2A — Signal Word: WARNING**.
     - `TA-90` (Tolyltriazole Solution, 50% TTA): **Eye Irrit. 2A — Signal Word: WARNING**.
     - `PD-45` (Polyacrylate Dispersant, 40% polymer): **Eye Irrit. 2A — Signal Word: WARNING**.
     - *(Note: `NB-700` and `SA-100` are included in `VD-07` for reference but are not ordered or brought on site.)*
   - **Non-Routine Tasks & Unlabeled Pipes (`1910.1200(e)(1)(ii)`):** Prior to charging chemicals into any temporary flush hose, skid eductor, or permanent PCW circuit (`C1`–`C8`), temporary warning tags/signs stating *"DANGER / WARNING — CHEMICAL CLEANING / PASSIVATION IN PROGRESS — CORROSIVE / IRRITANT SOLUTION IN PIPEWORK"* are affixed at both tie-in valves (`TI-C<k>-01/02`), high-point vents (`AV-C<k>-01`), and low-point drains (`DV-C<k>-01`). Strainer basket opening and cleaning after `CHEM_CLEAN` is treated as a non-routine chemical exposure task requiring full transfer PPE after depressurization and draining.
   - **Multi-Employer Workplace Coordination (`1910.1200(e)(2)`):** The General Contractor and all adjacent trades working in `MER-1`, `MER-2`, `L3-N`, `L3-S`, `L3-W`, `ROOF`, and `YARD` are notified 24 hours prior to chemical dosing, provided on-site access to the `VD-07` SDS binder, briefed on the temporary pipe/skid labeling system, and informed of barricaded exclusion zones and emergency response procedures.

2. **Container & Workplace Labeling (`29 CFR 1910.1200(f)`):**
   - All shipped pails (`5 gal`) and bottles (`1 gal`) from Cascadia Water Technologies (`VD-07`, Emergency Tel: `1-800-555-0142`) are inspected upon delivery to verify intact GHS labels bearing the product identifier, signal word (`DANGER` or `WARNING`), hazard statements, corrosion/exclamation pictograms, precautionary statements, and supplier contact details (`1910.1200(f)(1)`).
   - Any secondary transfer container, chemical feed pot, or skid dosing tank not drained immediately within a single crew member's shift is labeled with a workplace GHS label (`1910.1200(f)(6)`–`(7)`). Damaged or illegible labels are replaced immediately (`1910.1200(f)(9)`).

3. **Safety Data Sheet (SDS) Accessibility (`29 CFR 1910.1200(g)`):**
   - Complete 16-section Safety Data Sheets (`VD-07`) for every product used are maintained in weatherproof red SDS binders mounted directly on `FS-1200-A` and `FS-600-A` at each active tie-in pad (`MER-1`, `MER-2`, `L3-N/S/W`, `ROOF`, `YARD`) so that crew members travelling between tie-in locations have immediate, unrestricted access during every work shift (`1910.1200(g)(8)`–`(9)`), satisfying Prefunctional Checklist `CX-03 Item 10`.

4. **Employee Information, Training, PPE, and Emergency Eyewash/Shower Controls (`29 CFR 1910.1200(h)` & `VD-07` Sections 4 & 8):**
   - Prior to initial assignment on Day 1, all members of `CREW-1` and `CREW-2` receive documented HazCom training (`1910.1200(h)(1)`–`(3)`) covering:
     - Visual and pH/conductivity methods for detecting chemical leaks or releases from temporary lay-flat hoses, camlock couplings, and strainer housings;
     - Severe skin burn and eye damage hazards (`Skin Corr. 1B`, `Eye Dam. 1`) of `CL-100` and `CL-210`, and serious eye irritation hazards (`Eye Irrit. 2A`) of `MO-500`, `PS-330`, `TA-90`, and `PD-45`;
     - **Mandatory Personal Protective Equipment (`VD-07 Section 8`):** Chemical splash goggles, full-face shield, chemical-resistant butyl/nitrile gauntlet gloves, and chemical-resistant apron/suit worn during all chemical pail/bottle transfers, dosing, sampling, and strainer basket cleaning;
     - **Emergency Eyewash & Quick-Drench Shower (`VD-07 Section 4`):** A tested, ANSI-compliant portable/plumbed emergency eyewash and quick-drench safety shower is positioned **within 10 seconds unobstructed travel distance** of every active chemical handling and dosing point prior to opening any chemical container. In the event of eye or skin contact, flush immediately with copious water for at least **15 minutes** and contact emergency medical services / Cascadia Water Technologies (`1-800-555-0142`).
