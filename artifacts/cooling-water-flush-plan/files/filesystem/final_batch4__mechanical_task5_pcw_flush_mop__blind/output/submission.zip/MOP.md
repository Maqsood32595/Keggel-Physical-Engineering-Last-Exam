# METHOD OF PROCEDURE — PCW Cleaning, Flushing, Passivation and Turnover
## Tull Creek Data Hall — Process Cooling Water System
### Commissioning Engineer: Flushing Contractor
### Revision: Issued for Construction

---

## 1. EXECUTION NARRATIVE

### 1.1 Scope

This Method of Procedure (MOP) governs pre-operational cleaning, flushing, chemical
cleaning, rinsing, passivation, and turnover of the eight tie-in-bounded Process Cooling
Water (PCW) circuits (C1–C8) at the Tull Creek Data Hall. All work is performed in
accordance with Section 23 25 16 Rev 3, UFC 3-230-13 (2023), and the referenced project
documents.

The PCW loop is mechanically complete and all eight circuits have already been
hydrostatically tested and accepted (CX-02, 127.5 psig, 120 min, PASS). No HYDRO stage is
required; the HYDRO rows in flush_plan.csv are filed with duration 0 and no water as
"test not performed" per Section 23 25 16 cl.3.3 and CX-01.

### 1.2 Circuit Line Assignments (from P&ID drawings M-PID-101 through M-PID-104 Rev C)

| Circuit | Description | Lines (M-601) | Tie-in Location |
|---------|-------------|---------------|-----------------|
| C1 | PCW primary header and pump gallery | 1041, 1042, 1043 (x4), 1044 (x4) | MER-1 |
| C2 | PCW heat exchanger bay A | 2011, 2012, 2013 (x3) | MER-1 |
| C3 | PCW heat exchanger bay B | 2021, 2022, 2023 (x2) | MER-2 |
| C4 | PCW CDU distribution north | 4021, 4022, 4023 (x2), 4024 (x4) | L3-N |
| C5 | PCW CDU distribution south | 4031, 4032, 4033 (x3), 4034 (x4) | L3-S |
| C6 | PCW CDU distribution west | 4041, 4042, 4043 (x3) | L3-W |
| C7 | PCW fan-wall coil branch | 5011, 5012, 5013 (x4) | ROOF |
| C8 | PCW makeup and fill riser | 6011, 6012, 6013 (x2) | YARD |

### 1.3 Rented Skid Fleet (SW-01 Section 3, SI-05)

Three flush skids are on hire:
- **FS-600-A** and **FS-600-B**: delivered at mobilisation (hour 0), 30 kW each, $430.00/calendar day
- **FS-1200-A**: delivered at hour 48 (SI-05), 75 kW, $790.00/calendar day

Skid assignment (each circuit served by one skid; no circuit requires parallel skids):

| Circuit | Skid(s) | Flow (gpm) | Location | Power Limit (kW) |
|---------|---------|------------|----------|------------------|
| C1 | FS-1200-A | 1,181 | MER-1 | 150 |
| C2 | FS-1200-A | 624 | MER-1 | 150 |
| C3 | FS-1200-A | 720 | MER-2 | 95 |
| C4 | FS-600-A | 360 | L3-N | 90 |
| C5 | FS-1200-A | 476 | L3-S | 90 |
| C6 | FS-600-B | 360 | L3-W | 90 |
| C7 | FS-600-A | 295 | ROOF | 45 |
| C8 | FS-600-B | 151 | YARD | 120 |

Each skid develops the required head at its assigned flow with margin (see Section 3).
Power check: maximum connected load at any panel (75 kW FS-1200 at MER-2 with 95 kW limit)
does not exceed the panel kW rating (SW-04/E-701).

### 1.4 Stage Sequence per Circuit

Each circuit progresses through: INITIAL_FLUSH → CHEM_CLEAN → DRAIN_RINSE → PASSIVATE →
HOLD → FINAL_FILL. HYDRO is omitted (already accepted). HOLD is an unattended
film-formation hold (skid released, not charged). Stages are scheduled as discrete
activities in schedule.csv; crew and skid assignments respect the two-crew limit and
single-circuit-per-skid constraint.

### 1.5 Water Conservation and Cascade

Rinse water is conserved via cascade: the final rinse effluent of a donor circuit is
transferred to a receiver circuit as one displacement. Cascade pairs (donor → receiver,
donor V_f ≥ receiver V_f):

- **C1 → C7** (32,983 gal ≥ 4,086 gal): saves 4,086 gal draw
- **C5 → C6** (6,406 gal ≥ 4,227 gal): saves 4,227 gal draw
- **C3 → C8** (6,203 gal ≥ 5,791 gal): saves 5,791 gal draw
- **C4 → C2** (5,957 gal ≥ 5,596 gal): saves 5,596 gal draw

Total cascade savings: 19,700 gal. Cascade precedence is encoded in schedule.csv
predecessor_ids.

### 1.6 Discharge

All effluent is discharged to metered manhole MH-14 under authorization IWD-2026-0417
(SW-03 / RFI-031). Programme total at the metered connection is capped at 540,000 gal.
Total effluent after cascade is 657,101 gal; 540,000 gal is discharged to sewer and
117,101 gal is hauled by vacuum tanker at $168.00/1,000 gal (RFI-031). Tanker standing is
at the yard pad only (C-101).

### 1.7 Turnover Method

All circuits use **DRAIN_AND_REFILL**. RETAIN_AND_TOP_UP is not permitted because, for the
selected polysilicate-azole program, the maintenance residual (10–20 ppm as SiO2, UFC
Table 5-11) is below the passivation residual (40–60 ppm as SiO2), so topping up would
dilute rather than raise the inhibitor level (Section 23 25 16 cl.3.8).

Each circuit is drained to the declared discharge route, refilled to system volume with
treated makeup water carrying the maintenance charge, and recirculated before sampling.

---

## 2. DESIGN BASIS

### 2.1 Hydraulic Basis

All hydraulic quantities computed per DOE-HDBK-1012/3-92 (Section 23 25 16 cl.3.2):
- Design water: density 62.30 lbm/ft³, kinematic viscosity 1.08e-5 ft²/s at 68°F
- Velocity: v = Q_leg / A (parallel legs share flow equally)
- Friction factor: Colebrook-White, f = 64/Re below Re 2,000
- Head loss: Darcy + equivalent length fittings (sum L/D from M-601)
- Required head = static lift (M-ISO-2xx) + main path loss + component pressure drops
  (scaled per M-602) + per-skid hose and strainer loss (VD-05)

### 2.2 Flushing Flow

Flushing velocity ≥ greater of UFC 3-230-13 §5-3.7 (3.28 ft/s for foulant suspension) and
project minimum (4.0 ft/s for plate HX / cold-plate circuits C2–C7; 2.0 ft/s otherwise).
Flows:

| Circuit | Flow (gpm) | Governing Segment | Governing ID (in) |
|---------|------------|-------------------|-------------------|
| C1 | 1,181.4 | 1043 | 6.065 |
| C2 | 623.7 | 2011 | 7.981 |
| C3 | 720.4 | 2023 | 6.065 |
| C4 | 360.2 | 4021 | 6.065 |
| C5 | 476.1 | 4033 | 4.026 |
| C6 | 360.2 | 4041 | 6.065 |
| C7 | 295.4 | 5011 | 6.065 |
| C8 | 151.2 | 6013 | 3.068 |

### 2.3 Chemical Treatment Program

All circuits use **polysilicate-azole** (PS-330 + TA-90 where copper is wetted), selected
per UFC 3-230-13 Table 6-2 for chilled/closed water with copper and aluminium metallurgy.
Per Section 23 25 16 cl.3.5, the UFC paragraph text governs over the selection table.

| Circuit | Cleaner | Program | Copper Wetted? | Azole Required? |
|---------|---------|---------|----------------|-----------------|
| C1 | CL-100 | Polysilicate-azole | No | No |
| C2 | CL-100 | Polysilicate-azole | No | No |
| C3 | CL-100 | Polysilicate-azole | No | No |
| C4 | CL-100 | Polysilicate-azole | Yes | Yes (TA-90) |
| C5 | CL-100 | Polysilicate-azole | Yes | Yes (TA-90) |
| C6 | CL-100 | Polysilicate-azole | Yes (CP-331 aluminium) | Yes (TA-90) |
| C7 | CL-100 | Polysilicate-azole | Yes | Yes (TA-90) |
| C8 | CL-210 | Polysilicate | No | No (galvanized, pH ≤ 8.5) |

C8 uses CL-210 (neutral-pH cleaner for galvanized/aluminium) per VD-06, and polysilicate
without azole (no copper). pH band 7.5–8.5 protects galvanizing from white rust
(UFC 5-7.3.2).

### 2.4 Rinse Displacement Model

Per Section 23 25 16 cl.3.6: C_n = C_mk + (C_0 − C_mk)·exp(−η·n), with C_mk = 500 uS/cm
(SW-02), C_0 from VD-06 Note 3 (CL-100: 2,600 uS/cm; CL-210: 2,150 uS/cm).

| Circuit | Cleaner | C_0 (uS/cm) | η | n_r (displacements) | C_n after n_r (uS/cm) |
|---------|---------|-------------|---|---------------------|------------------------|
| C1–C3 | CL-100 | 2,600 | 0.62 | 7 | 527.4 |
| C4–C7 | CL-100 | 2,600 | 0.45 | 9 | 536.6 |
| C8 | CL-210 | 2,150 | 0.62 | 6 | 540.0 |

Rinse acceptance: conductivity ≤ 550 uS/cm (110% of makeup), pH within ±0.3 of makeup
(7.2–7.8) and within 7.5–8.5 window (UFC 5-7.3.2.2). Both readings acceptable per
Section 23 25 16 cl.3.6.

### 2.5 Chemical Dosing

- **CL-100**: 1.5 gal per 1,000 gal system volume (VD-06), dosed volumetrically, not to
  target residual (VD-06 Note 4a)
- **CL-210**: 2.0 gal per 1,000 gal system volume (VD-06) for C8
- **PD-45 dispersant**: 5 ppm active polymer (UFC 5-3.7), dosed on system volume
- **PS-330 passivation**: 50 ppm as SiO2 (mid of 40–60 ppm band, UFC Table 5-11)
- **TA-90 azole**: 10 ppm as TTA (minimum for copper, UFC Table 5-11 / 6-2.2.5)
- All treatment chemicals dosed on system volume; cleaning products dosed volumetrically

Packages rounded up per dosing row per VD-06 Note 1 (no pooling across stages/circuits).

### 2.6 Film-Formation Hold

Polysilicate film-formation hold: 10 days (240 occupied hours), per UFC Table 5-11
(10–12 days range; conservative lower bound selected). Hold is unattended; skid released
and not charged (Section 23 25 16 cl.3.10a).

---

## 3. GOVERNING CONSTRAINT AND MARGIN PER CIRCUIT

The governing constraint is the one with the least fractional room (limit − achieved)/limit
(upper limit) or (achieved − limit)/limit (lower limit). Five candidate constraints are
evaluated per circuit.

| Circuit | Head Margin | Rinse Margin | Power Margin | Water Allocation Margin | Discharge Margin | **Governing** | **Governing Margin** |
|---------|-------------|--------------|--------------|------------------------|------------------|---------------|----------------------|
| C1 | 0.2109 | 0.0411 | 0.5000 | 0.0414 | 0.0000 | **Discharge** | 0.0000 |
| C2 | 0.6439 | 0.0411 | 0.5000 | 0.0414 | 0.0000 | **Discharge** | 0.0000 |
| C3 | 0.6590 | 0.0411 | 0.2105 | 0.0414 | 0.0000 | **Discharge** | 0.0000 |
| C4 | 0.0408 | 0.0244 | 0.6667 | 0.0414 | 0.0000 | **Discharge** | 0.0000 |
| C5 | 0.3546 | 0.0244 | 0.1667 | 0.0414 | 0.0000 | **Discharge** | 0.0000 |
| C6 | 0.1216 | 0.0244 | 0.6667 | 0.0414 | 0.0000 | **Discharge** | 0.0000 |
| C7 | 0.0657 | 0.0244 | 0.3333 | 0.0414 | 0.0000 | **Discharge** | 0.0000 |
| C8 | 0.5936 | 0.0182 | 0.7500 | 0.0414 | 0.0000 | **Discharge** | 0.0000 |

**GOVERNING CONSTRAINT C1: Discharge (margin 0.0000)**
**GOVERNING CONSTRAINT C2: Discharge (margin 0.0000)**
**GOVERNING CONSTRAINT C3: Discharge (margin 0.0000)**
**GOVERNING CONSTRAINT C4: Discharge (margin 0.0000)**
**GOVERNING CONSTRAINT C5: Discharge (margin 0.0000)**
**GOVERNING CONSTRAINT C6: Discharge (margin 0.0000)**
**GOVERNING CONSTRAINT C7: Discharge (margin 0.0000)**
**GOVERNING CONSTRAINT C8: Discharge (margin 0.0000)**

### 3.1 Discharge Constraint (Programme-Level)

The authorised programme discharge at metered connection MH-14 is capped at 540,000 gal
(RFI-031). Total effluent after cascade is 657,101 gal; 540,000 gal discharges to sewer
(at cap, margin 0.0000) and 117,101 gal is hauled off-site. The discharge constraint is
programme-level and binds equally for all circuits. Margin = (540,000 − 540,000)/540,000 =
0.0000.

### 3.2 Per-Circuit Constraint Detail

**C1** — Head margin 0.2109 (req 94.4 ft, avail 119.6 ft, FS-1200-A at MER-1); Rinse margin
0.0411 (C_n 527.4 vs 550 uS/cm limit); Power margin 0.5000 (75 kW vs 150 kW at MER-1).

**C2** — Head margin 0.6439 (req 66.1 ft, avail 185.7 ft); Rinse margin 0.0411; Power
margin 0.5000 (75 kW vs 150 kW at MER-1).

**C3** — Head margin 0.6590 (req 60.1 ft, avail 176.4 ft); Rinse margin 0.0411; Power
margin 0.2105 (75 kW vs 95 kW at MER-2).

**C4** — Head margin 0.0408 (req 147.9 ft, avail 154.2 ft, FS-600-A at L3-N — tightest
per-circuit head margin); Rinse margin 0.0244; Power margin 0.6667 (30 kW vs 90 kW).

**C5** — Head margin 0.3546 (req 125.6 ft, avail 194.6 ft); Rinse margin 0.0244; Power
margin 0.1667 (75 kW vs 90 kW at L3-S — tightest per-circuit power margin).

**C6** — Head margin 0.1216 (req 135.4 ft, avail 154.2 ft); Rinse margin 0.0244; Power
margin 0.6667 (30 kW vs 90 kW at L3-W).

**C7** — Head margin 0.0657 (req 152.7 ft, avail 163.4 ft, FS-600-A at ROOF — tight
head margin due to 72 ft static lift); Rinse margin 0.0244; Power margin 0.3333 (30 kW
vs 45 kW at ROOF — tight power margin).

**C8** — Head margin 0.5936 (req 71.5 ft, avail 175.9 ft); Rinse margin 0.0182 (C_n 540.0
vs 550 uS/cm limit — tightest per-circuit rinse margin); Power margin 0.7500 (30 kW
vs 120 kW at YARD).

---

## 4. CONFLICT RESOLUTION

### 4.1 UFC 3-230-13 vs Section 23 25 16 — Treatment Program Selection

**Conflict**: UFC Table 6-2 organises closed-system treatment by system type, not
metallurgy. The selection table lists polysilicate-azole for chilled water, but does not
explicitly list all metallurgies.

**Resolution**: Per Section 23 25 16 cl.3.5, the paragraph text of the individual
programmes governs over the selection table. Polysilicate-azole is selected for all
circuits because: (a) Table 6-2 permits it for chilled/closed water; (b) Table 5-11
tabulates polysilicate passivation dosages and pH bands; (c) pH 7.5–8.5 is safe for
galvanized steel (C8) and aluminium (C6 CP-331); (d) TA-90 azole added where copper is
wetted (C4, C5, C6, C7).

### 4.2 UFC Rinse pH Criterion — Tolerance vs Window

**Conflict**: UFC 5-7.3.2.2 states rinse pH as "±0.3 pH units from 7.5 to 8.5" —
ambiguous whether this means pH 7.2–7.8 (tolerance about makeup pH 7.5) or the absolute
window 7.5–8.5.

**Resolution**: Per Section 23 25 16 cl.3.6, BOTH readings are acceptable. The control
band is set to the intersection: pH 7.5–7.8, which satisfies both the tolerance about
makeup pH (7.5 ± 0.3 = 7.2–7.8) and the absolute window (7.5–8.5).

### 4.3 RETAIN_AND_TOP_UP Eligibility

**Conflict**: Section 23 25 16 cl.3.8 permits RETAIN_AND_TOP_UP only where maintenance
residual ≥ passivation residual.

**Resolution**: For polysilicate-azole, maintenance (10–20 ppm SiO2) < passivation
(40–60 ppm SiO2, UFC Table 5-11). RETAIN_AND_TOP_UP is NOT permitted for any circuit.
All circuits use DRAIN_AND_REFILL. This increases effluent volume but is mandatory.

### 4.4 NB-700 Suitability

**Conflict**: VD-06 Note 4 offers NB-700 "for comparison only; confirm suitability against
the makeup water analysis before ordering." UFC 6-2.2.2 avoids nitrite programs if
(Cl + SO4) > 800 ppm.

**Resolution**: SW-02 (makeup water analysis) is a scanned image with no text layer;
chloride/sulfate values could not be extracted. NB-700 is NOT ordered to avoid risk of
nitrite discharge restriction (VD-06 Note 5: molybdate-bearing effluent may be subject
to local discharge restriction). Polysilicate-azole is used instead.

---

## 5. DEFECTS FOUND IN PROJECT DOCUMENTS

1. **SW-02 Municipal Water Analysis Lab Report**: Scanned image, no text layer.
   Conductivity, pH, hardness, chloride, and sulfate values could not be extracted.
   Engineering assumptions documented: C_mk = 500 uS/cm, pH = 7.5. These values drive
   the rinse displacement model and pH control band.

2. **SW-03 Sanitary Sewer Discharge Authorization (Rev A and Rev B)**: Both are scanned
   images with no text layer. Local limits (pH, temperature, metals, zinc, copper) could
   not be extracted. Engineering assumptions documented: sewer rate $4.00/1,000 gal;
   pH lower limit 6.0; temperature upper limit 120°F. These values drive the DISCHARGE
   gate thresholds.

3. **UFC 3-240-13FN (2005)**: Cancelled standard found in standards/ folder. Must not be
   used per Section 23 25 16 cl.1.2. Current edition UFC 3-230-13 (2023) is cited
   instead.

4. **M-PID-103 Rev A**: Superseded drawing found in drawings/ folder. Rev C is used per
   M-601 Note 5.

5. **RFI-031 Discharge Cap**: The 540,000 gal sewer cap is exceeded by total effluent
   (657,101 gal after cascade). 117,101 gal must be hauled off-site at $168.00/1,000 gal.
   This was not avoidable within the process constraints (minimum rinse displacements,
   mandatory DRAIN_AND_REFILL).

---

## 6. SAFETY — HAZARD COMMUNICATION (29 CFR 1910.1200)

All products brought on site comply with 29 CFR 1910.1200 (Hazard Communication
Standard) as adopted by Section 23 25 16 cl.1.2. The following obligations are discharged:

### 6.1 Safety Data Sheets (SDS)

SDS for all seven products (CL-100, CL-210, MO-500, PS-330, NB-700, TA-90, PD-45, SA-100)
are provided in VD-07 SDS pack. SDS are maintained on site at the flush skid pads and the
yard pad for the duration of the work. Each SDS includes:
- Section 1: Identification (supplier Cascadia Water Technologies, emergency 1-800-555-0142)
- Section 2: Hazard identification (signal word, GHS classification)
- Section 3: Composition (active species and concentration)
- Section 4: First aid measures
- Section 8: Exposure controls / personal protection
- Section 14: Transport information

### 6.2 Hazard Classification and Labeling

| Product | Signal Word | GHS Classification | Active Species | Concentration |
|---------|-------------|-------------------|----------------|---------------|
| CL-100 | DANGER | Skin Corr. 1B, Eye Dam. 1 | Proprietary blend | 22% |
| CL-210 | DANGER | Skin Corr. 1B, Eye Dam. 1 | Proprietary blend | 18% |
| PS-330 | WARNING | Eye Irrit. 2A | SiO2 | 12% |
| TA-90 | WARNING | Eye Irrit. 2A | TTA | 50% |
| PD-45 | WARNING | Eye Irrit. 2A | Polymer | 40% |

All containers are labeled with product identifier, signal word, hazard statements,
precautionary statements, and supplier information per 29 CFR 1910.1200(f).

### 6.3 Personal Protective Equipment (PPE)

Per SDS Section 8 for all products:
- Chemical splash goggles and face shield
- Chemical-resistant gloves (nitrile or butyl)
- Chemical-resistant apron
- Eyewash and quick-drench shower within 10 seconds of the handling point

### 6.4 First Aid

For all products: flush eyes with water for 15 minutes; seek medical attention for skin
contact or ingestion. Emergency eyewash and quick-drench shower available at each skid
pad.

### 6.5 Chemical Handling Procedures

- All transfers performed with PPE as above
- Spill response: absorb with inert material, containerize for disposal
- No mixing of chemicals except as specified in the treatment program
- Acid and alkaline chemicals stored separately
- SDS reviewed by all personnel before handling

### 6.6 Training

All commissioning crew members receive hazard communication training covering the SDS for
each product, PPE requirements, first aid, and spill response before mobilisation
(TM-0).

---

## 7. SCHEDULE AND MILESTONES

All work completes within the contractual turnover date TM-4 (day 47, hour 1,128 from
mobilisation). The last activity (FINAL_FILL for C8) finishes at approximately hour 621
(day 26), well ahead of TM-4. Milestones TM-1 through TM-4 (CX-01) are satisfied.

### 7.1 Resource Limits Observed

- **Two crews maximum**: CREW-A and CREW-B; no more than two activities attended
  simultaneously
- **Skid availability**: FS-1200-A not used before hour 48 (SI-05); FS-600-A/B available
  from hour 0
- **Water allocation**: Daily draw never exceeds 92,000 gal (SW-01 cl.2); SI-04
  restrictions observed (days 2–3: 31,000 gal metered; day 6: no metered water)
- **Power**: Simultaneous connected load at each panel does not exceed kW limit
  (SW-04/E-701)

---

## 8. COST BASIS

Programme priced per Section 23 25 16 cl.3.10:
- Skid rental: one day rate per calendar day held, apportioned by hours
- Crew: one shift rate ($820) per 12-hour shift attended, apportioned by hours
- Water: metered rate up to daily allocation, trucked rate above; programme-wide average
  rate applied
- Effluent: sewer rate to MH-14, tanker rate for hauled volume
- Chemicals: whole packages at VD-06 quoted prices, rounded up per dosing row

Total programme cost: **$74,768.42** (see resources.json for full breakdown).

---