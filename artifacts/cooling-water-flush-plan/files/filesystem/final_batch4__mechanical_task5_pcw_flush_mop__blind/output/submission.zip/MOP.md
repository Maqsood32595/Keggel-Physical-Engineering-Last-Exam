# Method of Procedure (MOP) and Engineering Design Basis
**Project:** Tull Creek Data Hall — Process Cooling Water (PCW) Cleaning, Flushing, Passivation, and Turnover
**Specification Section:** Section 23 25 16 (Rev 3, Issued for Construction, 2026-07-14)

---

## 1. Design Basis & Governing Constraints per Circuit

Per **Section 23 25 16 cl. 1.6**, the governing constraint for each circuit (`C1` through `C8`) is evaluated across all five candidate constraint families:
1. **Flushing duty against available skid head**: `(skid_head_avail_ft - required_head_ft) / skid_head_avail_ft`
2. **Rinse endpoint**: expressed in conductivity `(676.5 - C_n) / 676.5` (where `C_lim = 1.10 * 615 = 676.5 microS/cm` per `UFC 3-230-13` cl. 5-7.3.2.2e and `SW-02`) and in displacements `(n_r - n_exact) / n_exact`
3. **Authorised programme sewer discharge volume**: `(540,000 - 506,467.8135) / 540,000 = 0.062096` (`SW-03 Rev B` Section 2)
4. **Site daily water allocation**: `(92,000 - max_daily_draw_gal) / 92,000` (`SW-01` cl. 1–2)
5. **Temporary power available at tie-in**: `(available_kw - connected_kw) / available_kw` (`SW-04 Rev B`, `E-701 Rev B`)

### 1.1 Required Governing Constraint Declarations (Section 23 25 16 cl. 1.6)

GOVERNING CONSTRAINT C1: rinse endpoint (margin 0.019801)
GOVERNING CONSTRAINT C2: rinse endpoint (margin 0.019801)
GOVERNING CONSTRAINT C3: rinse endpoint (margin 0.019801)
GOVERNING CONSTRAINT C4: rinse endpoint (margin 0.010735)
GOVERNING CONSTRAINT C5: rinse endpoint (margin 0.010735)
GOVERNING CONSTRAINT C6: rinse endpoint (margin 0.028911)
GOVERNING CONSTRAINT C7: rinse endpoint (margin 0.010735)
GOVERNING CONSTRAINT C8: rinse endpoint (margin 0.035921)

### 1.2 Full Candidate Margin Comparison Table (All Five Families)

| Circuit | 1. Skid Head Margin | 2. Rinse Endpoint Margin (Conductivity / Displacements) | 3. Programme Sewer Cap Margin | 4. Daily Water Limit Margin (vs 92,000 gal/d) | 5. Tie-In Power Margin | Binding Constraint Family (Tightest Permitted Form) |
|---|---:|---:|---:|---:|---:|---|
| **C1** | 0.229085 | **0.019801** (cond) / 0.070708 (disp) | 0.062096 | 0.179236 | 0.500000 | `rinse endpoint` (0.019801) |
| **C2** | 0.721402 | **0.019801** (cond) / 0.070708 (disp) | 0.062096 | 0.196176 | 0.500000 | `rinse endpoint` (0.019801) |
| **C3** | 0.657178 | **0.019801** (cond) / 0.070708 (disp) | 0.062096 | 0.179236 | 0.210526 | `rinse endpoint` (0.019801) |
| **C4** | 0.255403 | **0.010735** (cond) / 0.036169 (disp) | 0.062096 | 0.363961 | 0.666667 | `rinse endpoint` (0.010735) |
| **C5** | 0.033626 | **0.010735** (cond) / 0.036169 (disp) | 0.062096 | 0.410497 | 0.666667 | `rinse endpoint` (0.010735) |
| **C6** | 0.230168 | **0.028911** (cond) / 0.118969 (disp) | 0.062096 | 0.410497 | 0.666667 | `rinse endpoint` (0.028911) |
| **C7** | 0.293837 | **0.010735** (cond) / 0.036169 (disp) | 0.062096 | 0.592629 | 0.333333 | `rinse endpoint` (0.010735) |
| **C8** | 0.386577 | **0.035921** (cond) / 0.156268 (disp) | 0.062096 | 0.363961 | 0.750000 | `rinse endpoint` (0.035921) |

*Note on Rinse Endpoint Quantities (Section 23 25 16 cl. 1.6 & cl. 3.6):* Under `Section 23 25 16` cl. 1.6, where a constraint can be expressed in more than one quantity (such as rinse endpoint in conductivity `microS/cm` with upper limit `676.5 microS/cm` or in displacements `n` against `n_exact`), the margin may be stated in any permitted quantity, and the binding constraint is determined using whichever permitted form is tighter. As shown in the table above, the rinse endpoint expressed in conductivity (`0.010735` on `C4, C5, C7`; `0.019801` on `C1, C2, C3`; `0.028911` on `C6`; `0.035921` on `C8`) is the tightest margin on all eight circuits. Even if evaluated in displacements (`0.036169` on `C4, C5, C7`), only `C5` has a slightly tighter skid head margin (`0.033638` at `477.0 gpm` on `FS-600-A`), which is documented above for complete transparency.

---

## 2. Circuit Topology, Volumes, Hydraulics, and Skid Selection

Circuit boundaries were traced directly from the Rev C P&IDs (`M-PID-101`, `M-PID-102`, `M-PID-103 Rev C`, `M-PID-104`), Isometric elevations (`M-ISO-201` through `M-ISO-204`), Pipe Schedule (`M-601 Rev C`), Equipment Schedule (`M-602 Rev C`), and Valve/Tie-In Schedule (`M-603 Rev C`).

| Circuit | Tie-In & Location | P&ID / Iso | Pipe Lines (Legs) | Equipment (Flush Status) | Pipe Vol (gal) | Flush Vol $V_f$ (gal) | System Vol $V_s$ (gal) | Min Vel Class (ft/s) | Gov Seg (ID in.) | Min $Q$ (gpm) | Declared $Q$ (gpm) | Assigned Skid | Vel (ft/s) | $h_{\text{req}}$ (ft) | $h_{\text{avail}}$ (ft) |
|---|---|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|
| **C1** | TI-C1-01/02 (`MER-1`) | M-PID-101 / M-ISO-201 | 1041(1), 1042(1), 1043(4), 1044(4) | PMP-101 (in), BT-101 (in) | 25,583.40 | 32,983.40 | 32,983.40 | 3.28 | 1043 (6.065) | 1,181.42 | 1,200.0 | `FS-1200-A` | 3.3316 | 90.3519 | 117.0000 |
| **C2** | TI-C2-01/02 (`MER-1`) | M-PID-102 / M-ISO-201 | 2011(1), 2012(1), 2013(3) | HX-201A (bypassed) | 5,596.03 | 5,596.03 | 7,946.03 | 4.00 | 2011 (7.981) | 623.71 | 650.0 | `FS-1200-A` | 4.1686 | 52.2757 | 183.1667 |
| **C3** | TI-C3-01/02 (`MER-2`) | M-PID-102 / M-ISO-202 | 2021(1), 2022(1), 2023(2) | HX-201B (bypassed) | 6,203.19 | 6,203.19 | 8,553.19 | 4.00 | 2023 (6.065) | 720.38 | 750.0 | `FS-1200-A` | 4.1645 | 61.3474 | 173.5000 |
| **C4** | TI-C4-01/02 (`L3-N`) | M-PID-103 / M-ISO-203 | 4021(1), 4022(1), 4023(2), 4024(4) | CDU-301 (byp), CP-311 (byp) | 5,956.64 | 5,956.64 | 8,536.64 | 4.00 | 4021 (6.065) | 360.19 | 400.0 | `FS-600-A` | 4.4421 | 109.1066 | 148.3333 |
| **C5** | TI-C5-01/02 (`L3-S`) | M-PID-103 / M-ISO-203 | 4031(1), 4032(1), 4033(3), 4034(4) | CDU-302 (byp), CP-321 (byp) | 6,405.83 | 6,405.83 | 8,985.83 | 4.00 | 4033 (4.026) | 476.15 | 477.0 | `FS-600-A` | 4.0072 | 130.1689 | 134.7000 |
| **C6** | TI-C6-01/02 (`L3-W`) | M-PID-103 / M-ISO-203 | 4041(1), 4042(1), 4043(3) | CP-331 (bypassed) | 4,227.15 | 4,227.15 | 5,677.15 | 4.00 | 4041 (6.065) | 360.19 | 400.0 | `FS-600-A` | 4.4421 | 112.8858 | 148.3333 |
| **C7** | TI-C7-01/02 (`ROOF`) | M-PID-101 / M-ISO-204 | 5011(1), 5012(1), 5013(4) | CL-401 (bypassed) | 4,085.96 | 4,085.96 | 6,035.96 | 3.28 | 5011 (6.065) | 295.36 | 320.0 | `FS-600-A` | 3.5537 | 113.6199 | 160.0667 |
| **C8** | TI-C8-01/02 (`YARD`) | M-PID-104 / M-ISO-202 | 6011(1), 6012(1), 6013(2) | ST-601 (in path) | 2,040.75 | 5,790.75 | 5,790.75 | 3.28 | 6013 (3.068) | 151.16 | 200.0 | `FS-600-A` | 4.3396 | 102.7524 | 171.6667 |

---

## 3. Document Conflicts Resolved, Defects Logged, and Rejected Documents

### 3.1 Documents Reviewed and Rejected (Excluded from `constraint_register.csv`)
In strict compliance with the specification, the following seven superseded, cancelled, or non-adopted/out-of-scope documents were identified during reconnaissance and excluded from `constraint_register.csv`:
1. **`standards/UFC_3-240-13FN_Industrial_Water_Treatment_2005_CANCELLED.pdf`**: Cancelled 2005 edition of the Unified Facilities Criteria. `Section 23 25 16` cl. 1.2 explicitly mandates the current 2023 edition (`UFC 3-230-13`) and prohibits use of the cancelled 2005 edition.
2. **`standards/40_CFR_122_NPDES_Permit_Programs_2024.pdf`**: Non-adopted standard governing direct point-source NPDES discharges to surface waters. `Section 23 25 16` cl. 1.2 adopts `40 CFR 403` (General Pretreatment Regulations for POTW discharges), and `RFI-031` confirms all sewerable effluent is routed to the POTW via metered sanitary manhole `MH-14` while prohibiting any discharge to the storm system or Tull Creek.
3. **`drawings/M-PID-103_Pcw_Cdu_Distribution_RevA_SUPERSEDED.dxf`**: Superseded by `M-PID-103 Rev C` per the drawing title block and `Schedule M-601` Note 5. In Rev A, line `4"-PCW-4033-CS` was erroneously drawn in Circuit `C4` with 2 parallel legs (`x2`); in governing `Rev C` (and `M-601 Rev C`), line `4033` is in Circuit `C5` with 3 parallel legs (`x3`), where it is the governing velocity segment (`Q_min = 476.15 gpm`).
4. **`site/SW-03_Sanitary_Sewer_Discharge_Authorization.pdf`**: Original issue (dated 2026-06-15) of Discharge Authorization `IWD-2026-0417`, which capped programme sewer discharge at `380,000 gallons`. Superseded by **`SW-03 Rev B`** (dated 2026-07-10), which increased the authorised programme discharge cap at `MH-14` to `540,000 gallons` and confirmed acceptance of molybdate- and polysilicate-treated water meeting Section 1 metal limits.
5. **`specs/22_11_23_Domestic_Water_Pumps_excerpt.docx`**: Out-of-scope specification for domestic water booster pumps (`120 gpm at 65 psi`) and plumbing code disinfection. Clauses 2.1 and 3.1 explicitly state that domestic water piping and equipment are not part of the PCW loop and are not flushed under `Section 23 25 16`.
6. **`vendor_data/VD-08_Air_Cooled_Chiller_Submittal.pdf`**: Out-of-scope submittal for comfort cooling chiller `ACCH-500`. Note 1 explicitly states the chiller serves the comfort cooling system and is not part of the PCW loop or `Section 23 25 16`.
7. **`correspondence/RFI-009_Response_Roof_Curb_Flashing.docx`**: Out-of-scope architectural RFI response regarding roof curb counterflashing height (`14 in.`); explicitly states it concerns the roofing scope only and has no mechanical content.

### 3.2 Resolution of Document Conflicts and Logged Document Defects
1. **Defect in Commissioning Record `CX-02` vs. Physical Evidence Rule (`01 91 13` cl. 1.3 & `23 21 16` cl. 3.3)**:
   - `CX-02_Hydrostatic_Test_Record_partial.csv` lists all eight circuits (`C1`–`C8`) as having passed a `127.5 psig`, `120-minute` hydrostatic test in June 2026, citing pressure recorder chart numbers `TR-0412` through `TR-0419`.
   - However, inspection of `commissioning/` revealed that only **four** pressure recorder charts are on file: `TR-0412` (`C1`), `TR-0413` (`C2`), `TR-0415` (`C4`), and `TR-0419` (`C8`). Each of those four scanned charts was deskewed and verified (`127.5 psig`, `120 min`, no drop, no leakage, witnessed by R. Aldana, CxA).
   - Charts `TR-0414` (`C3`), `TR-0416` (`C5`), `TR-0417` (`C6`), and `TR-0418` (`C7`) are **missing from the files**.
   - **Resolution**: Under `Section 01 91 13` cl. 1.3 (*"a result whose cited evidence is not on file is not an accepted result"*) and `Section 23 21 16` cl. 3.3 (*"Circuits recorded as tested and accepted in CX-02 shall not be retested... Any circuit not so recorded shall be tested before chemical cleaning begins"*), circuits **`C1`, `C2`, `C4`, and `C8`** are accepted and are **not retested**, while circuits **`C3`, `C5`, `C6`, and `C7`** are scheduled for a `2.0-hour` (`120-minute`) hydrostatic test at `127.5 psig` on Project Day 4 (`hours 96.0 to 104.0`), prior to `TM-1` (Day 6, `hour 144.0`) and prior to chemical cleaning.
2. **Conflict Between `UFC 3-230-13` Selection Table (`Table 6-2`) and Controlling Programme Paragraph Text (`cl. 6-2.2.2` to `6-2.2.5`)**:
   - `Table 6-2` lists `Nitrite-azole`, `Molybdate-azole`, and `Nitrite-molybdate-azole` under *"Chilled, brine, glycol"* and lists `Polysilicate-azole` only under *"Diesel engine jacket"*.
   - **Resolution**: Per `Section 23 25 16` cl. 3.5, the controlling paragraph text of the individual programmes governs over `Table 6-2`:
     - **Rejection of `NB-700` (`Nitrite-Azole` and `Molybdate-Nitrite-Azole`) and `SA-100` (`Soda Ash`)**: Lab report `SW-02` shows municipal makeup water has `Chloride = 505 mg/L` and `Sulfate = 355 mg/L`, so `Cl + SO4 = 860 mg/L`. Under `UFC 3-230-13` cl. 6-2.2.2, `Nitrite-Azole` is prohibited when `Cl + SO4 > 800 ppm`; under cl. 6-2.2.4, `Molybdate-Nitrite-Azole` is prohibited when `Cl + SO4 > [(NO2 + Mo) - 100] = 375 ppm`. Thus `NB-700` (`VD-06` Note 4) and its companion pH buffer `SA-100` (`cl. 6-2.2.2`) are disqualified and rejected.
     - **Selection of `Polysilicate-Azole` (`PS-330` + `TA-90`) on `C6` and `Polysilicate` (`PS-330`) on `C8`**: Circuit `C6` contains `CP-331` (6061-T6 aluminium cold plates and copper manifolds; `VD-04` limits service pH to `7.0–8.5` and mandates an aluminium-compatible program). `UFC 3-230-13` cl. 6-2.2.5 states `Polysilicate-Azole` (`80–100 ppm as SiO2`, pH `7.5–8.9`, intersected with `VD-04` to `7.5–8.5`, plus `>= 10 ppm TTA`) is specifically recommended for closed process cooling water loops containing aluminium. Circuit `C8` (`ST-601` and lines `6011–6013`, hot-dip galvanized steel per `M-601`, `M-602`, and `RFI-022`) cannot use `Molybdate` (`pH 8.5–9.5`) because `UFC 3-230-13` cl. 5-7.3.1 & 5-7.3.2 forbid `pH > 8.5` on galvanized steel to prevent white rust and prescribe polysilicate passivation at `pH 7.5–8.5` (`Table 5-10` Note 3 is satisfied since makeup silica in `SW-02` is `11 mg/L < 150 ppm`).
     - **Selection of `Molybdate` (`MO-500`) on `C1, C2, C3` and `Molybdate-Azole` (`MO-500` + `TA-90`) on `C4, C5, C7`**: These six circuits contain carbon steel, stainless steel, and (on `C4, C5, C7`) wetted copper, with no wetted aluminium (`VD-04` Note 4 and `M-602` confirm `CL-401` on `C7` has aluminium fins on the dry air side only) and no galvanized steel. They use `Molybdate` / `Molybdate-Azole` per `UFC 3-230-13` Table 6-2 and cl. 6-2.2.3 (`100–125 ppm as Mo`, pH `8.5–9.5`, plus `>= 10 ppm TTA` on `C4, C5, C7`). `SW-03 Rev B` Section 2 confirms that both molybdate- and polysilicate-treated water are accepted at `MH-14`.
3. **Conflict Between `UFC 3-230-13` Passivation Tables (`Table 5-14` & `Table 5-15` vs. `Table 5-11`) & Unit Typo Defect in `Table 5-14`**:
   - `Table 5-11` (general open cooling water corrosion control) lists `10–12 days` film formation for Polysilicate/Molybdate and `5–6 days` for Tolyltriazole, whereas `cl. 5-7.3.2.4` (*"Passivation of the System"*) explicitly identifies **`Table 5-14` and `Table 5-15`** as the tables governing passivation (`14–21 days` film formation; `40–60 ppm as Mo` and `40–50 ppm as SiO2` at `pH 7.5–8.5` in `Table 5-15`; `10–20 ppm as TTA` at `pH 6.5–7.9` in `Table 5-14`).
   - **Resolution**: Per `Section 23 25 16` cl. 3.5 & cl. 3.8, `Table 5-14` and `Table 5-15` govern passivation dosages (`40.0 ppm Mo` or `40.0 ppm SiO2`, plus `10.0 ppm TTA` on copper-wetted circuits `C4–C7`), film-formation hold duration (`14 days = 336.0 occupied hours`), and passivation pH bands (`7.5–8.5` on `C1, C2, C3, C8`, and the intersection `[7.5, 8.5] ∩ [6.5, 7.9] = [7.5, 7.9]` on `C4, C5, C6, C7`).
   - **Logged Document Defect in `UFC 3-230-13` Table 5-14**: In `Table 5-14` (p. 147), the `Dosage` column for Orthophosphate and Tolyltriazole is misprinted with units of `"20-30 days as PO4"` and `"10-20 days as TTA"` instead of `"ppm"`. Cross-referencing `cl. 5-7.3.2.1b` (*"tolyltriazole (active) at 10 to 20 ppm"*) and `Table 5-11` (*"10-20 as TTA"* under *"Dosage (ppm)"*) confirms the intended unit is `ppm`.
4. **Vendor Datasheet Rated $\Delta P$ (`VD-03`, `VD-04`) vs. `Schedule M-602` Notes 5 and 6**:
   - `VD-03` quotes `46 ft w.c. at 610 gpm` for `HX-201A/B` and `VD-04` quotes `58 ft w.c. at 300 gpm` for `CP-331`. Per `M-602` Note 6 and `VD-03` Note 5, those are the pressure drops developed at rated flow, whereas the *"Max Allowable Pressure Drop"* column in `M-602` governs the operating limit. Per `M-602` Note 5, the `0 ft w.c.` rated pressure drop on `PMP-101` and `BT-101` (`C1`) indicates full-bore vessels/casings with zero hydraulic loss at any flow, while `ST-601` (`C8`, `6 ft w.c. at 120 gpm`, max allowable `25 ft w.c.`) develops `6 * (200/120)^2 = 16.67 ft w.c. <= 25.0 ft w.c.` at the declared `200 gpm` flow.
5. **Makeup Water Hardness (`SW-02` `288 mg/L as CaCO3`) vs. Closed-System Limit (`UFC 3-230-13` Table 6-1 & cl. 6-2.1 `< 250 ppm`) and Softener `SF-1` (`C-101`)**:
   - Unsoftened municipal water (`SW-02`) has total hardness `288 mg/L as CaCO3`, which exceeds the `250 ppm as CaCO3` limit in `UFC 3-230-13` Table 6-1 and cl. 6-2.2.3/6-2.2.5 step 1 (*"Soften makeup water if hardness is over 250 ppm as CaCO3"*).
   - **Resolution**: Site Logistics drawing `C-101 Rev B` provides softened water outlet `SV-2` fed by base-building softener `SF-1` downstream of the construction meter (metered at the construction water rate, hardness `< 20 mg/L as CaCO3`, capacity `88,000 grains as CaCO3` per day between overnight regenerations). At `288 mg/L = 16.82 grains/gal`, `SF-1` softens up to `88,000 / 16.82 = 5,231 gal/day`. During `DRAIN_RINSE`, the final displacement left standing in each circuit for `PASSIVATE` and the `FINAL_FILL` top-up volume (`13,449.95 gal` total across `C2–C7`) are routed through `SV-2` (or blended at the circuit with unsoftened makeup so the standing loop hardness is well below `250 mg/L as CaCO3`).

---

## 4. Execution Narrative & Contractor-Furnished Lump-Sum Mobilisation Scope

### 4.1 Contractor-Furnished Lump-Sum Scope Items (Section 23 25 16 cl. 3.10f)
In accordance with **Section 23 25 16 cl. 3.10f**, the following three scope items are provided by the Flushing Contractor within the lump-sum mobilisation and carry no separate price line in the cost comparison:
1. **Dedicated Hydrostatic Test Pump Rig**: Because the rented centrifugal flush skids (`FS-600` and `FS-1200`) have shutoff heads of `182 ft w.c.` (`78.7 psig`) and `212 ft w.c.` (`91.7 psig`) and cannot reach the required `127.5 psig` hydrostatic test pressure (`Section 23 21 16` cl. 3.3), the Contractor furnishes a positive-displacement hydrostatic test pump rig with calibrated pressure recorder chart gauges to execute the `2.0-hour` (`120-minute`) hydrostatic tests on `C3`, `C5`, `C6`, and `C7` on Day 4 (`hours 96.0 to 104.0`).
2. **Portable Holding Tanks and Transfer Hose for Inter-Circuit Rinse Cascades**: To execute the six rinse cascades (`C1 -> C5 -> C3 -> C2 -> C6 -> C7` and `C4 -> C8`, saving `32,308.91 gallons` of makeup water and sewer effluent) across different tie-in locations (`MER-1`, `MER-2`, `L3-N`, `L3-S`, `L3-W`, `ROOF`, `YARD`), the Contractor provides portable polyethylene holding tanks to capture the donor circuit's final rinse effluent displacement and feed it into the receiving circuit's initial rinse displacement.
3. **50-Micron Fine Trim Filtration for Cold-Plate Circuits (`C4`, `C5`, `C6`)**: Because cold-plate manifold banks `CP-311` (`C4`), `CP-321` (`C5`), and `CP-331` (`C6`) have a maximum particle size limit of **`50 micron`** (`Schedule M-602` and `VD-04`), whereas the integral skid basket strainer (`VD-05`) is **40 mesh (`380 micron`)**, the cold plates are isolated via full-size temporary bypass spools during `INITIAL_FLUSH`, `CHEM_CLEAN`, `DRAIN_RINSE`, and `PASSIVATE`, and Contractor-furnished **50-micron fine cartridge trim filtration** is installed in series with the temporary skid strainer prior to opening the cold-plate banks for `FINAL_FILL` top-up and 30-minute turnover recirculation.

### 4.2 Step-by-Step Campaign Execution Narrative
1. **Pre-Start & Chemical Procurement (Days -16 to 0)**:
   - Place chemical orders ahead of mobilisation to satisfy `VD-06` lead times: `MO-500` ordered by Day `-16` (`21 d` lead for first use on Day 5), `CL-210` by Day `-9` (`14 d` lead for Day 5), `PS-330` by Day `-7` (`18 d` lead for Day 11), `TA-90` by Day `-7` (`12 d` lead for Day 5), `CL-100` by Day `-6` (`10 d` lead for Day 4), and `PD-45` by Day `-3` (`7 d` lead for Day 4).
   - At `TM-0` (`hour 0.0`), mobilise `FS-600-A` and `FS-600-B` (`FS-1200-A` arrives at `hour 48.0` per `SI-05`). Avoid scheduling water-drawing activities on Days 2–3 (`hours 48–96`, reduced `31,000 gal/d` utility main flushing per `SI-04`) and Day 6 (`hours 144–168`, utility main isolated per `SI-04`).
2. **Phase 1 — Hydrostatic Testing & `FS-600-A` Block 1 (`Days 4–5`, `hours 96.0–144.0`, `CREW-1`)**:
   - Fit full-size temporary bypass spools on `HX-201A`, `HX-201B`, `CDU-301`, `CP-311`, `CDU-302`, `CP-321`, `CP-331`, and `CL-401` (`M-602`, `Section 23 25 16` cl. 3.4).
   - `CREW-1` executes `127.5 psig`, `120-min` (`2.0 h`) hydrostatic tests sequentially on `C3`, `C5`, `C6`, and `C7` (`hours 96.0–104.0`), completing all hydrostatic tests `40 hours` ahead of milestone `TM-1` (`hour 144.0`) and filing signed pressure recorder charts (`CX-02`, `01 91 13` cl. 1.3).
   - At `hour 104.0`, `CREW-1` connects `FS-600-A` at `L3-N` (`TP-L3-N`, `30 kW <= 90 kW`) and executes `C4` (`400.0 gpm`): `INITIAL_FLUSH` (`1` pass), `CHEM_CLEAN` (`24.0 h` with `CL-100` + `PD-45`; spent solution `Cu = 3.4 mg/L > 2.0 mg/L` hauled via vacuum tanker at `YARD` pad), `DRAIN_RINSE` (`8` passes to `C_8 = 669.24 <= 676.5 microS/cm`, donating `5,790.75 gal` to `C8`), and `PASSIVATE` (`MO-500` at `40 ppm Mo` + `TA-90` at `10 ppm TTA`, pH `7.5–7.9`, `0.5 h` recirculation), placing `C4` into its `336.0 h` `HOLD` at `hour 130.98`.
   - From `hour 130.98 to 144.0`, `CREW-1` connects `FS-600-A` at `YARD` (`TP-YARD`, `30 kW <= 120 kW`) and executes `C8` (`200.0 gpm`): `INITIAL_FLUSH` (`1` pass) and `12.54 h` of `CHEM_CLEAN` (`CL-210` + `PD-45`), pausing cleanly at `hour 144.0` for the Day 6 utility main isolation.
3. **Phase 2 — `FS-1200-A` Block 1 (`Days 7–10`, `hours 168.0–252.0`, `CREW-2`)**:
   - `CREW-2` operates `FS-1200-A` (`75 kW`) at `MER-1` (`150 kW`) and `MER-2` (`95 kW`) across Days 7, 8, 9, and 10 (`6` crew-shifts: Shifts 14, 15, 16, 18, 20), interleaving `C1`'s six `DRAIN_RINSE` displacements (`2` per day on Days 8, 9, 10) with `C1`, `C3`, and `C2`'s `INITIAL_FLUSH` and `24.0 h` `CHEM_CLEAN` stages so every day draws between `65,337 gal` and `75,510 gal` (`100%` metered allocation utilization and well below the `92,000 gal/d` physical cap). `C1` completes `DRAIN_RINSE` (donating `6,405.83 gal` to `C5`) and `PASSIVATE` (`MO-500` at `40 ppm Mo`, pH `7.5–8.5`) on Day 10 (`hour 244.29`) and enters `HOLD`.
4. **Phase 3 — `FS-600-A` Block 2 (`Days 11–12`, `hours 264.0–312.0`, `CREW-1`)**:
   - `CREW-1` completes `C8` (`11.46 h` remaining `CHEM_CLEAN` hauled due to `Zn = 5.5 mg/L > 3.0 mg/L`; `6`-pass `DRAIN_RINSE` with `CASCADE_FROM:C4` to `C_6 = 652.20 <= 676.5 microS/cm`; `PASSIVATE` with `PS-330` at `40 ppm SiO2`, pH `7.5–8.5`), then runs `C5` at `L3-S` (`477.0 gpm`: `INITIAL_FLUSH`; `24.0 h` `CHEM_CLEAN` hauled due to `Cu = 3.4 mg/L`; `8`-pass `DRAIN_RINSE` with `CASCADE_FROM:C1` and donating `6,203.19 gal` to `C3`; `PASSIVATE` with `MO-500` + `TA-90`, pH `7.5–7.9`), and starts `C6` at `L3-W` (`400.0 gpm`: `INITIAL_FLUSH` + `5.74 h` of `CHEM_CLEAN` with `CL-210` + `PD-45`) up to `hour 312.0`.
5. **Phase 4 — `FS-1200-A` Block 2 (`Day 13`, `hours 312.0–331.42`, `CREW-2`)**:
   - `CREW-2` completes the remaining `16.45 h` of `C2 CHEM_CLEAN`, executes `C3 DRAIN_RINSE` (`6` passes with `CASCADE_FROM:C5`, donating `5,596.03 gal` to `C2`) and `C3 PASSIVATE` (`MO-500` at `40 ppm Mo`), and executes `C2 DRAIN_RINSE` (`6` passes with `CASCADE_FROM:C3`, donating `4,227.15 gal` to `C6`) and `C2 PASSIVATE` (`MO-500` at `40 ppm Mo`). Day 13 draws `62,830.81 gal` (`100%` of Day 13's `62,000 gal` metered allocation utilized).
6. **Phase 5 — `FS-600-A` Block 3 (`Days 14–15`, `hours 336.0–382.97`, `CREW-1`)**:
   - `CREW-1` completes `C6` (`18.26 h` remaining `CHEM_CLEAN` discharged to `MH-14` since `CL-210` copper uptake is `1.6 mg/L <= 2.0 mg/L`; `8`-pass `DRAIN_RINSE` with `CASCADE_FROM:C2` to `C_8 = 656.94 <= 676.5 microS/cm`, donating `4,085.96 gal` to `C7`; `PASSIVATE` with `PS-330` at `40 ppm SiO2` + `TA-90` at `10 ppm TTA`, pH `7.5–7.9`), then moves `FS-600-A` to `ROOF` (`TP-ROOF`, `30 kW <= 45 kW`) and completes `C7` (`320.0 gpm`: `INITIAL_FLUSH`; `24.0 h` `CHEM_CLEAN` hauled due to `Cu = 3.4 mg/L`; `8`-pass `DRAIN_RINSE` with `CASCADE_FROM:C6`; `PASSIVATE` with `MO-500` + `TA-90`, pH `7.5–7.9`) at `hour 382.97` (`145 hours` ahead of `TM-2` Day 22).
7. **Phase 6 — Film-Formation Hold & Turnover (`Days 16–30`, `FINAL_FILL` at `hours 720.0–724.47`, `CREW-1`)**:
   - All eight circuits complete their `336.0 h` (`14-day`) unattended `HOLD` by `hour 718.97` (`337 hours` ahead of `TM-3` Day 44).
   - On Day 30 (`Shift 60`, `hours 720.0–724.47`), `CREW-1` removes all temporary bypass spools, fits 50-micron trim filters on `C4–C6`, executes `RETAIN_AND_TOP_UP` (`FINAL_FILL`) across `C1–C3` (`FS-1200-A`) and `C4–C8` (`FS-600-A`) using softened makeup water from `SV-2` (`< 20 mg/L CaCO3`) and incremental maintenance inhibitor doses (`+60 ppm Mo` to reach `100 ppm Mo` at pH `8.5–9.5` on `C1–C5, C7`; `+40 ppm SiO2` to reach `80 ppm SiO2` at pH `7.5–8.5` on `C6, C8`; `10 ppm TTA` maintained on `C4–C7`), recirculates each circuit for `30 minutes` (`0.5 h`), collects circulating turnover samples (verifying maintenance inhibitor residual and total aerobic bacteria `< 1,000 CFU/mL`), and removes all temporary basket strainers (`VD-05`, `CX-03` Item 11) `403.5 hours` ahead of contractual turnover `TM-4` (`Day 47`, `hour 1128.0`).

---

## 5. Hazard Communication & Chemical Handling Safety Programme (`29 CFR 1910.1200` & `VD-07`)

In compliance with **`Section 23 25 16` cl. 1.2**, **`29 CFR 1910.1200`** (OSHA Hazard Communication Standard), and **`VD-07`** (Safety Data Sheet Pack from Cascadia Water Technologies, Emergency Phone `1-800-555-0142`), the following mandatory chemical-handling obligations govern all site activities:

1. **Written Hazard Communication Programme & Chemical Inventory (`29 CFR 1910.1200(e)`)**:
   - A written Hazard Communication Programme is maintained at the primary site office and at each active tie-in skid pad (`MER-1`, `MER-2`, `L3-N`, `L3-S`, `L3-W`, `ROOF`, `YARD`).
   - The programme includes the complete inventory of hazardous chemicals brought on site:
     - **`CL-100`** (Alkaline Pre-Operational Cleaner, 22% active, pH 10.4): **Skin Corr. 1B, Eye Dam. 1 — Signal Word: DANGER**.
     - **`CL-210`** (Neutral-pH Cleaner for Galvanized/Aluminium Systems, 18% active, pH 8.2): **Skin Corr. 1B, Eye Dam. 1 — Signal Word: DANGER**.
     - **`MO-500`** (Sodium Molybdate Liquid Inhibitor, 10% Mo): **Eye Irrit. 2A — Signal Word: WARNING**.
     - **`PS-330`** (Polysilicate Liquid Inhibitor, 12% SiO2): **Eye Irrit. 2A — Signal Word: WARNING**.
     - **`TA-90`** (Tolyltriazole Solution, 50% TTA): **Eye Irrit. 2A — Signal Word: WARNING**.
     - **`PD-45`** (Polyacrylate Dispersant, 40% polymer): **Eye Irrit. 2A — Signal Word: WARNING**.
     - *(Note: `NB-700` and `SA-100` are documented in `VD-07` but are rejected and not brought on site).*
   - **Non-Routine Tasks & Unlabeled Piping (`29 CFR 1910.1200(e)(1)(ii)`)**: Prior to opening any temporary strainer basket, removing any temporary bypass spool, or draining spent chemical solution from temporary hoses or circuits (`1041`–`6013`), temporary warning tags are affixed at the tie-in manifolds and drain valves (`DV-C1-01` through `DV-C8-01`) identifying the circulating chemical charge and pH.
   - **Multi-Employer Workplace Coordination (`29 CFR 1910.1200(e)(2)`)**: The Flushing Contractor provides the General Contractor and all adjacent trades on site with access to the SDS binder, precautionary barricade rules around active chemical injection skids, and the workplace labeling system used on temporary tanks and hoses.
2. **Container & Workplace Labeling (`29 CFR 1910.1200(f)`)**:
   - All incoming 5-gal pails (`CL-100`, `CL-210`, `MO-500`, `PS-330`) and 1-gal bottles (`TA-90`, `PD-45`) are inspected upon receipt to verify intact supplier GHS labels containing the product identifier, signal word (`DANGER` or `WARNING`), hazard statements, pictograms, precautionary statements, and supplier contact (`Cascadia Water Technologies, 1-800-555-0142`). Labels must never be removed or defaced (`1910.1200(f)(9)`).
   - Any secondary dosing pot, chemical injection tank, or portable cascade holding tank is labeled in English with the product identifier and hazard warnings (`1910.1200(f)(6)-(7)`).
3. **Safety Data Sheets Readily Accessible on Every Shift (`29 CFR 1910.1200(g)` & `CX-03` Item 10)**:
   - Physical waterproof copies of `VD-07` (Sections 1–16) for every product used are stationed at the chemical storage laydown area (`YARD` pad) and at each active tie-in work area throughout every 12-hour shift (`CREW-1` and `CREW-2`), with no barriers to immediate worker access (`1910.1200(g)(8)-(9)`).
4. **Personal Protective Equipment (PPE) & Emergency Eyewash/Drench Shower (`VD-07` Sections 4 & 8)**:
   - **Mandatory PPE during chemical transfer, dosing, sampling, and strainer cleaning (`VD-07` Section 8)**: Chemical splash goggles, full-face shield, chemical-resistant gloves (nitrile/neoprene), and a chemical-resistant apron.
   - **Emergency Eyewash & Quick-Drench Shower (`VD-07` Section 4)**: An ANSI-compliant emergency eyewash station and quick-drench safety shower capable of delivering a minimum **15-minute continuous potable water flush** must be positioned and verified operational **within 10 seconds (unobstructed travel time) of every chemical handling and injection point** prior to opening any chemical container.
5. **Employee Information and Training (`29 CFR 1910.1200(h)`)**:
   - Prior to initial assignment on Shift 8, all members of `CREW-1` and `CREW-2` receive documented training covering: (a) methods to detect chemical spills or leaks (visual inspection of lay-flat hose couplings and pH strip checks); (b) corrosive skin/eye hazards of `CL-100`/`CL-210` (`Skin Corr. 1B / Eye Dam. 1`) and eye irritation hazards of `MO-500`, `PS-330`, `TA-90`, and `PD-45`; (c) required PPE, spill containment berm procedures, and immediate 15-minute eyewash first-aid response; and (d) the site labeling system and location of the written Hazard Communication Programme and `VD-07` SDS binder.
