#!/usr/bin/env python3
"""Generate all PCW flushing deliverables - master script v4 (per-displacement rinse)."""
import math, json, csv, os, sys
sys.path.insert(0, '/filesystem/final_batch4__mechanical_task5_pcw_flush_mop__blind/output')
from compute import *
from collections import defaultdict

OUTDIR = '/filesystem/final_batch4__mechanical_task5_pcw_flush_mop__blind/output'

SKID_ASSIGN = {
    'C1': ['FS-1200-A'],
    'C2': ['FS-1200-A'],
    'C3': ['FS-1200-A'],
    'C4': ['FS-600-A'],
    'C5': ['FS-1200-A'],
    'C6': ['FS-600-B'],
    'C7': ['FS-600-A'],
    'C8': ['FS-600-B'],
}

CREW_A = 'CREW-A'
CREW_B = 'CREW-B'
N_F = 1
HOLD_DAYS = 10.0
HOLD_H = HOLD_DAYS * 24.0

CREW_SHIFT_RATE = 820.0
WATER_METERED_RATE = 6.20
WATER_TRUCKED_RATE = 19.80
METERED_ALLOC = 62000
TRUCKED_LIMIT = 30000
MAX_DAY_DRAW = 92000
SCHEDULE_WATER_LIMIT = 90000  # safety margin in scheduler
SEWER_RATE = 4.00
TANKER_RATE = 168.00
DISCHARGE_CAP = 540000

def stage_durations(cid):
    ci = CINFO[cid]
    Q = ci['q_req']
    Vf = ci['flush_vol']
    t_disp = Vf / Q / 60.0
    n_r, eta, C0 = rinse_displacements(cid, TREATMENT[cid]['cleaner'])
    t_initial = N_F * t_disp
    t_chem = max(24.0, t_disp)
    t_rinse = n_r * t_disp
    t_pass = t_disp + 0.5
    return {
        't_disp': t_disp, 'n_r': n_r, 'eta': eta, 'C0': C0,
        't_initial': t_initial, 't_chem': t_chem, 't_rinse': t_rinse, 't_pass': t_pass,
    }

def build_schedule():
    skid_sequences = {
        'FS-1200-A': ['C1', 'C2', 'C3', 'C5'],
        'FS-600-A': ['C4', 'C7'],
        'FS-600-B': ['C6', 'C8'],
    }
    skid_available = {'FS-600-A': 0.0, 'FS-600-B': 0.0, 'FS-1200-A': 48.0}
    crew_next = {CREW_A: 0.0, CREW_B: 0.0}
    
    activities = []
    act_counter = 0
    skid_next = dict(skid_available)
    hold_end = {}
    day_water = defaultdict(float)
    
    def add_water(day, amount):
        day_water[day] += amount
    
    def water_on_day(day):
        return day_water[day]
    
    def find_start(skid_ready, crew_ready, water_amount, duration_h):
        """Earliest start satisfying skid, crew, and daily water limit."""
        t = max(skid_ready, crew_ready)
        max_iter = 1000
        for _ in range(max_iter):
            day = int(t // 24)
            if water_on_day(day) + water_amount <= SCHEDULE_WATER_LIMIT:
                return t
            t = (day + 1) * 24.0
        return t  # fallback
    
    for skid_id, circuit_list in skid_sequences.items():
        for cid in circuit_list:
            dur = stage_durations(cid)
            ci = CINFO[cid]
            Q = ci['q_req']
            Vf = ci['flush_vol']
            t_disp = dur['t_disp']
            n_r = dur['n_r']
            
            # INITIAL_FLUSH
            act_counter += 1
            act_id = f'A{act_counter:03d}'
            best_crew = min(crew_next, key=crew_next.get)
            s = find_start(skid_next[skid_id], crew_next[best_crew], Vf, dur['t_initial'])
            f = s + dur['t_initial']
            add_water(int(s // 24), Vf)
            activities.append({
                'activity_id': act_id, 'circuit_id': cid, 'stage': 'INITIAL_FLUSH',
                'predecessor_ids': '', 'start_h': round(s, 2), 'finish_h': round(f, 2),
                'skid_id': skid_id, 'crew_id': best_crew,
                'water_draw_gal': round(Vf, 1), 'effluent_gal': round(Vf, 1),
            })
            skid_next[skid_id] = f
            crew_next[best_crew] = f
            
            # CHEM_CLEAN
            act_counter += 1
            act_id = f'A{act_counter:03d}'
            best_crew = min(crew_next, key=crew_next.get)
            s = find_start(skid_next[skid_id], crew_next[best_crew], Vf, dur['t_chem'])
            f = s + dur['t_chem']
            add_water(int(s // 24), Vf)
            activities.append({
                'activity_id': act_id, 'circuit_id': cid, 'stage': 'CHEM_CLEAN',
                'predecessor_ids': '', 'start_h': round(s, 2), 'finish_h': round(f, 2),
                'skid_id': skid_id, 'crew_id': best_crew,
                'water_draw_gal': round(Vf, 1), 'effluent_gal': round(Vf, 1),
            })
            skid_next[skid_id] = f
            crew_next[best_crew] = f
            
            # DRAIN_RINSE - per displacement
            for disp in range(n_r):
                act_counter += 1
                act_id = f'A{act_counter:03d}'
                best_crew = min(crew_next, key=crew_next.get)
                s = find_start(skid_next[skid_id], crew_next[best_crew], Vf, t_disp)
                f = s + t_disp
                add_water(int(s // 24), Vf)
                activities.append({
                    'activity_id': act_id, 'circuit_id': cid, 'stage': 'DRAIN_RINSE',
                    'predecessor_ids': '', 'start_h': round(s, 2), 'finish_h': round(f, 2),
                    'skid_id': skid_id, 'crew_id': best_crew,
                    'water_draw_gal': round(Vf, 1), 'effluent_gal': round(Vf, 1),
                })
                skid_next[skid_id] = f
                crew_next[best_crew] = f
            
            # PASSIVATE
            act_counter += 1
            act_id = f'A{act_counter:03d}'
            best_crew = min(crew_next, key=crew_next.get)
            s = find_start(skid_next[skid_id], crew_next[best_crew], 0.0, dur['t_pass'])
            f = s + dur['t_pass']
            activities.append({
                'activity_id': act_id, 'circuit_id': cid, 'stage': 'PASSIVATE',
                'predecessor_ids': '', 'start_h': round(s, 2), 'finish_h': round(f, 2),
                'skid_id': skid_id, 'crew_id': best_crew,
                'water_draw_gal': 0.0, 'effluent_gal': 0.0,
            })
            skid_next[skid_id] = f
            crew_next[best_crew] = f
            
            # HOLD
            act_counter += 1
            act_id = f'A{act_counter:03d}'
            s = skid_next[skid_id]
            f = s + HOLD_H
            hold_end[cid] = f
            activities.append({
                'activity_id': act_id, 'circuit_id': cid, 'stage': 'HOLD',
                'predecessor_ids': '', 'start_h': round(s, 2), 'finish_h': round(f, 2),
                'skid_id': 'NONE', 'crew_id': 'NONE', 'water_draw_gal': 0.0, 'effluent_gal': 0.0,
            })
            skid_next[skid_id] = s
    
    # FINAL_FILL
    for cid in sorted(hold_end, key=lambda c: hold_end[c]):
        skid_id = SKID_ASSIGN[cid][0]
        ci = CINFO[cid]
        Q = ci['q_req']
        Vs = ci['sys_vol']
        Vf = ci['flush_vol']
        t_turnover = Vs / Q / 60.0 + 0.5
        
        act_counter += 1
        act_id = f'A{act_counter:03d}'
        best_crew = min(crew_next, key=crew_next.get)
        s = find_start(skid_next[skid_id], crew_next[best_crew], Vs, t_turnover)
        f = s + t_turnover
        add_water(int(s // 24), Vs)
        activities.append({
            'activity_id': act_id, 'circuit_id': cid, 'stage': 'FINAL_FILL',
            'predecessor_ids': '', 'start_h': round(s, 2), 'finish_h': round(f, 2),
            'skid_id': skid_id, 'crew_id': best_crew,
            'water_draw_gal': round(Vs, 1), 'effluent_gal': round(Vf, 1),
        })
        skid_next[skid_id] = f
        crew_next[best_crew] = f
    
    return activities

schedule_activities = build_schedule()
max_finish = max(a['finish_h'] for a in schedule_activities)
print(f"Max finish hour: {max_finish:.1f} (TM-4 deadline: 1128)")
print(f"Within deadline: {max_finish <= 1128}")

day_water2 = defaultdict(float)
for a in schedule_activities:
    if a['water_draw_gal'] > 0:
        s, f = a['start_h'], a['finish_h']
        v = a['water_draw_gal']
        t = s
        while t < f:
            day_end = (int(t // 24) + 1) * 24
            seg_end = min(f, day_end)
            frac = (seg_end - t) / (f - s)
            day_water2[int(t // 24)] += v * frac
            t = seg_end

print("\nWater draw by day:")
max_daily = 0
for d in sorted(day_water2):
    w = day_water2[d]
    max_daily = max(max_daily, w)
    flag = " *** EXCEEDS ***" if w > MAX_DAY_DRAW else ""
    print(f"  Day {d} (hours {d*24}-{(d+1)*24}): {w:,.0f} gal{flag}")
print(f"\nMax daily draw: {max_daily:,.0f} gal (limit: {MAX_DAY_DRAW:,})")