# Reconnaissance & Constraints Extraction Summary (`slice_01_recon`)

## 1. Workspace Document & Model Inventory

### 1.1 Specifications (`specs/`)
| Document | Title | Revision & Date | Status / Scope |
|---|---|---|---|
| `specs/23_25_16_PCW_Cleaning_Flushing_and_Passivation_Rev3.docx` | Section 23 25 16 — Process Cooling Water Cleaning, Flushing and Passivation | IFC Rev 3, 2026-07-14 | **GOVERNING** primary specification for PCW pre-operational cleaning, flushing, passivation, turnover, water/effluent accounting, and cost basis. |
| `specs/23_21_16_Hydronic_Piping_excerpt_Rev3.docx` | Section 23 21 16 — Hydronic Piping (Excerpt) | IFC Rev 3, 2026-07-14 | **GOVERNING** for pipe materials (cl. 2.1), absolute hydraulic roughness (cl. 2.2), pressure ratings (cl. 2.4), and hydrostatic test regime (cl. 3.3). |
| `specs/01_91_13_General_Commissioning_Requirements_excerpt.docx` | Section 01 91 13 — General Commissioning Requirements (Excerpt) | IFC Rev 2, 2026-05-28 | **GOVERNING** for submittals/evidence rule (cl. 1.3), utility/crew coordination (cl. 1.7), and deficiency closure (cl. 1.9). |
| `specs/22_11_23_Domestic_Water_Pumps_excerpt.docx` | Section 22 11 23 — Domestic Water Pumps (Excerpt) | IFC Rev 1, 2026-03-02 | **OUT OF SCOPE / EXCLUDED** (cl. 2.1 & 3.1 explicitly state domestic water piping/equipment are not part of the PCW system and not flushed under Section 23 25 16). |

### 1.2 Adopted & Non-Adopted Standards (`standards/`)
| Document | Title | Edition | Status / Scope |
|---|---|---|---|
| `standards/UFC_3-230-13_Industrial_Water_Treatment_Operation_and_Maintenance_2023.pdf` | UFC 3-230-13 — Industrial Water Treatment Operation and Maintenance | 1 March 2023 (276 pp.) | **GOVERNING** water-treatment criteria adopted by 23 25 16 cl. 1.2 (foulant suspension velocity/dispersant cl. 5-3.7; pre-operational cleaning & rinse criteria cl. 5-7.3.1 to 5-7.3.2.4; passivation Tables 5-14 & 5-15; closed-system treatment programs cl. 6-2.1, 6-2.2, Tables 6-1, 6-2, 6-3). |
| `standards/DOE-HDBK-1012-3-92_Fluid_Flow_Volume_3.pdf` | DOE-HDBK-1012/3-92 — Thermodynamics, Heat Transfer, and Fluid Flow, Vol. 3 | June 1992 (82 pp.) | **GOVERNING** hydraulic relations adopted by 23 25 16 cl. 1.2 & cl. 3.2 (continuity Eq. 3-1, Reynolds number, Darcy head loss Eq. 3-14, equivalent length Eq. 3-16, centrifugal pumps in parallel pp. 53–54). |
| `standards/40_CFR_403_General_Pretreatment_Regulations_2024.pdf` | 40 CFR Part 403 — General Pretreatment Regulations for Existing and New Sources of Pollution | 2024-07-01 (49 pp.) | **GOVERNING** POTW discharge pretreatment rules adopted by 23 25 16 cl. 1.2 & cl. 3.7 (§ 403.5(a) general prohibitions; § 403.5(b)(1)–(8) specific prohibitions including pH >= 5.0 and temperature <= 104 °F / 40 °C; § 403.5(c)–(d) local limits). |
| `standards/29_CFR_1910.1200_Hazard_Communication_2024.pdf` | 29 CFR § 1910.1200 — Hazard Communication | 2024-07-01 (129 pp.) | **GOVERNING** chemical hazard communication standard adopted by 23 25 16 cl. 1.2 (§ 1910.1200(e) written program & non-routine tasks/unlabeled pipes; (f) labels; (g) 16-section SDS accessibility; (h) employee training). |
| `standards/UFC_3-240-13FN_Industrial_Water_Treatment_2005_CANCELLED.pdf` | UFC 3-240-13FN — Industrial Water Treatment Operation and Maintenance | 25 May 2005 (262 pp.) | **CANCELLED / PROHIBITED** (23 25 16 cl. 1.2 explicitly forbids use; must be excluded from `constraint_register.csv` and documented as rejected in `MOP.md`). |
| `standards/40_CFR_122_NPDES_Permit_Programs_2024.pdf` | 40 CFR Part 122 — EPA Administered Permit Programs: The NPDES | 2024-07-01 (128 pp.) | **NON-ADOPTED / OUT OF SCOPE** (not adopted in 23 25 16 cl. 1.2; SW-03 General Condition 2 & RFI-031 confirm discharge is to POTW under 40 CFR 403, not surface water/NPDES). Exclude from `constraint_register.csv`. |

### 1.3 Drawings & CAD Models (`drawings/`)
| File | Title | Revision & Date | Key Extracted Content |
|---|---|---|---|
| `drawings/M-PID-101_Pcw_Primary_Loop_And_Fan-Wall_Branch_RevC.dxf` | PCW Primary Loop and Fan-Wall Branch | IFC Rev C, 2026-07-14 | **C1** (`TI-C1-01`/`TI-C1-02`): lines `1041` (12" CS x1), `1042` (12" CS x1), `1043` (6" CS x4), `1044` (6" CS x4); equip `PMP-101`, `BT-101`. **C7** (`TI-C7-01`/`TI-C7-02`): lines `5011` (6" CS x1), `5012` (6" CS x1), `5013` (2.5" CU x4); equip `CL-401`. |
| `drawings/M-PID-102_Pcw_Heat_Exchanger_Bays_RevC.dxf` | PCW Heat Exchanger Bays | IFC Rev C, 2026-07-14 | **C2** (`TI-C2-01`/`TI-C2-02`): lines `2011` (8" CS x1), `2012` (8" CS x1), `2013` (4" CS x3); equip `HX-201A`. **C3** (`TI-C3-01`/`TI-C3-02`): lines `2021` (8" CS x1), `2022` (8" CS x1), `2023` (6" CS x2); equip `HX-201B`. |
| `drawings/M-PID-103_Pcw_Cdu_Distribution_RevC.dxf` | PCW CDU Distribution | IFC Rev C, 2026-07-14 | **GOVERNING** (supersedes Rev A). **C4** (`TI-C4-01`/`TI-C4-02`): lines `4021` (6" CS x1), `4022` (6" CS x1), `4023` (4" CS x2), `4024` (3" CU x4); equip `CDU-301`, `CP-311`. **C5** (`TI-C5-01`/`TI-C5-02`): lines `4031` (6" CS x1), `4032` (6" CS x1), `4033` (4" CS x3), `4034` (3" CU x4); equip `CDU-302`, `CP-321`. **C6** (`TI-C6-01`/`TI-C6-02`): lines `4041` (6" CS x1), `4042` (6" CS x1), `4043` (3" CU x3); equip `CP-331`. |
| `drawings/M-PID-103_Pcw_Cdu_Distribution_RevA_SUPERSEDED.dxf` | PCW CDU Distribution (Rev A) | Rev A, 2026-07-14 | **SUPERSEDED BY REV C** (had line `4033` misplaced in C4 as `x2` instead of in C5 as `x3`). Must not be cited in `constraint_register.csv`. |
| `drawings/M-PID-104_Pcw_Makeup_And_Fill_RevC.dxf` | PCW Makeup and Fill | IFC Rev C, 2026-07-14 | **C8** (`TI-C8-01`/`TI-C8-02`): lines `6011` (4" GALV x1), `6012` (4" GALV x1), `6013` (3" GALV x2); equip `ST-601`. |
| `drawings/M-ISO-201_PCW_Isometric_RevC.dxf` | PCW Isometric (C1, C2) | IFC Rev C, 2026-07-14 | **C1**: Tie-in `MER-1` El. `+0'-0"`, High point `AV-C1-01` El. `+26'-0"` (lift = `26.0 ft`), Low point drain `DV-C1-01`. **C2**: Tie-in `MER-1` El. `+0'-0"`, High point `AV-C2-01` El. `+22'-0"` (lift = `22.0 ft`), Low point drain `DV-C2-01`. |
| `drawings/M-ISO-202_PCW_Isometric_RevC.dxf` | PCW Isometric (C3, C8) | IFC Rev C, 2026-07-14 | **C3**: Tie-in `MER-2` El. `+0'-0"`, High point `AV-C3-01` El. `+22'-0"` (lift = `22.0 ft`), Low point drain `DV-C3-01`. **C8**: Tie-in `YARD` El. `+0'-0"`, High point `AV-C8-01` El. `+14'-0"` (lift = `14.0 ft`), Low point drain `DV-C8-01`. |
| `drawings/M-ISO-203_PCW_Isometric_RevC.dxf` | PCW Isometric (C4, C5, C6) | IFC Rev C, 2026-07-14 | **C4**: Tie-in `L3-N` El. `+0'-0"`, High point `AV-C4-01` El. `+48'-0"` (lift = `48.0 ft`), Drain `DV-C4-01`. **C5**: Tie-in `L3-S` El. `+0'-0"`, High point `AV-C5-01` El. `+44'-0"` (lift = `44.0 ft`), Drain `DV-C5-01`. **C6**: Tie-in `L3-W` El. `+0'-0"`, High point `AV-C6-01` El. `+48'-0"` (lift = `48.0 ft`), Drain `DV-C6-01`. |
| `drawings/M-ISO-204_PCW_Isometric_RevC.dxf` | PCW Isometric (C7) | IFC Rev C, 2026-07-14 | **C7**: Tie-in `ROOF` El. `+0'-0"`, High point `AV-C7-01` El. `+72'-0"` (lift = `72.0 ft`), Low point drain `DV-C7-01`. |
| `drawings/C-101_Site_Logistics_and_Laydown_RevB.dxf` | Site Logistics and Laydown | IFC Rev B, 2026-06-30 | Skid pad dimensions: `MER-1` (40'x26'), `MER-2` (32'x22'), `L3-N` (26'x18'), `L3-S` (26'x18'), `L3-W` (26'x18'), `ROOF` (22'x16'), `YARD` (60'x34'). Haul-off tanker standing at YARD pad only. Notes on softened water outlet `SV-2` / softener `SF-1` (88,000 grains/day capacity, < 20 mg/L CaCO3, no blending). |
| `drawings/E-701_Temporary_Power_Single_Line_RevB.dxf` | Temporary Power Single Line | IFC Rev B, 2026-06-30 | 480V 3-phase temporary panels: `TP-MER-1` (150 kW), `TP-MER-2` (95 kW), `TP-L3-N` (90 kW), `TP-L3-S` (90 kW), `TP-L3-W` (90 kW), `TP-ROOF` (45 kW), `TP-YARD` (120 kW). |

### 1.4 Schedules (`schedules/`)
- `schedules/M-601_PCW_Pipe_Schedule_RevC.xlsx`: 27 pipe lines (`1041`–`6013`) with exact Inside Diameter (in), Length per Leg (ft), Parallel Legs, Fittings/Valves `Sum L/D`, and Material.
- `schedules/M-602_PCW_Equipment_Schedule_RevC.xlsx`: 11 equipment items (`PMP-101`, `BT-101`, `HX-201A`, `HX-201B`, `CDU-301`, `CP-311`, `CDU-302`, `CP-321`, `CP-331`, `CL-401`, `ST-601`) with hold-up volume, wetted materials, rated dP and flow, max allowable dP, max temperature, max particle size, pressure rating, and bypass provision.
- `schedules/M-603_Valve_and_Tie-In_Schedule_RevC.xlsx`: 16 tie-in valves (`TI-C1-01`..`TI-C8-02`) mapping circuits `C1`–`C8` to P&ID sheets and tie-in locations (`MER-1`, `MER-2`, `L3-N`, `L3-S`, `L3-W`, `ROOF`, `YARD`).

### 1.5 Site Documents (`site/`) — Including OCR of Scanned Image PDFs
- `site/SW-01_Construction_Water_Availability_Memo.docx` (2026-07-02):
  - Metered construction water allocation: `62,000 gal/day` at `$6.20 / 1,000 gal`.
  - Trucked potable water: up to `30,000 gal/day` at `$19.80 / 1,000 gal` (hard daily ceiling = `92,000 gal/day` on normal days).
  - Rented flush skid fleet: `FS-600-A`, `FS-600-B`, `FS-1200-A` (charged per calendar day `[24k, 24k+24)` held).
  - Commissioning crews: max `2 crews`, charged per 12-hour shift `[12k, 12k+12)` attended at `$820.00 / shift`.
- `site/SI-04_Site_Instruction_Construction_Water_Utility_Works.docx` (2026-07-24):
  - **Varies SW-01 Sec 1**:
    - Project Day 2 (`hours 48 to 72`): metered allocation reduced to `31,000 gal` (max daily draw with trucked = `61,000 gal`).
    - Project Day 3 (`hours 72 to 96`): metered allocation reduced to `31,000 gal` (max daily draw with trucked = `61,000 gal`).
    - Project Day 6 (`hours 144 to 168`): main isolated, metered allocation = `0 gal` (max daily draw with trucked = `30,000 gal`).
- `site/SI-05_Site_Instruction_Flush_Skid_Delivery.docx` (2026-07-27):
  - **Varies SW-01 Sec 3**: `FS-1200-A` is delivered at **hour 48** (start of Project Day 2) and is unavailable before hour 48. `FS-600-A` and `FS-600-B` are available at hour 0.
- `site/SW-02_Municipal_Water_Analysis_Lab_Report.pdf` (Scanned PDF, Certificate No. 26-118440, 2026-06-24):
  - `pH = 7.6`, `Specific conductance = 615 microS/cm`, `Total hardness = 288 mg/L as CaCO3`, `Chloride = 505 mg/L`, `Sulfate = 355 mg/L` (`Cl + SO4 = 860 mg/L`), `Total iron = 0.09 mg/L`, `Silica = 11 mg/L as SiO2`, `Temperature at sampling = 68 degF`, `TSS < 1 mg/L`, `Turbidity = 0.3 NTU`. Unsoftened municipal supply; trucked water is from the same supply.
- `site/SW-03_Sanitary_Sewer_Discharge_Authorization.pdf` (Scanned PDF, IWD-2026-0417 Initial/Rev A, effective 2026-07-01) & `site/SW-03_Sanitary_Sewer_Discharge_Authorization_RevB.pdf` (Scanned PDF, IWD-2026-0417 Rev B, issued 2026-07-21):
  - **Rev B supersedes Rev A on Authorized Volume**: Programme total sewer discharge cap reduced from `540,000 gal` (in Rev A and cited in earlier RFI-031) to **`500,000 gallons`** at metered manhole `MH-14`.
  - Sewer discharge rate: **`$9.40 per 1,000 gallons`**.
  - Local limits from Rev A remain in force under Rev B Sec 3:
    - `pH`: `6.0 to 9.0 units`
    - `Temperature`: `<= 104 degF`
    - `Molybdenum, total`: `<= 0.5 mg/L`
    - `Zinc, total`: `<= 1.0 mg/L`
    - `Copper, total`: `<= 1.0 mg/L`
    - `Total suspended solids (TSS)`: `<= 300 mg/L`
    - `Silica`: no local limit
    - `Nitrite nitrogen`: no local limit
- `site/SW-04_Temporary_Power_Availability_RevB.xlsx`: Matches `E-701` kW and breaker ratings per tie-in location.

### 1.6 Vendor Data (`vendor_data/`)
- `vendor_data/VD-01_FlushSkid_FS-600_Datasheet.pdf`:
  - Pump curve: `(0 gpm, 182 ft), (150, 176), (300, 163), (450, 141), (600, 106), (700, 74)`. Max flow `700 gpm`.
  - Connected load: `30 kW` at 480V 3ph; Max temp `180 degF`; Max working pressure `150 psig`; Hose ID `4.026 in.`; Footprint `10 ft x 6 ft`; Rental rate `$430.00 / calendar day`.
- `vendor_data/VD-02_FlushSkid_FS-1200_Datasheet.pdf`:
  - Pump curve: `(0 gpm, 212 ft), (300, 204), (600, 188), (900, 159), (1200, 117), (1400, 82)`. Max flow `1,400 gpm`.
  - Connected load: `75 kW` at 480V 3ph; Max temp `180 degF`; Max working pressure `150 psig`; Hose ID `7.981 in.`; Footprint `16 ft x 8 ft`; Rental rate `$790.00 / calendar day`.
- `vendor_data/VD-03_PlateHX_PHE-450_Gasket_and_Limits.pdf`: `HX-201A`/`HX-201B` rated dP `46 ft w.c.` at `610 gpm` (max allowable dP `58 ft w.c.` in M-602 governs); max particle `500 micron`; max temp `185 degF`; design pressure `230 psig`; bypass during construction flushing and chemical cleaning.
- `vendor_data/VD-04_CDU_ColdPlate_Technical_Bulletin.pdf`: Cold plates (`CP-331` has 6061-T6 aluminium body + copper manifold; `CL-401` has aluminium fins on air side only, wetted path is copper). Max temp `130 degF`, max particle `50 micron`, fluid pH in service `7.0 to 8.5`. Requires aluminium-compatible treatment program (`Polysilicate-Azole`).
- `vendor_data/VD-05_Temporary_Strainer_and_Hose_Data.pdf`:
  - Basket strainer: `40 mesh` stainless steel (`380 micron` opening), clean dP `11 ft w.c.` at `600 gpm` (scales as `(Q_skid/600)^2`), max pressure `150 psig`, remove at `TM-4`.
  - Lay-flat hose: `300 ft` total run (supply + return) per skid; ID `4.026 in.` (FS-600) or `7.981 in.` (FS-1200); roughness `0.0008 ft` (per 23 21 16 cl. 2.2); max pressure `150 psig`.
- `vendor_data/VD-06_Water_Treatment_Chemicals_Quote_RevB.xlsx`:
  - `CL-100`: Alkaline cleaner, 22% active, 5 gal pail ($112, lead 10 d), pH 10.4 supplied, dose `1.5 gal / 1,000 gal V_s`. Spent solution: `C_0 = 2,600 microS/cm`, `pH = 8.4`; picks up `3.4 mg/L Cu` if copper pipe in flushed path (`> 1.0 mg/L` SW-03 limit -> **HAUL**!), `9.0 mg/L Zn` if galvanized steel.
  - `CL-210`: Neutral-pH cleaner for galvanized/aluminium systems, 18% active, 5 gal pail ($128, lead 14 d), pH 8.2 supplied, dose `2.0 gal / 1,000 gal V_s`. Spent solution: `C_0 = 2,150 microS/cm`, `pH = 8.1`; picks up `1.6 mg/L Cu` if copper pipe in flushed path (`> 1.0 mg/L` SW-03 limit -> **HAUL**!), `5.5 mg/L Zn` if galvanized steel (`> 1.0 mg/L` SW-03 limit -> **HAUL**!).
  - `MO-500`: Sodium molybdate liquid inhibitor, `10% Mo`, `10.9 lb/gal`, 5 gal pail ($172, lead 21 d). Note: Mo residual `40-60 ppm` exceeds SW-03 `0.5 mg/L Mo` limit if drained!
  - `PS-330`: Polysilicate liquid inhibitor, `12% SiO2`, `9.8 lb/gal`, 5 gal pail ($139, lead 18 d).
  - `NB-700`: Nitrite-borax-azole blend, `68% NO2`, 50 lb bag ($148, lead 10 d) — **DISQUALIFIED** by `SW-02` `Cl + SO4 = 860 mg/L > 800 mg/L` per `UFC 3-230-13 cl. 6-2.2.2`.
  - `TA-90`: Tolyltriazole solution, `50% TTA`, `8.9 lb/gal`, 1 gal bottle ($92, lead 12 d).
  - `PD-45`: Polyacrylate dispersant, `40% polymer`, `9.1 lb/gal`, 1 gal bottle ($46, lead 7 d).
  - `SA-100`: Soda ash, `99% Na2CO3`, 50 lb bag ($62, lead 5 d).
- `vendor_data/VD-07_SDS_pack.pdf`: SDS summaries for all 8 products; all require emergency eyewash and quick-drench shower within 10 seconds (15-min eye flush) and chemical splash goggles, face shield, chemical-resistant gloves, and apron during transfer.
- `vendor_data/VD-08_Air_Cooled_Chiller_Submittal.pdf`: **OUT OF SCOPE / EXCLUDED** (comfort cooling chiller ACCH-500, Note 1 & 2 state not part of PCW loop or Section 23 25 16).

### 1.7 Commissioning & Correspondence (`commissioning/`, `correspondence/`)
- `commissioning/CX-01_Turnover_Milestones_RevB.xlsx`:
  - `TM-0`: Day 0 (Hour 0) — Mobilisation, temp power energised.
  - `TM-1`: Day 6 (Hour 144) — All circuits hydrostatically tested.
  - `TM-2`: Day 22 (Hour 528) — Chemical cleaning of all circuits complete.
  - `TM-3`: Day 44 (Hour 1056) — Passivation film formation complete on all circuits.
  - `TM-4`: Day 47 (Hour 1128) — Temporary strainers removed, system turned over to owner (contractual hard deadline).
- `commissioning/CX-02_Hydrostatic_Test_Record_partial.csv` & `TR-0412`, `TR-0413`, `TR-0415`, `TR-0419` (Scanned PDFs):
  - **Defect / Evidence Gate (01 91 13 cl. 1.3 & 23 21 16 cl. 3.3)**: `CX-02` lists all 8 circuits as PASS at `127.5 psig` for `120 min`, citing `TR-0412` through `TR-0419`. However, only `TR-0412` (C1), `TR-0413` (C2), `TR-0415` (C4), and `TR-0419` (C8) are on file! Charts `TR-0414` (C3), `TR-0416` (C5), `TR-0417` (C6), and `TR-0418` (C7) are missing. Under `01 91 13 cl. 1.3`, results without filed evidence are not accepted. Under `23 21 16 cl. 3.3`, **C1, C2, C4, C8 must NOT be retested**, while **C3, C5, C6, C7 MUST be hydrostatically tested** before chemical cleaning (and by `TM-1`, Hour 144).
- `correspondence/RFI-009_Response_Roof_Curb_Flashing.docx`: **OUT OF SCOPE** (roofing scope only, no mechanical content).
- `correspondence/RFI-022_Response_Galvanized_Fill_Riser.docx`: Confirms lines `6011`, `6012`, `6013` and break tank `ST-601` in **C8** are hot-dip galvanized steel as specified.
- `correspondence/RFI-031_Response_Discharge_Route_and_Metering.docx`: Confirms discharge to POTW via metered manhole `MH-14` under `SW-03` (`IWD-2026-0417`), no storm/creek discharge, and vacuum tanker haul-off rate of **`$168.00 per 1,000 gallons`** (tanker standing at YARD pad only). Note: RFI-031's mention of the `540,000 gal` cap from initial `SW-03` (2026-07-06) was later superseded by `SW-03 Rev B` (`500,000 gal`, issued 2026-07-21).

---

## 2. Circuit-by-Circuit Engineering Synthesis

| Circuit | Tie-In Location & Panel (kW) | Lines (NPS, Mat, Legs) | Equipment (Vol gal, Bypassed?) | Pipe Vol (gal) | Flush Vol $V_f$ (gal) | System Vol $V_s$ (gal) | Static Lift (ft) | Gov. Seg (ID in.) | $v_{\min}$ (ft/s) | $Q_{\min}$ (gpm) | Hydro Owed? | Wetted Metallurgy |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **C1** | `MER-1` (`TP-MER-1`, 150 kW) | `1041` (12" CS x1), `1042` (12" CS x1), `1043` (6" CS x4), `1044` (6" CS x4) | `PMP-101` (2400, No), `BT-101` (5000, No) | 25,583.40 | 32,983.40 | 32,983.40 | 26.0 | `1043` (6.065) | 3.28 | 1,181.42 | **NO** (`TR-0412`) | Carbon Steel |
| **C2** | `MER-1` (`TP-MER-1`, 150 kW) | `2011` (8" CS x1), `2012` (8" CS x1), `2013` (4" CS x3) | `HX-201A` (2350, Yes) | 5,596.03 | 5,596.03 | 7,946.03 | 22.0 | `2011` (7.981) | 4.00 | 623.71 | **NO** (`TR-0413`) | CS, SS, Nitrile |
| **C3** | `MER-2` (`TP-MER-2`, 95 kW) | `2021` (8" CS x1), `2022` (8" CS x1), `2023` (6" CS x2) | `HX-201B` (2350, Yes) | 6,203.19 | 6,203.19 | 8,553.19 | 22.0 | `2023` (6.065) | 4.00 | 720.38 | **YES** (`TR-0414` missing) | CS, SS, Nitrile |
| **C4** | `L3-N` (`TP-L3-N`, 90 kW) | `4021` (6" CS x1), `4022` (6" CS x1), `4023` (4" CS x2), `4024` (3" CU x4) | `CDU-301` (1550, Yes), `CP-311` (1030, Yes) | 5,956.64 | 5,956.64 | 8,536.64 | 48.0 | `4021` (6.065) | 4.00 | 360.19 | **NO** (`TR-0415`) | CS, SS, Copper |
| **C5** | `L3-S` (`TP-L3-S`, 90 kW) | `4031` (6" CS x1), `4032` (6" CS x1), `4033` (4" CS x3), `4034` (3" CU x4) | `CDU-302` (1550, Yes), `CP-321` (1030, Yes) | 6,405.83 | 6,405.83 | 8,985.83 | 44.0 | `4033` (4.026) | 4.00 | 476.14 | **YES** (`TR-0416` missing) | CS, SS, Copper |
| **C6** | `L3-W` (`TP-L3-W`, 90 kW) | `4041` (6" CS x1), `4042` (6" CS x1), `4043` (3" CU x3) | `CP-331` (1450, Yes) | 4,227.15 | 4,227.15 | 5,677.15 | 48.0 | `4041` (6.065) | 4.00 | 360.19 | **YES** (`TR-0417` missing) | CS, Copper, **Aluminium** |
| **C7** | `ROOF` (`TP-ROOF`, 45 kW) | `5011` (6" CS x1), `5012` (6" CS x1), `5013` (2.5" CU x4) | `CL-401` (1950, Yes) | 4,085.96 | 4,085.96 | 6,035.96 | 72.0 | `5011` (6.065) | 3.28 | 295.36 | **YES** (`TR-0418` missing) | CS, Copper (Al fin dry) |
| **C8** | `YARD` (`TP-YARD`, 120 kW) | `6011` (4" GALV x1), `6012` (4" GALV x1), `6013` (3" GALV x2) | `ST-601` (3750, No) | 2,040.75 | 5,790.75 | 5,790.75 | 14.0 | `6013` (3.068) | 3.28 | 151.16 | **NO** (`TR-0419`) | **Galvanized Steel** |

---

## 3. Atomic Constraint Register Decomposition

All active requirements from the governing documents are decomposed into atomic clauses for `output/constraint_register.csv` (strictly excluding `UFC 3-240-13FN`, `M-PID-103 RevA`, `SW-03 RevA` superseded volume, `40 CFR 122`, `22 11 23`, `VD-08`, and `RFI-009`):
1. **Hydrostatic Testing (`23 21 16 cl. 3.3`, `01 91 13 cl. 1.3`, `CX-01`, `CX-02`, `M-602`, `VD-05`)**:
   - Test pressure `>= max(1.5 * 85, 125) = 127.5 psig`, and `<= min component rating = 150 psig` (`ST-601`, `VD-05` hose/strainer, `VD-01`/`VD-02` skids).
   - Minimum hold duration `>= 120 minutes` (`2.0 h`) with zero pressure loss and no visible leakage.
   - Evidence gate (`01 91 13 cl. 1.3`): only `C1`, `C2`, `C4`, `C8` have valid pressure charts (`TR-0412`, `TR-0413`, `TR-0415`, `TR-0419`) on file and must not be retested (`23 21 16 cl. 3.3`); `C3`, `C5`, `C6`, `C7` lack charts and must be tested before chemical cleaning and by `TM-1` (Day 6 / Hour 144).
2. **Hydraulic & Flushing Velocity Rules (`23 25 16 cl. 3.2 & 3.3`, `23 21 16 cl. 2.2`, `UFC 3-230-13 cl. 5-3.7`, `DOE-HDBK-1012/3-92`, `VD-01`, `VD-02`, `VD-05`)**:
   - Fluid properties: `rho = 62.30 lbm/ft3`, `nu = 1.08e-5 ft2/s` at `68 degF`; dosing mass conversion `8.34 lb/gal`.
   - Pipe roughness: Carbon steel `0.00015 ft`, Galvanized steel `0.0005 ft`, Copper `0.000005 ft`, Lay-flat flush hose `0.0008 ft`.
   - Minimum velocity in every leg: `max(3.28, 4.0) = 4.0 ft/s` for PHE/cold-plate circuits (`C2`–`C6`) and `max(3.28, 2.0) = 3.28 ft/s` for other circuits (`C1`, `C7`, `C8`).
   - Required head = static lift (`M-ISO-201..204`) + main single-leg Darcy loss (`M-601`) + un-bypassed component drop (`M-602`) + per-skid 300 ft hose Darcy loss and 40-mesh strainer drop (`11 ft w.c. * (Q_skid/600)^2`, `VD-05`).
   - Pump curve limits (`VD-01`, `VD-02`, `23 25 16 cl. 3.2 f`): `skid_head_avail_ft >= required_head_ft` and `Q_skid <= 700 gpm` (FS-600) or `1,400 gpm` (FS-1200).
3. **Chemical Cleaning & Component Protection (`23 25 16 cl. 3.4`, `UFC 3-230-13 cl. 5-3.7 & 5-7.3.1 & 5-7.3.2.2`, `VD-03`, `VD-04`, `VD-05`, `VD-06`, `M-602`)**:
   - Temporary bypasses installed on all bypass-equipped components (`HX-201A`, `HX-201B`, `CDU-301`, `CP-311`, `CDU-302`, `CP-321`, `CP-331`, `CL-401`) and 40-mesh temporary strainer fitted on skid discharge (`removed at TM-4`).
   - Cleaner selection & volumetric dosing on $V_s$: `CL-100` at `1.5 gal / 1,000 gal V_s` for `C1`–`C5`, `C7`; `CL-210` at `2.0 gal / 1,000 gal V_s` for `C6` (aluminium) and `C8` (galvanized steel).
   - Dispersant dosing on $V_s$: `PD-45` (polyacrylate) at `4 to 5 ppm` active polymer (`UFC 3-230-13 cl. 5-3.7`).
   - Contact circulation time: `>= 24.0 occupied hours` (`UFC 3-230-13 cl. 5-7.3.2.2 b`), completed by `TM-2` (Day 22 / Hour 528).
4. **Rinse Displacement & Cascading (`23 25 16 cl. 3.6`, `UFC 3-230-13 cl. 5-7.3.2.2 e`, `SW-02`, `VD-06`)**:
   - Mixing efficiency $\eta = 0.45$ for circuits with cold-plate manifold bank or coil bank (`C4`, `C5`, `C6`, `C7`); $\eta = 0.62$ for others (`C1`, `C2`, `C3`, `C8`).
   - Acceptance threshold: $C_n = C_{\text{mk}} + (C_0 - C_{\text{mk}}) e^{-\eta n} \le 1.10 \times 615 = 676.5\ \mu\text{S/cm}$; pH within `7.3–7.9` ($7.6 \pm 0.3$) or `7.5–8.5` (intersection `7.5–7.9`).
   - Minimum integer displacements $n_r$:
     - `C1`, `C2`, `C3` ($\eta=0.62, C_0=2600$): $n_r \ge 5.61 \implies \mathbf{6}$ passes ($C_6 = 663.04\ \mu\text{S/cm}$).
     - `C4`, `C5`, `C7` ($\eta=0.45, C_0=2600$): $n_r \ge 7.73 \implies \mathbf{8}$ passes ($C_8 = 669.24\ \mu\text{S/cm}$).
     - `C6` ($\eta=0.45, C_0=2150$): $n_r \ge 7.16 \implies \mathbf{8}$ passes ($C_8 = 656.94\ \mu\text{S/cm}$).
     - `C8` ($\eta=0.62, C_0=2150$): $n_r \ge 5.20 \implies \mathbf{6}$ passes ($C_6 = 652.16\ \mu\text{S/cm}$).
   - Cascade rules: at most 1 cascaded displacement received ($c \in \{0,1\}$), at most 1 donated, donor rinse must finish before receiver rinse starts, and $V_{f,\text{donor}} \ge V_{f,\text{receiver}}$.
5. **Passivation, Hold & Turnover (`23 25 16 cl. 3.5 & 3.8`, `UFC 3-230-13 Tables 5-14, 5-15, 6-1, 6-2, 6-3 & cl. 6-2.2.2–6-2.2.5`, `VD-04`, `VD-06`, `CX-01`)**:
   - `NB-700` (Nitrite-Azole) excluded because `SW-02` `Cl + SO4 = 860 ppm > 800 ppm` (`UFC 3-230-13 cl. 6-2.2.2`).
   - Passivation dosages (`Table 5-14` & `Table 5-15` on $V_s$):
     - `Polysilicate` (`PS-330`): `40–50 ppm as SiO2`, pH `7.5–8.5` (with `TA-90` at `10–20 ppm as TTA`, pH `6.5–7.9`, intersection `7.5–7.9` where copper is wetted).
     - `Molybdate` (`MO-500`): `40–60 ppm as Mo`, pH `7.5–8.5` (with `TA-90` at `10–20 ppm as TTA`, pH `6.5–7.9`, intersection `7.5–7.9` where copper is wetted).
   - Film-formation hold: `14 to 21 days` (`336 to 504 occupied hours`, `Table 5-14`/`5-15`), completed by `TM-3` (Day 44 / Hour 1056).
   - Recirculation before sampling at Passivation and Turnover: `>= 30 minutes` (`0.5 h`, `UFC 3-230-13 cl. 5-7.3.2.2 d`).
   - Turnover maintenance dosages (`cl. 6-2.2.3` & `6-2.2.5` on $V_s$):
     - `Polysilicate-Azole`: `80–100 ppm as SiO2`, pH `7.5–8.9` (`7.5–8.5` on C6 per `VD-04` and C8 per `cl. 5-7.3.1`), `>= 10 ppm TTA` if copper present.
     - `Molybdate-Azole`: `100–125 ppm as Mo`, pH `8.5–9.5`, `>= 10 ppm TTA` if copper present.
   - Since maintenance residuals (`80–100 ppm SiO2` or `100–125 ppm Mo`, and `>= 10 ppm TTA`) are >= passivation residuals (`40–50 ppm SiO2` or `40–60 ppm Mo`, and `10 ppm TTA`), **`RETAIN_AND_TOP_UP` is permitted on all 8 circuits**, saving `V_f` of makeup water, `V_f` of effluent, and avoiding any Molybdate discharge violation (`0.5 mg/L Mo` limit in `SW-03`)!
6. **Discharge, Water, Power & Schedule Caps (`SW-01`, `SI-04`, `SI-05`, `SW-03 RevB`, `SW-04`, `RFI-031`, `CX-01`)**:
   - Chemical cleaning effluent on copper-pipe circuits (`C4`, `C5`, `C6`, `C7` have Cu > 1.0 mg/L) and galvanized circuit (`C8` has Zn = 5.5 mg/L > 1.0 mg/L) **MUST be routed to `HAUL`** (`$168 / 1,000 gal`).
   - Total `SEWER` discharge across all circuits/stages `<= 500,000 gal` (`SW-03 RevB`).
   - Daily water draw `<= 92,000 gal/day` (normal days), `<= 61,000 gal/day` (Days 2 & 3, hours 48–96), `<= 30,000 gal/day` (Day 6, hours 144–168).
   - Simultaneous skid kW at each tie-in location `<= Available kW` (`SW-04` / `E-701`).
   - Simultaneous active crews `<= 2`, simultaneous circuits per skid `<= 1`, `FS-1200-A` start `>= 48.0 h`.
