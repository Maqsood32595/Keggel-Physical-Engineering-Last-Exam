# Pacific Crest Space Force Annex — 13.8 kV Site Distribution Conveyance Study Report
**Solicitation:** FA4610-26-R-0031 | **Project:** PCSFA 24-0117  
**Date:** 2026-09-15 | **Design Phase:** 35% Design Conveyance Study Submittal  

## 1. Executive Summary
This conveyance study evaluates all required conveyance alternatives for seven medium-voltage (13.8 kV) circuits (items C01 through C07) at Pacific Crest Space Force Annex (PCSFA), Los Angeles County, California. The study determines criteria admissibility per PCSFA Installation Electrical Design Standard (PCSFA-IEDS Rev 3), UFC 3-550-01, UFC 3-520-01, and UFGS guide specifications, establishes detailed segment-by-segment designs, and presents full bottom-up cost estimates.

### Summary of Recommended Conveyances
| Item | Circuit / Description | Recommended Conveyance | Conductor Size | Parallel Sets | Route Length (ft) | Design Current (A) | Ampacity / Set (A) |
|---|---|---|---|---|---|---|---|
| C01 | SS-1 to MB-1 Switchgear MSG-A (F1) | CEDB | 500 kcmil Al | 2 | 895 | 640 | 345 |
| C02 | SS-1 to MB-1 Switchgear MSG-B (F2) | CEDB | 500 kcmil Al | 2 | 1,120 | 560 | 345 |
| C03 | SS-1 to CUP-1 Switchgear SWG-C1 (F3) | CEDB | 500 kcmil Al | 1 | 490 | 400 | 420 |
| C04 | CUP-1 to Lift Station LS-2 Pad (CF-2) | CEDB | 250 kcmil Al | 1 | 1,310 | 60 | 310 |
| C05 | MB-1 MSG-A to Unit Sub USS-A1 (A-3) | RMC | 250 kcmil Al | 1 | 410 | 200 | 245 |
| C06 | SS-1 to Gate House GH-1 Pad (F4) | CEDB | 250 kcmil Al | 1 | 1,720 | 40 | 310 |
| C07 | CUP-1 to Warehouse W-3 Pad (CF-1) | CEDB | 250 kcmil Al | 1 | 580 | 120 | 310 |

## 2. Conveyance Alternatives Evaluation & Admissibility
Every conveyance type designated in RFP Section 01 11 00 paragraph 1.4 was evaluated:
- **CEDB (Concrete-Encased Ductbank):** Permitted for all site items per PCSFA-IEDS Rev 3 clause 4.2, UFC 3-550-01 clause 3-11.2.1, and UFGS 33 71 02 clause 3.7.9.
- **UEDB (Conduit without Encasement):** Strictly prohibited for installation primary distribution per PCSFA-IEDS Rev 3 clause 4.2.
- **DBC (Direct-Buried Cable):** Strictly prohibited for installation primary distribution per PCSFA-IEDS Rev 3 clause 4.2.
- **HDD (Horizontal Directional Drilling as Predominant Method):** Prohibited per PCSFA-IEDS Rev 3 clause 4.3 and UFC 3-550-01 clause 3-11.4.1 (bores restricted to specific obstacle crossings and cannot exceed 50 ft beyond pavement/channel).
- **OH (Overhead Distribution):** Prohibited inside the industrial congested area (ADP 2024) and W-3 crane area per PCSFA-IEDS Rev 3 clause 4.1.
- **Item C05 (Interior Building Conveyance):**
  - **RMC:** Permitted per UFC 3-520-01 Table 3-1 and UFGS 26 20 00 clause 3.1.6.7.
  - **EMT:** Prohibited for circuits rated >600 V per UFGS 26 20 00 clause 3.1.6.7.
  - **TRAY-LD:** Prohibited for interior MV cable per UFC 3-520-01 Table 3-1 Article 328 (requires fully enclosed raceway or tray).
  - **TRAY-EN:** Prohibited due to vertical clearance restrictions (requires 18 in headroom, but COR-1D provides only 14 in per A-501) and SCIF 10-ft keep-out per PCSFA-IEDS clause 5.1.

## 3. Findings & Government Document Corrections
Five primary document defects were identified and resolved per the contractual order of precedence (PCSFA-IEDS Rev 3 clause 1.3):
1. **Area Cost Factor (ACF):** Government Estimate Template applied 1.16 location factor to bottom-up direct costs; corrected to 1.0 per UFS 3-701-01 paragraph 4-1.1 and RFP 3.1.
2. **Water Main W-12 Depth:** C-101 indicated 72 in depth; SUE-24-0117 vacuum test holes TH-1 and TH-2 established actual depth of 56 in (16 in shallower). SUE survey governs.
3. **Feeder F1 Pickup:** E-001 showed 560 A; Protective Device Settings Schedule Rev D established 640 A. Settings schedule governs.
4. **Tree T-208 Omission:** C-101 omitted tree T-208; Arborist Survey TS-24-0117 identified 14 in Jacaranda marked for retention at (170, 395). Tree survey governs.
5. **Wage Determination Modification:** RFP referenced Attachment J-3 Mod 2 while Mod 5 was issued on 2026-08-06. Priced using Contracting Officer designated classifications and rates.
