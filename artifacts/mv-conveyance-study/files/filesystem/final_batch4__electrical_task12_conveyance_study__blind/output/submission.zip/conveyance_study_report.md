# 13.8 kV MEDIUM-VOLTAGE CONVEYANCE ENGINEERING STUDY
## PACIFIC CREST SPACE FORCE ANNEX (PCSFA)
### Engineering Basis of Design and Conveyance Lifecycle Evaluation

**Author:** Maqsood32595 <Maqsood32595@users.noreply.github.com>  
**Standards Compliance:** DoD UFC 3-550-01, PCSFA-IEDS Rev 3, IEEE 399, IEEE 141, NFPA 70 (NEC), 29 CFR 1926 Subpart P, 29 CFR 1.6, EP 1110-1-8

---

## 1. Executive Summary & Regulatory Authority

This study establishes the definitive conveyance engineering methodology, physical routing, raceway design, and comprehensive cost estimate for the seven medium-voltage (13.8 kV nominal, 3-phase, 60 Hz) distribution circuits serving critical mission assets at Pacific Crest Space Force Annex.

All labor-hours and prevailing wage rates conform to Davis-Bacon Wage Determination **CA20260022 Modification 5** (published August 6, 2026, incorporating Electrician journeyman hourly base rate $60.80 and fringe benefits $31.59). Equipment ownership and operating expense rates follow USACE EP 1110-1-8 with jobsite fuel index adjustments.

| Labor Classification | Davis-Bacon Group | Base Hourly ($) | Fringe ($) | Burden (%) | Loaded Rate ($/MH) |
|---|---|---|---|---|---|
| ELECTRICIAN | ELEC0011-004 | $60.80 | $31.59 | 16.03% | $101.98 |
| LINEMAN / CABLE SPLICER | ELEC1245-001 | $70.16 | $24.71 | 20.35% | $109.18 |
| EQUIPMENT SPECIALIST | ELEC1245-001 | $53.30 | $22.26 | 20.35% | $86.43 |
| GROUNDMAN | ELEC1245-001 | $40.76 | $21.76 | 20.35% | $70.83 |
| LABORER GROUP 1 | LABO0300-003 | $46.48 | $25.95 | 18.99% | $81.26 |
| LABORER GROUP 3 | LABO0300-003 | $47.58 | $25.95 | 18.99% | $82.57 |
| PREFAB MANHOLE INSTALLER | LABO0300-003 | $49.13 | $25.95 | 18.99% | $84.41 |
| POWER OPERATOR (PUMP) | ENGI0012-024 | $63.40 | $33.20 | 18.99% | $108.65 |
| CABLE SPLICER (INSIDE) | ELEC0011-004 | $63.84 | $31.59 | 16.03% | $105.50 |

---

## Circuit C01 Conveyance Analysis

Circuit C01 detailed evaluation of all conveyance alternatives:

| Alternative Type | Description | Admissible | Governing Clause | Length (ft) | Labor Hours (MH) | Cost per LF ($/LF) | Recommended |
|---|---|---|---|---|---|---|---|
| CEDB | Concrete-encased ductbank (CEDB) | Y | UFC 3-550-01 3-11.2 | 1010.0 | 789.01 | 432.01 | Y |
| UEDB | Unencased ductbank without concrete encasement (UEDB) | N | UFC 3-550-01 3-11.2.1 | 866.2 | 4576.34 | 805.96 | N |
| DBC | Direct-buried cable (DBC) | N | UFC 3-550-01 3-11.3.1 | 866.2 | 4409.21 | 805.96 | N |
| HDD | Horizontal directional bore (HDD) | N | UFC 3-550-01 3-11.4.1 | 866.2 | 109.76 | 826.02 | N |
| OH | Overhead distribution line (OH) | N | UFC 3-550-01 3-11.1.1 | 866.2 | 4430.68 | 805.96 | N |

**Alternative Evaluation Summary & Engineering Justification:**

- Concrete-encased ductbank CEDB: evaluated with labor 789.01 man-hours and unit cost 432.01 $/LF. Compliance status: admissible=Y under UFC 3-550-01 3-11.2. Recommended=Y.
- Without concrete encasement unencased UEDB: evaluated with labor 4576.34 man-hours and unit cost 805.96 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.2.1. Recommended=N.
- Direct-buried DBC: evaluated with labor 4409.21 man-hours and unit cost 805.96 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.3.1. Recommended=N.
- Directional bore HDD: evaluated with labor 109.76 man-hours and unit cost 826.02 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.4.1. Recommended=N.
- Overhead line OH: evaluated with labor 4430.68 man-hours and unit cost 805.96 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.1.1. Recommended=N.

---

## Circuit C02 Conveyance Analysis

Circuit C02 detailed evaluation of all conveyance alternatives:

| Alternative Type | Description | Admissible | Governing Clause | Length (ft) | Labor Hours (MH) | Cost per LF ($/LF) | Recommended |
|---|---|---|---|---|---|---|---|
| CEDB | Concrete-encased ductbank (CEDB) | Y | UFC 3-550-01 3-11.2 | 1230.0 | 927.39 | 366.72 | Y |
| UEDB | Unencased ductbank without concrete encasement (UEDB) | N | UFC 3-550-01 3-11.2.1 | 1107.5 | 4730.89 | 651.65 | N |
| DBC | Direct-buried cable (DBC) | N | UFC 3-550-01 3-11.3.1 | 1107.5 | 4558.11 | 651.65 | N |
| HDD | Horizontal directional bore (HDD) | N | UFC 3-550-01 3-11.4.1 | 1107.5 | 140.33 | 671.71 | N |
| OH | Overhead distribution line (OH) | N | UFC 3-550-01 3-11.1.1 | 1107.5 | 4599.53 | 651.65 | N |

**Alternative Evaluation Summary & Engineering Justification:**

- Concrete-encased ductbank CEDB: evaluated with labor 927.39 man-hours and unit cost 366.72 $/LF. Compliance status: admissible=Y under UFC 3-550-01 3-11.2. Recommended=Y.
- Without concrete encasement unencased UEDB: evaluated with labor 4730.89 man-hours and unit cost 651.65 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.2.1. Recommended=N.
- Direct-buried DBC: evaluated with labor 4558.11 man-hours and unit cost 651.65 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.3.1. Recommended=N.
- Directional bore HDD: evaluated with labor 140.33 man-hours and unit cost 671.71 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.4.1. Recommended=N.
- Overhead line OH: evaluated with labor 4599.53 man-hours and unit cost 651.65 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.1.1. Recommended=N.

---

## Circuit C03 Conveyance Analysis

Circuit C03 detailed evaluation of all conveyance alternatives:

| Alternative Type | Description | Admissible | Governing Clause | Length (ft) | Labor Hours (MH) | Cost per LF ($/LF) | Recommended |
|---|---|---|---|---|---|---|---|
| CEDB | Concrete-encased ductbank (CEDB) | Y | UFC 3-550-01 3-11.2 | 490.0 | 341.21 | 300.68 | Y |
| UEDB | Unencased ductbank without concrete encasement (UEDB) | N | UFC 3-550-01 3-11.2.1 | 364.5 | 1545.25 | 646.72 | N |
| DBC | Direct-buried cable (DBC) | N | UFC 3-550-01 3-11.3.1 | 364.5 | 1488.82 | 646.72 | N |
| HDD | Horizontal directional bore (HDD) | N | UFC 3-550-01 3-11.4.1 | 364.5 | 46.19 | 666.78 | N |
| OH | Overhead distribution line (OH) | N | UFC 3-550-01 3-11.1.1 | 364.5 | 1479.23 | 646.72 | N |

**Alternative Evaluation Summary & Engineering Justification:**

- Concrete-encased ductbank CEDB: evaluated with labor 341.21 man-hours and unit cost 300.68 $/LF. Compliance status: admissible=Y under UFC 3-550-01 3-11.2. Recommended=Y.
- Without concrete encasement unencased UEDB: evaluated with labor 1545.25 man-hours and unit cost 646.72 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.2.1. Recommended=N.
- Direct-buried DBC: evaluated with labor 1488.82 man-hours and unit cost 646.72 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.3.1. Recommended=N.
- Directional bore HDD: evaluated with labor 46.19 man-hours and unit cost 666.78 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.4.1. Recommended=N.
- Overhead line OH: evaluated with labor 1479.23 man-hours and unit cost 646.72 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.1.1. Recommended=N.

---

## Circuit C04 Conveyance Analysis

Circuit C04 detailed evaluation of all conveyance alternatives:

| Alternative Type | Description | Admissible | Governing Clause | Length (ft) | Labor Hours (MH) | Cost per LF ($/LF) | Recommended |
|---|---|---|---|---|---|---|---|
| CEDB | Concrete-encased ductbank (CEDB) | Y | UFC 3-550-01 3-11.2 | 1315.0 | 706.42 | 314.08 | Y |
| UEDB | Unencased ductbank without concrete encasement (UEDB) | N | UFC 3-550-01 3-11.2.1 | 1226.8 | 4331.77 | 538.65 | N |
| DBC | Direct-buried cable (DBC) | N | UFC 3-550-01 3-11.3.1 | 1226.8 | 4173.58 | 538.65 | N |
| HDD | Horizontal directional bore (HDD) | N | UFC 3-550-01 3-11.4.1 | 1226.8 | 155.46 | 558.71 | N |
| OH | Overhead distribution line (OH) | N | UFC 3-550-01 3-11.1.1 | 1226.8 | 4219.29 | 538.65 | N |

**Alternative Evaluation Summary & Engineering Justification:**

- Concrete-encased ductbank CEDB: evaluated with labor 706.42 man-hours and unit cost 314.08 $/LF. Compliance status: admissible=Y under UFC 3-550-01 3-11.2. Recommended=Y.
- Without concrete encasement unencased UEDB: evaluated with labor 4331.77 man-hours and unit cost 538.65 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.2.1. Recommended=N.
- Direct-buried DBC: evaluated with labor 4173.58 man-hours and unit cost 538.65 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.3.1. Recommended=N.
- Directional bore HDD: evaluated with labor 155.46 man-hours and unit cost 558.71 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.4.1. Recommended=N.
- Overhead line OH: evaluated with labor 4219.29 man-hours and unit cost 538.65 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.1.1. Recommended=N.

---

## Circuit C05 Conveyance Analysis

Circuit C05 detailed evaluation of all conveyance alternatives:

| Alternative Type | Description | Admissible | Governing Clause | Length (ft) | Labor Hours (MH) | Cost per LF ($/LF) | Recommended |
|---|---|---|---|---|---|---|---|
| RMC | Rigid metal conduit raceway (RMC) | Y | IEDS Rev 3 Table 3-1 | 366.7 | 514.81 | 552.84 | Y |
| EMT | Electrical metallic tubing raceway (EMT) | N | IEDS Rev 3 Table 3-1 | 338.9 | 2126.16 | 957.10 | N |
| TRAY-EN | Enclosed solid-bottom cable tray (TRAY-EN) | N | IEDS Rev 3 Table 3-1 | 338.9 | 2126.16 | 957.10 | N |
| TRAY-LD | Ladder cable tray (TRAY-LD) | N | IEDS Rev 3 Table 3-1 | 338.9 | 2126.16 | 957.10 | N |

**Alternative Evaluation Summary & Engineering Justification:**

- Rigid metal conduit RMC: evaluated with labor 514.81 man-hours and unit cost 552.84 $/LF. Compliance status: admissible=Y under IEDS Rev 3 Table 3-1. Recommended=Y.
- Electrical metallic tubing EMT: evaluated with labor 2126.16 man-hours and unit cost 957.10 $/LF. Compliance status: admissible=N under IEDS Rev 3 Table 3-1. Recommended=N.
- Enclosed cable tray TRAY-EN: evaluated with labor 2126.16 man-hours and unit cost 957.10 $/LF. Compliance status: admissible=N under IEDS Rev 3 Table 3-1. Recommended=N.
- Ladder cable tray TRAY-LD: evaluated with labor 2126.16 man-hours and unit cost 957.10 $/LF. Compliance status: admissible=N under IEDS Rev 3 Table 3-1. Recommended=N.

---

## Circuit C06 Conveyance Analysis

Circuit C06 detailed evaluation of all conveyance alternatives:

| Alternative Type | Description | Admissible | Governing Clause | Length (ft) | Labor Hours (MH) | Cost per LF ($/LF) | Recommended |
|---|---|---|---|---|---|---|---|
| CEDB | Concrete-encased ductbank (CEDB) | Y | UFC 3-550-01 3-11.2 | 1740.2 | 1881.74 | 161.09 | N |
| UEDB | Unencased ductbank without concrete encasement (UEDB) | N | UFC 3-550-01 3-11.2.1 | 1740.2 | 2177.90 | 190.92 | N |
| DBC | Direct-buried cable (DBC) | N | UFC 3-550-01 3-11.3.1 | 1740.2 | 2098.37 | 190.92 | N |
| HDD | Horizontal directional bore (HDD) | N | UFC 3-550-01 3-11.4.1 | 1740.2 | 220.51 | 210.98 | N |
| OH | Overhead distribution line (OH) | Y | UFC 3-550-01 3-10 | 1924.6 | 447.77 | 107.89 | Y |

**Alternative Evaluation Summary & Engineering Justification:**

- Concrete-encased ductbank CEDB: evaluated with labor 1881.74 man-hours and unit cost 161.09 $/LF. Compliance status: admissible=Y under UFC 3-550-01 3-11.2. Recommended=N.
- Without concrete encasement unencased UEDB: evaluated with labor 2177.90 man-hours and unit cost 190.92 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.2.1. Recommended=N.
- Direct-buried DBC: evaluated with labor 2098.37 man-hours and unit cost 190.92 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.3.1. Recommended=N.
- Directional bore HDD: evaluated with labor 220.51 man-hours and unit cost 210.98 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.4.1. Recommended=N.
- Overhead line OH: evaluated with labor 447.77 man-hours and unit cost 107.89 $/LF. Compliance status: admissible=Y under UFC 3-550-01 3-10. Recommended=Y.

---

## Circuit C07 Conveyance Analysis

Circuit C07 detailed evaluation of all conveyance alternatives:

| Alternative Type | Description | Admissible | Governing Clause | Length (ft) | Labor Hours (MH) | Cost per LF ($/LF) | Recommended |
|---|---|---|---|---|---|---|---|
| CEDB | Concrete-encased ductbank (CEDB) | Y | UFC 3-550-01 3-11.2 | 680.0 | 391.63 | 476.48 | Y |
| UEDB | Unencased ductbank without concrete encasement (UEDB) | N | UFC 3-550-01 3-11.2.1 | 601.3 | 3398.26 | 862.14 | N |
| DBC | Direct-buried cable (DBC) | N | UFC 3-550-01 3-11.3.1 | 601.3 | 3274.16 | 862.14 | N |
| HDD | Horizontal directional bore (HDD) | N | UFC 3-550-01 3-11.4.1 | 601.3 | 76.20 | 882.21 | N |
| OH | Overhead distribution line (OH) | N | UFC 3-550-01 3-11.1.1 | 601.3 | 3272.20 | 862.14 | N |

**Alternative Evaluation Summary & Engineering Justification:**

- Concrete-encased ductbank CEDB: evaluated with labor 391.63 man-hours and unit cost 476.48 $/LF. Compliance status: admissible=Y under UFC 3-550-01 3-11.2. Recommended=Y.
- Without concrete encasement unencased UEDB: evaluated with labor 3398.26 man-hours and unit cost 862.14 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.2.1. Recommended=N.
- Direct-buried DBC: evaluated with labor 3274.16 man-hours and unit cost 862.14 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.3.1. Recommended=N.
- Directional bore HDD: evaluated with labor 76.20 man-hours and unit cost 882.21 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.4.1. Recommended=N.
- Overhead line OH: evaluated with labor 3272.20 man-hours and unit cost 862.14 $/LF. Compliance status: admissible=N under UFC 3-550-01 3-11.1.1. Recommended=N.

---
