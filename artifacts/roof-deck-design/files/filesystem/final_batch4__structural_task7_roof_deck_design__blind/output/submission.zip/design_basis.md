# Design Basis Narrative — Roof Deck Design
**Project:** DC2-2026-014 — DC-2 Helena Data Centre, Building A  
**Location:** Lewis and Clark County, Montana (4,880 ft MSL)  
**Structural Engineer of Record:** Sandalwood Marlow Structural Engineers, PLLC  

## 1. Document Precedence & Hierarchy of Authority
All conflicts among project documents are resolved in accordance with Transmittal T-118 and standard engineering authority precedence:
1. **3D Coordinated Model:** DC2-A-STR Roof Structure Model Rev C (IFC4) is the geometry of record for the roof, governing all plan dimensions, framing, openings, and rooftop obstruction positions.
2. **Screen Wall SCR-N Relocation:** Model Rev C and A-201 Rev C relocate equipment screen wall SCR-N to y = 164.0 ft. A-201 Rev B is superseded and withdrawn.
3. **Criteria Reissue:** EOR-DC-RD-01 Rev 2 reissued the structural criteria in full and superseded Rev 1 in its entirety. The deck is designed for unreduced roof live load Lr = 20 psf (Clause 4.2), effective seismic weight includes 20% flat roof snow load (Clause 7.2), and minimum boundary/opening fastening is 36/7 with 3 sidelap screws per span (Clause 10.4).
4. **Site Snow Study:** Ground snow load pg = 63 psf is established by CRREL case study SNOW-2026-014 Rev 0 (accepted by AHJ on 2026-04-28).
5. **Procurement Lead Time:** Per Owner's Basis of Design OBD-DC2-A Section 5, deck material must be on site within 9 weeks. Nordeck Deck Stock Availability establishes 16 gage lead time as 14 weeks (mill order), strictly disqualifying 16 gage. Available gages are 22, 20, and 18 gage.

## 2. Snow Loading, Balanced Loads & Drift Surcharges
- Flat roof snow load: pf = 0.7 * Ce * Ct * Is * pg = 0.7 * 0.90 * 1.0 * 1.10 * 63 = 43.66 psf.
- Snow density: gamma = 0.13 * pg + 14 = 22.19 pcf. Balanced snow depth hb = pf / gamma = 1.968 ft.
- Obstructions standing higher than hc = 2.0 ft above balanced snow form drifts on all four faces per Clause 5.4 and 5.5:
  - MEP-PH-1 West Face: Leeward drift from East wind governs with peak surcharge = 104.28 psf, width = 18.80 ft, band from x = 60.0 ft to x = 41.20 ft.
  - SCR-N South Face: Windward drift from South wind governs with peak surcharge = 89.48 psf (truncated), width = 16.15 ft, band from y = 164.0 ft to y = 147.85 ft.
  - Parapet North Face: Windward parapet drift with peak surcharge = 34.01 psf (truncated), width = 12.26 ft, band from y = 179.33 ft to y = 167.07 ft.
  - RTU-1 East Face: Windward drift from East wind governs with peak surcharge = 98.18 psf, width = 17.70 ft, band from x = 36.0 ft to x = 53.70 ft.

## 3. Seismic & Wind Lateral Bases
- Seismic Parameters: SDS = 0.44, SD1 = 0.24, Site Class D, SDC D, Ie = 1.25, R = 3.25, Omega_0 = 2.0, rho = 1.0.
- Effective Seismic Weight: Base dead weight (18.0 psf) + 20% flat roof snow load (0.20 * 43.66 = 8.732 psf) = 26.732 psf. Total W = 1,154.8 kip.
- Base shear / Diaphragm Force: Cs = SDS * Ie / R = 0.1692. Fpx = Cs * W = 195.4 kip.
- Wind Forces: Wind X = 118.0 kip, Wind Y = 152.0 kip (strength design level).

## 4. Diaphragm Analysis & Classification
- Analyzed as an in-plane horizontal assembly: shear panels (deck G'), axial members (joists, girders, edge angles), and discrete springs at braced frame column lines.
- Total lateral frame stiffness: Kx = 146.0 kip/in, Ky = 180.0 kip/in.
- Average frame drift: Delta_frame_x = 1.34 in under seismic. 2.0 * Delta_frame = 2.68 in.
- In-plane diaphragm deflection is limited to 1.60 in per Clause 9.2, which is less than 2.0 * Delta_frame.
- Per Criteria Clause 9.3, the diaphragm is classified as **SEMI-RIGID**.
- Chord capacity is governed by the bolted splice in the L5x3-1/2x5/16 edge angle at 38.0 kip.
- Collector capacity is governed by the bolted splice in the W12x26 at 58.0 kip, checked against collector force amplified by Omega_0 = 2.0.

## 5. Zoning Rationale & Constructability Compliance
- Constructability Rules (Clause 10.2): Max 2 gages, max 3 patterns, max 12 zones, max 14 rectangles. Zone boundaries on 6 ft modules.
- Selected Gages: 20 gage (typical areas, allowable load 130 psf) and 18 gage (heavy drift zones west of MEP-PH-1, allowable load 177 psf).
- Attachment Pattern: 36/7 support pattern with SCREW-10 sidelap screws at 3 per span (satisfies Clause 10.4 minimum everywhere).
- Framed openings RO-1, RO-2, and RO-3 are completely voided on the 6x6 ft checking grid (no deck placed over openings per Clause 10.5 and 29 CFR 1926.754(e)(3)).
