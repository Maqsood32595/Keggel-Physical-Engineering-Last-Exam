# Foundation Feasibility & Optimization Matrix — Phase 1 Pads

| Pad ID | Subsurface Conditions | Foundation Type | Bearing Depth (ft) | Settlement (in) | Cost ($) | Feasibility Determination |
| :--- | :--- | :--- | :---: | :---: | :---: | :--- |
| **CR-P1** | Stratum I / II soft clay | IMPROVED_SPREAD | 4.0 | 0.89 | $71,393 | Rammed aggregate piers required to satisfy 1.0 in settlement limit. |
| **CR-P2** | Upper compressible silt | IMPROVED_SPREAD | 4.0 | 0.94 | $75,815 | Ground improvement selected over undercut; 2-rig sequence. |
| **CR-P3** | Dense granular stratum | SPREAD | 4.0 | 0.81 | $27,223 | Competent bearing at 4.0 ft; conventional spread footings feasible. |
| **CR-P4** | Variable fill / alluvial | IMPROVED_SPREAD | 4.0 | 0.88 | $38,335 | Aggregate piers control angular distortion below 1/500. |
| **CR-P5** | Shallow bedrock / dense | SPREAD | 3.5 | 0.76 | $14,171 | High presumptive bearing; conventional shallow footings optimal. |
| **CR-P6** | Deeper compressible zone | IMPROVED_SPREAD | 3.75 | 0.91 | $74,213 | Improved spread footings provide cost-optimal performance. |

Each pad (CR-P1, CR-P2, CR-P3, CR-P4, CR-P5, and CR-P6) has been analyzed for technical feasibility, structural safety, constructability, and minimum total cost.
