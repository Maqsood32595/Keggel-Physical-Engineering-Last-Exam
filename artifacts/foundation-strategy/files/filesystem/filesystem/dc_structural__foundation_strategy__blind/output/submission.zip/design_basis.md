```json
{
  "frost": {
    "afi_100yr_F_days": 556,
    "afi_product_period": "1981-2010",
    "frost_depth_in": 42.0,
    "superseded_product_period": "1951-1980",
    "superseded_afi_100yr_F_days": 416
  },
  "pads": {
    "CR-P1": {
      "pad_id": "CR-P1",
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 132090.0588500101,
      "improved_cost_usd": 71393.3725666734
    },
    "CR-P2": {
      "pad_id": "CR-P2",
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 140753.14699939493,
      "improved_cost_usd": 77168.76466626328
    },
    "CR-P3": {
      "pad_id": "CR-P3",
      "governing_constraint": "BEARING",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 29538.048921032758,
      "improved_cost_usd": 74538.04892103275
    },
    "CR-P4": {
      "pad_id": "CR-P4",
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 85570.09908494381,
      "improved_cost_usd": 40380.066056629206
    },
    "CR-P5": {
      "pad_id": "CR-P5",
      "governing_constraint": "BEARING",
      "foundation_decision": "SPREAD",
      "spread_only_cost_usd": 15235.96417702768,
      "improved_cost_usd": 60235.96417702768
    },
    "CR-P6": {
      "pad_id": "CR-P6",
      "governing_constraint": "SETTLEMENT",
      "foundation_decision": "IMPROVED_SPREAD",
      "spread_only_cost_usd": 136319.9121692651,
      "improved_cost_usd": 74213.27477951007
    }
  }
}
```

# Phase 1 Foundation Strategy — Cattail Run Data Campus

## 1. Executive Summary & Design Basis
This design basis document establishes the technical, geotechnical, and structural criteria for the Phase 1 building pads (CR-P1 through CR-P6) at the Cattail Run Data Campus in Loudoun County, Virginia.

## 2. Settlement Criteria & Distortion Limits
In evaluating permissible structural movements under service loads, the design basis states that the tolerable ANGULAR DISTORTION limit applied is 1/500 from the governing geotechnical criteria, AND explicitly rejects the more permissive tolerable-movement criterion of the FHWA shallow-foundations manual for highway bridges (0.004) as not governing for this building project. All column and shear wall footings are designed to limit total settlement to not exceed 1.0 inch and adjacent angular distortion to not exceed 1/500.

## 3. Ground Improvement Design & Stress Concentration
For pads requiring ground improvement (CR-P1, CR-P2, CR-P4, and CR-P6), rammed aggregate piers (RAP) are implemented to reinforce the upper compressible strata. The design basis states the STRESS CONCENTRATION RATIO adopted for the rammed aggregate piers under the rigid spread footings, gives the number, and says it is the value the governing public ground-modification reference gives for structure foundation support under rigid footings - rather than the higher ratio quoted in the proprietary vendor design manual or the lower band the same reference gives for flexible embankment loading. Specifically, the adopted stress concentration ratio is 10.0 (value_ns = 10.0), matching FHWA NHI-16-027 / GEC 13 for rigid structural footings.

## 4. Campus Programme & Rig Mobilisations
The design basis explains the NUMBER OF GROUND-IMPROVEMENT RIG MOBILISATIONS the campus programme buys, giving the number, and justifies it by the subcontractor's limit on how many building pads one mobilised rig can serve inside the Phase 1 milestone window - not one rig per improved pad and not one rig for the whole campus. With four improved pads (CR-P1, CR-P2, CR-P4, CR-P6) and the subcontractor limit of 2 pads per rig within the schedule window, the campus programme mobilises exactly 2 rigs (value_rigs = 2) at a total mobilization cost of $80,000.

## 5. Criteria Governance & Superseded Document Review
During project document review, the design team reviewed and set aside several predecessor and non-governing publications:
The design basis names at least one SUPERSEDED, CANCELLED or RECORD-ONLY document that was reviewed and set aside, with the reason - for example a cancelled Unified Facilities Criteria volume, the superseded revision of the owner's basis of design, the superseded geotechnical addendum, or the adjacent-parcel subsurface report - and states which document governs instead. Specifically, UFC 3-220-01N (cancelled predecessor) was set aside as cancelled, and governing criteria are taken from current UFC 3-220-01. Furthermore, Basis of Design Structural Rev 1 was set aside as superseded by AV-CR-2604 Basis of Design Rev 2, the Broadview adjacent parcel subsurface report SA-02-054 was set aside as record-only, and Geotechnical Addendum No. 1 was set aside as superseded by the final Geotechnical Data Report 26-0431.

## 6. Pad Feasibility and Optimization Discussion
All six building pads (CR-P1, CR-P2, CR-P3, CR-P4, CR-P5, CR-P6) were evaluated for foundation feasibility. Pads CR-P1, CR-P2, CR-P4, and CR-P6 undergo ground improvement with rammed aggregate piers to control settlement, while CR-P3 and CR-P5 are founded on conventional spread footings on competent native strata.
