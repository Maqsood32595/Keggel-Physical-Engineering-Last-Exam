# DESIGN BASIS REPORT: EOR REVIEW RESOLUTION AND RE-ISSUE PLAN
**Project:** Central Utility Plant and Data Hall Infrastructure (Work Order 74213)  
**Location:** Naval Support Activity Ventura Bay  
**Author:** Maqsood32595 (Professional Engineer of Record)

---

## 1. Executive Summary and Governing Standards

This Design Basis Report documents the comprehensive resolution of Engineer of Record (EOR) backcheck review comments, package reconstitution, revision block accounting, and deliverable bundling for Bid Packages BP-2 (Central Utility Plant) and BP-3 (Data Hall 210).

All engineering actions, drafting modifications, and deliverable packages strictly conform to the governing criteria:
- **A/E/C CAD Standard R6.2** (ERDC/ITL TR-24-3)
- **A/E/C Graphics Standard R2.2** (ERDC/ITL SR-23-1)
- **FC 1-300-09N (2024)** with Change 1 (*Navy and Marine Corps Design Procedures*)

The following criteria documents were audited and confirmed to be non-governing, superseded, cancelled, or inapplicable to this project:
- **A/E/C CAD Standard R6.0** (superseded by Release 6.2)
- **UFC 1-300-09N (2005)** (cancelled and replaced by FC 1-300-09N 2024)
- **GSA PBS CAD Standards** (owner legacy standards not applicable to Navy defense infrastructure)

---

## 2. Program Specification Block

```json
{
  "governing_standards": [
    "A/E/C CAD Standard R6.2",
    "A/E/C Graphics Standard R2.2",
    "FC 1-300-09N (2024)"
  ],
  "rejected_standards": [
    "A/E/C CAD Standard R6.0",
    "UFC 1-300-09N (2005)",
    "GSA PBS CAD Standards"
  ],
  "rate_parameters": {
    "production_start": "2026-08-31",
    "sheets_per_day": 4.0,
    "days_per_bundle": 3.0
  },
  "void_markups": [
    {"comment_id": "EOR-2-015", "reason": "Reviewer M. Delacroix is an Electrical engineer and is not registered in the mechanical field of sheet M-301 per FAR 52.236-25."},
    {"comment_id": "EOR-2-017", "reason": "Reviewer G. Halvorsen is an unknown reviewer and is not listed on the project review roster."},
    {"comment_id": "EOR-2-019", "reason": "The markup on sheet S-501 is undated and contains no timestamp."},
    {"comment_id": "EOR-2-021", "reason": "The markup was placed on a superseded 60% review print of sheet S-102 and is obsolete."},
    {"comment_id": "EOR-2-027", "reason": "The issue on sheet M-502 was closed in a prior 60% elevation review."},
    {"comment_id": "EOR-2-033", "reason": "Reviewer J. Vandermeer is a Structural engineer and is not registered in the electrical discipline of sheet E-101 per FAR 52.236-25."},
    {"comment_id": "EOR-3-012", "reason": "The markup was placed on a superseded 90% review print of sheet A-102 and is obsolete."},
    {"comment_id": "EOR-3-016", "reason": "Reviewer D. Fenwick is a Mechanical engineer and is not registered in the architectural discipline of sheet A-501 per FAR 52.236-25."},
    {"comment_id": "EOR-3-018", "reason": "Reviewer P. Okonjo is a Civil engineer and is not registered in the architectural discipline of sheet A-502 per FAR 52.236-25."},
    {"comment_id": "EOR-3-020", "reason": "The markup on sheet S-501 contains no date or timestamp."},
    {"comment_id": "EOR-3-022", "reason": "Reviewer C. Ballantyne is not listed on the authorized project review roster."},
    {"comment_id": "EOR-3-036", "reason": "This review comment on sheet A-301 was closed with elevation during prior design review."}
  ],
  "packages": {
    "BP-2": {
      "issue_state": "AMENDMENT",
      "change_number": "0003",
      "overflow_option": 2,
      "revision_layers": [
        "G-ANNO-REVC",
        "G-ANNO-REVS"
      ],
      "n_bundles": 3,
      "production_days": 14,
      "delay_days": 1,
      "backcheck_window_days": 15,
      "title_block_defects": [
        {"sheet": "E-501", "defect": "SEAL_DISCIPLINE_MISMATCH"},
        {"sheet": "S-301", "defect": "CHK_EQUALS_DRW"}
      ],
      "ledger": {
        "bundles_usd": 14400.0,
        "sheets_usd": 19719.67,
        "added_sheets_usd": 12800.0,
        "revision_marks_usd": 3840.0,
        "overflow_option_usd": 1760.0,
        "non_concurrence_usd": 2400.0,
        "delay_usd": 2740.0,
        "total_usd": 57659.67
      }
    },
    "BP-3": {
      "issue_state": "PRE_ADVERTISEMENT_REISSUE",
      "change_number": "",
      "overflow_option": 1,
      "revision_layers": [
        "G-ANNO-REVC",
        "G-ANNO-REVS"
      ],
      "n_bundles": 2,
      "production_days": 12,
      "delay_days": 0,
      "backcheck_window_days": 30,
      "title_block_defects": [
        {"sheet": "A-501", "defect": "CHK_EQUALS_DES"},
        {"sheet": "M-101", "defect": "SEAL_DISCIPLINE_MISMATCH"}
      ],
      "ledger": {
        "bundles_usd": 9600.0,
        "sheets_usd": 21253.2,
        "added_sheets_usd": 12800.0,
        "revision_marks_usd": 0.0,
        "overflow_option_usd": 0.0,
        "non_concurrence_usd": 2400.0,
        "delay_usd": 0.0,
        "total_usd": 46053.2
      }
    }
  }
}
```

---

## 3. Engineering Decisions and Technical Narrative

### 3.1 Revision-Graphics and Layer Conflict Resolution (J1)
In evaluating the layer assignments for revision graphics, a conflict arises between two candidate standard layer assignments: the standard general annotation layer pair (`G-ANNO-REVC` and `G-ANNO-REVS`) from A/E/C CAD Standard R6.2 Appendix A and the record drawing layer pair (`Z-ANNO-REVC` and `Z-ANNO-REVS`) in FC 1-300-09N clause 12-3.6.1.

This hierarchy is definitively governed by **FC 1-300-09N clause 12-3.3.4**, which establishes the mandatory order of precedence for CAD standards across Navy and Marine Corps facilities design. Under clause 12-3.3.4, the requirements of Chapter 12 take precedence over external standards, but clause 12-3.6.1 explicitly governs only the preparation of final As-Built / RECORD drawings following construction completion. The record-drawing layers (the Z-ANNO- pair) apply to RECORD drawings only and therefore do NOT apply to this issue. Because the current package represents a design revision prior to construction rather than record drawings, the record drawing layers are inapplicable. Consequently, the revision graphics are assigned to standard design layers: revision clouds are placed on layer `G-ANNO-REVC` and revision indicators are placed on layer `G-ANNO-REVS`.

### 3.2 Issue-State Determination for Bid Package BP-3 (J2)
The issue state of bid package BP-3 is determined as a `PRE_ADVERTISEMENT_REISSUE` based on contract milestones and review scheduling regulations.

According to the official project solicitation schedule, Bid Package BP-3 (Solicitation N40085-26-R-3018) is in status PENDING ADVERTISEMENT, with a scheduled advertisement date of 2026-10-12 and a bid opening date of 2026-11-12. In accordance with ER 415-1-11 clause 6.e and BCOES review guidelines, when comments are identified prior to advertisement, the backcheck review starts 30 calendar days prior to advertising and all review comments must be fully resolved and incorporated before the solicitation is advertised to prospective bidders.

Applying the mandatory 30 calendar days backcheck window prior to scheduled advertisement yields a required completion deadline of 2026-09-12 (2026-10-12 minus 30 calendar days). Production commenced on 2026-08-31. With 17 sheets in the plan and 2 deliverable bundles, production requires 12 calendar days, finishing on 2026-09-12. Because production completes on or before the 30-day pre-advertisement deadline, there are zero delay days. Therefore, rather than issuing an Amendment after advertisement under the 15-day post-advertisement window, BP-3 is issued as a complete `PRE_ADVERTISEMENT_REISSUE` prior to solicitation advertisement.

### 3.3 Revision (Issue) Block Overflow Decision for Bid Package BP-2 (J3)
Under A/E/C Graphics Standard R2.2 clause 7.3, the standard border Revision (Issue) block holds eight rows for recording drawing changes. For Bid Package BP-2, multiple heavily revised sheets (including C-101, M-101, M-501, S-101, S-102, and S-502) have already accumulated 8 historical revision entries, causing the revision block to overflow upon adding Revision Mark 3.

A/E/C Graphics Standard R2.2 clause 7.3 specifies two options for handling revision block overflow:
- **Option 1**: Replace the oldest revision entry in the block, resetting the top row and requiring re-indexing across all revised sheets.
- **Option 2**: Spill the new revision entry into a ninth row directly above the existing eight-row block.

The graphics standard mandates that whichever option is selected must be applied consistently across the entire drawing set rather than on an ad-hoc, sheet-by-sheet basis. For Bid Package BP-2, Option 2 was selected for the entire drawing package. In cost terms, Option 1 was rejected because Option 1 imposes a fixed drafting re-indexing fee of $520 across every full sheet ($3,120), whereas Option 2 applies an overflow fee of $880 only to dense overflow sheets ($1,760 total), achieving an immediate net savings of $1,360 while fully preserving historical revision records. Thus, Option 2 was adopted across BP-2.

---

## 4. Title Block Verification and Checker Independence
In compliance with FC 1-300-09N clause 12-4.1, all sheet title blocks were audited for proper discipline seals and checker independence:
1. **Checker Independence Defect (`CHK_EQUALS_DRW` / `CHK_EQUALS_DES`):** Sheet S-301 in BP-2 contains identical initials for the designer/draftsperson and checker (`CHK_EQUALS_DRW`). In BP-3, sheet A-501 contains identical initials for designer and checker (`CHK_EQUALS_DES`). Both represent violations of clause 12-4.1 and have been flagged for correction.
2. **Seal Discipline Mismatch (`SEAL_DISCIPLINE_MISMATCH`):** Sheet E-501 in BP-2 carries a mechanical seal on an electrical single-line diagram. In BP-3, sheet M-101 carries an architectural seal on a mechanical piping drawing. Both defects have been documented and flagged for re-sealing by registered discipline engineers.

---

## 5. Summary of Delivery Bundles and Economic Ledger
All drawing files were packaged to respect the 50 MB / 50-sheet file limits and preserve discipline integrity:
- **BP-2**: 3 bundles, 16 sheets total ($57,659.67, with 1 day schedule delay).
- **BP-3**: 2 bundles, 17 sheets total ($46,053.20, with 0 days schedule delay).
