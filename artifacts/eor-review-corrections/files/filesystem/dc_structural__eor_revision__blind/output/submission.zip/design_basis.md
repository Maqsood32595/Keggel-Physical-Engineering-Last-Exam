# Design Basis - Work Order 74213 EOR Review Corrections

```json
{
  "packages": {
    "BP-2": {
      "issue_state": "AMENDMENT",
      "change_number": "0003",
      "overflow_option": 1,
      "revision_layers": [
        "Z-ANNO-REVC",
        "Z-ANNO-REVS"
      ],
      "n_bundles": 3,
      "production_days": 14,
      "delay_days": 0,
      "backcheck_window_days": 15,
      "ledger": {
        "bundles_usd": 14400,
        "sheets_usd": 26529.33,
        "added_sheets_usd": 12800,
        "revision_marks_usd": 4560,
        "overflow_option_usd": 2600,
        "non_concurrence_usd": 0,
        "delay_usd": 0,
        "total_usd": 60889.33
      },
      "title_block_defects": [
        {"sheet": "C-102", "defect": "CHK_EQUALS_DES"},
        {"sheet": "E-501", "defect": "SEAL_DISCIPLINE_MISMATCH"},
        {"sheet": "S-301", "defect": "CHK_EQUALS_DRW"}
      ]
    },
    "BP-3": {
      "issue_state": "PRE_ADVERTISEMENT_REISSUE",
      "change_number": "",
      "overflow_option": "NONE",
      "revision_layers": [
        "Z-ANNO-REVC",
        "Z-ANNO-REVS"
      ],
      "n_bundles": 3,
      "production_days": 14,
      "delay_days": 0,
      "backcheck_window_days": 30,
      "ledger": {
        "bundles_usd": 14400,
        "sheets_usd": 26789.78,
        "added_sheets_usd": 12800,
        "revision_marks_usd": 0,
        "overflow_option_usd": 0,
        "non_concurrence_usd": 0,
        "delay_usd": 0,
        "total_usd": 53989.78
      },
      "title_block_defects": [
        {"sheet": "A-501", "defect": "CHK_EQUALS_DES"},
        {"sheet": "M-101", "defect": "SEAL_DISCIPLINE_MISMATCH"},
        {"sheet": "T-101", "defect": "CHK_EQUALS_DRW"}
      ]
    }
  },
  "governing_standards": [
    "Facilities Criteria FC 1-300-09N, Navy and Marine Corps Design Procedures, Change 1 (17 April 2025)",
    "ERDC/ITL SR-24-3, A/E/C Computer-Aided Design (CAD) Standard Release 6.2 (July 2024)",
    "ERDC/ITL SR-23-1, A/E/C Graphics Standard Release 2.2 (August 2023)",
    "ER 1165-2-217, Civil Works Review Policy (1 May 2021) [Adopted for design-review process]",
    "ERDC/ITL SR-21-6, Record Package Guidance Best Practices (August 2021) [Adopted for markup conventions]",
    "ER 415-1-11, Biddability, Constructability, Operability, Environmental and Sustainability (BCOES) Reviews (1 January 2013)"
  ],
  "rejected_standards": [
    "ERDC/ITL TR-12-6, A/E/C CAD Standard Release 6.0 (August 2015) - Superseded by A/E/C CAD Standard Release 6.2 (ERDC/ITL SR-24-3)",
    "UFC 1-300-09N, Design Procedures (Change 7, 27 January 2010) - Formally cancelled and superseded by FC 1-300-09N",
    "GSA Public Buildings Service CAD Standards (March 10, 2021) - Civilian agency standard inapplicable to DoD and NAVFAC defense facilities",
    "ER 1110-1-8159, Design Review and Checking System (DrChecks) (1 January 2015) - Internal USACE administrative regulation not adopted for this work order"
  ],
  "rate_parameters": {
    "production_start": "2026-08-31",
    "sheets_per_day": 4,
    "days_per_bundle": 3
  },
  "void_markups": [
    {"comment_id": "EOR-2-017", "reason": "Author G. Halvorsen is not on the authorized reviewer roster and lacks professional registration under FAR 52.236-25."},
    {"comment_id": "EOR-2-021", "reason": "Markup was placed on superseded 90% submittal drawing 74213_BP-2_S-102_90pct_SUPERSEDED.pdf rather than the active bid drawing."},
    {"comment_id": "EOR-2-033", "reason": "Comment was previously closed in the 60% review phase without being reopened for the final design review."},
    {"comment_id": "EOR-3-012", "reason": "Markup was placed on superseded 60% submittal drawing 74213_BP-3_T-501_60pct_SUPERSEDED.pdf rather than the active final design sheet."},
    {"comment_id": "EOR-3-022", "reason": "Author C. Ballantyne is not on the authorized reviewer roster and lacks professional registration under FAR 52.236-25."},
    {"comment_id": "EOR-3-036", "reason": "Comment was previously closed in the 60% review phase without being reopened for the final design review."}
  ]
}
```

---

## Technical & Legal Narrative

### (a) Revision-Graphics Layer Conflict Resolution
An apparent discrepancy arises between A/E/C CAD Standard Release 6.2 (ERDC/ITL SR-24-3, Appendix A) and Facilities Criteria FC 1-300-09N (Change 1). While the former assigns revision linework to general layers G-ANNO-REVC and G-ANNO-REVS, FC 1-300-09N section 12-3.6.1 explicitly requires drafting personnel to isolate perimeter modification clouds onto layer Z-ANNO-REVC and place all delta indicators, callouts, and revision block text upon layer Z-ANNO-REVS.

This drafting divergence is legally governed by FC 1-300-09N paragraph 12-3.3.4, CAD Standards, which establishes an explicit order of precedence: requirements located in Chapter 12 supersede the DoD A/E/C CAD and Graphics Standards, which themselves govern ahead of the National CAD Standard. Furthermore, paragraph 7 of the Contracting Officer Memorandum restricts the application of ERDC/ITL SR-21-6 to reviewer markup mechanics and color usage, disclaiming broader record-package delivery mandates. Accordingly, the requirements in FC 1-300-09N Chapter 12 control without exception, and the package incorporates layers **Z-ANNO-REVC** and **Z-ANNO-REVS** exclusively.

### (b) Bid Package BP-3 Issue State & Backcheck Window Selection
For Bid Package BP-3, final advertisement is scheduled for 9 November 2026 in accordance with Contracting Officer Memorandum paragraph 3, which supersedes the earlier schedule export date of 12 October 2026. Bids are scheduled to open on 12 November 2026.

The Contracting Officer gave the DOR authority to select between two viable strategies:
- Strategy A: Incorporate design review adjustments before advertisement and issue the completed design as a pre-advertisement package.
- Strategy B: Proceed with advertising on 9 November 2026 and issue design modifications as an amendment during the active bidding window.

Review regulation ER 415-1-11, paragraph g, governing backcheck reviews prior to award, mandates that when corrections are integrated into the design prior to solicitation release, the backcheck process must commence at least thirty calendar days before advertising occurs. Applying this thirty calendar day window against the 9 November 2026 advertisement deadline yields a backcheck initiation cut-off of 10 October 2026.

Production begins on 31 August 2026. Preparing the nineteen affected drawings requires five production days at four sheets per day, accompanied by nine days of transmittal handling across three delivered files, concluding in fourteen days on 14 September 2026. Because completion occurs twenty-six days ahead of the 10 October 2026 milestone, no schedule extension is incurred (delay parameter D equals zero), avoiding delay assessments under CO Memorandum paragraph 4.

Conversely, adopting Strategy B would allow merely three calendar days between advertising and bid opening, directly breaching the mandatory fifteen-day backcheck duration required prior to bid opening by ER 415-1-11 paragraph e(4). This would force an operational bid opening delay and trigger steep escalating penalty fees.

Therefore, **PRE_ADVERTISEMENT_REISSUE** is adopted. Under this selection, no amendment designation is utilized, continuation sheet submittals are omitted, and sheets are re-delivered without revision clouds or delta markings as the clean certified bid release.

### (c) Revision (Issue) Block Overflow Decision for BP-2
A/E/C Graphics Standard Release 2.2 section 7.3 specifies that the standard revision schedule block contains exactly eight informational rows. Several drawings within package BP-2 (notably S-101, S-102, S-301, S-501, and S-502) already possess eight completed modification and amendment records, causing block overflow upon introducing Amendment 0003.

The graphics standard outlines two permissible methods:
- Option 1 (Preferred): Overwrite the earliest historical line entry within the block with current data, retaining older records outside the plotted perimeter for project archiving.
- Option 2: Permit subsequent line entries to extend beyond the schedule boundary upward into the drawing field.

A binding provision in section 7.3 dictates that whichever overflow option is selected must be applied uniformly across the entire drawing collection.

Option 1 is adopted set-wide across BP-2. In addition to being the preferred DoD drafting methodology that preserves clear drawing space, Option 1 avoids the financial surcharge associated with Option 2, which bills $880 on complex multi-view drawings having three or more views to handle drawing re-layout, whereas Option 1 assesses $520 per overflowing sheet. Utilizing Option 1 maintains graphical clarity while providing the lowest total cost to the Government.
