# CONTINUATION SHEET - AMENDMENT 0003

**SOLICITATION NO.:** N40085-26-R-2041  
**PROJECT TITLE:** Central Utility Plant and Site Utilities (BP-2)  
**WORK ORDER NO.:** 74213  
**FACILITY:** Naval Support Activity Ventura Bay, California  

---

## PART 1: BID PACKAGE BP-2 (AMENDMENT 0003)

### DRAWINGS:

On NAVFAC Drawing No. 74213-GI001 (GI-001):
Incorporate the following newly prepared sheets into the DRAWING INDEX under their respective discipline headers. The listed sheets accompany this Amendment:
- S-202 [74213-S202] BRACED BAY FRAMING ELEVATIONS - ADDED SHEET
- M-503 [74213-M503] CHILLER HOUSEKEEPING PAD ANCHORAGE DETAILS - ADDED SHEET

Update the DRAWING INDEX by replacing the drawings listed below with the current reissued sheets accompanying this Amendment:
- GI-001 [74213-GI001] DRAWING INDEX - REPLACED SHEET
- C-101 [74213-C101] SITE UTILITY PLAN - REPLACED SHEET
- C-301 [74213-C301] SITE UTILITY SECTIONS - REPLACED SHEET
- C-501 [74213-C501] CIVIL DETAILS - REPLACED SHEET
- S-101 [74213-S101] CUP FOUNDATION PLAN - REPLACED SHEET
- S-102 [74213-S102] CUP ROOF FRAMING PLAN - REPLACED SHEET
- S-301 [74213-S301] CUP BUILDING SECTIONS - REPLACED SHEET
- S-501 [74213-S501] FOUNDATION DETAILS - REPLACED SHEET
- S-502 [74213-S502] FRAMING DETAILS - REPLACED SHEET
- M-101 [74213-M101] CUP CHILLED WATER PLAN - REPLACED SHEET
- M-301 [74213-M301] CHILLED WATER PLANT SECTIONS - REPLACED SHEET
- M-401 [74213-M401] CHILLER BAY ENLARGED PLAN - REPLACED SHEET
- M-501 [74213-M501] PIPING DETAILS - REPLACED SHEET
- M-502 [74213-M502] EQUIPMENT ANCHORAGE DETAILS - REPLACED SHEET
- E-001 [74213-E001] ELECTRICAL PANEL SCHEDULES - REPLACED SHEET
- E-101 [74213-E101] CUP POWER PLAN - REPLACED SHEET
- E-501 [74213-E501] ELECTRICAL DETAILS - REPLACED SHEET

On NAVFAC Drawing No. 74213-C101 (C-101):
1/C-101 Site Utility Plan: Adjust route of 8-inch fire water supply line crossing electrical duct bank between grid lines E-4 and F-4 to maintain twelve inches minimum clear separation.

On NAVFAC Drawing No. 74213-C501 (C-501):
A/C-501 Thrust Block Detail: Reposition bearing area schedule directly above the section graphic.

On NAVFAC Drawing No. 74213-S101 (S-101):
1/S-101 Foundation Plan: Modify anchor rod embedment callouts along grid lines 2 and 4 from twelve inches to eighteen inches depth. Add reference tags to added sheet S-202 for braced bay framing elevations.

On NAVFAC Drawing No. 74213-S501 (S-501):
C/S-501 Slab Edge Detail: Adjust horizontal dimension string so that overall foundation width closes without numerical error.

On NAVFAC Drawing No. 74213-S502 (S-502):
A/S-502 Equipment Anchorage Detail: Remove cast-in anchor graphic and notes; replace with heavy-duty post-installed undercut anchorage requirements.

On NAVFAC Drawing No. 74213-M101 (M-101):
1/M-101 Chilled Water Plan: Revise primary chilled water supply main diameter tag from ten inches to twelve inches, aligning with hydraulic head computations in mechanical Design Analysis Section 8.1.

On NAVFAC Drawing No. 74213-M301 (M-301):
1/M-301 Plant Section A: Lower elevation of chilled water supply header by fourteen inches to resolve physical interference with structural roof framing members.
2/M-301 Plant Section B: Change chiller equipment outline linework to phantom line style.

On NAVFAC Drawing No. 74213-M401 (M-401):
1/M-401 Chiller Bay Enlarged Plan: Provide callout tag pointing to added detail drawing M-503 for chiller housekeeping pad anchor layout.

On NAVFAC Drawing No. 74213-M501 (M-501):
A/M-501 Pipe Support Detail: Modify trapeze hanger rod spacing annotations to conform with earlier CUP project installation parameters.

On NAVFAC Drawing No. 74213-E001 (E-001):
1/E-001 Panel Schedules: Reorganize column sequence to place circuit description text adjacent to circuit breaker pole numbers.

On NAVFAC Drawing No. 74213-E101 (E-101):
1/E-101 Power Plan: Reorient feeder tag leader lines to tie directly into disconnect switch load terminals.

---

### SPECIFICATIONS:

#### DOCUMENT 00 01 15 LIST OF DRAWINGS

##### 1.2 Contract Drawings
The following drawings are added to the contract set and accompany this Amendment:
```
DRAWING NO.    REVISION NO.    NAVFAC DWG NO.    TITLE
S-202          3               74213-S202        BRACED BAY FRAMING ELEVATIONS
M-503          3               74213-M503        CHILLER HOUSEKEEPING PAD ANCHORAGE DETAILS
```

The drawings listed below are removed and superseded by replacement prints dated August 2026, accompanying this Amendment:
```
DRAWING NO.    REVISION NO.    NAVFAC DWG NO.    TITLE
GI-001         3               74213-GI001       DRAWING INDEX
C-101          3               74213-C101        SITE UTILITY PLAN
C-301          3               74213-C301        SITE UTILITY SECTIONS
C-501          3               74213-C501        CIVIL DETAILS
S-101          3               74213-S101        CUP FOUNDATION PLAN
S-102          3               74213-S102        CUP ROOF FRAMING PLAN
S-301          3               74213-S301        CUP BUILDING SECTIONS
S-501          3               74213-S501        FOUNDATION DETAILS
S-502          3               74213-S502        FRAMING DETAILS
M-101          3               74213-M101        CUP CHILLED WATER PLAN
M-301          3               74213-M301        CHILLED WATER PLANT SECTIONS
M-401          3               74213-M401        CHILLER BAY ENLARGED PLAN
M-501          3               74213-M501        PIPING DETAILS
M-502          3               74213-M502        EQUIPMENT ANCHORAGE DETAILS
E-001          3               74213-E001        ELECTRICAL PANEL SCHEDULES
E-101          3               74213-E101        CUP POWER PLAN
E-501          3               74213-E501        ELECTRICAL DETAILS
```

--End of Amendment 0003 Changes--

---

## PART 2: BID PACKAGE BP-3 STATEMENT

Solicitation No. N40085-26-R-3018 (BP-3, Data Hall 210 Shell and Interiors) has not yet been advertised. In accordance with Contracting Officer Memorandum dated 26 August 2026, paragraph 2, all corrections resulting from the Engineer of Record review are incorporated into the design prior to solicitation advertisement as a pre-advertisement reissue. Consequently, no solicitation amendment change number is assigned, no continuation sheet is submitted, and the reissued sheets are incorporated cleanly into the certified bid package.
